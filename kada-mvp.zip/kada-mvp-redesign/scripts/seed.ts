/**
 * Seeds reference data for a fresh database: an admin account, a handful of
 * verified vendors with real products, and two rider partners.
 *
 * Run once after connecting MONGODB_URI:  npm run seed
 * Safe to re-run; it upserts by phone and skips products that already exist.
 */
import 'dotenv/config';
import { connectDb } from '../src/lib/db';
import { User, Vendor, Product, Rider } from '../src/lib/models';

const ADMIN_PHONE = process.env.ADMIN_BOOTSTRAP_PHONE || '08010000000';

const VENDORS = [
  { name: 'Mama Ovie Kitchen', ownerName: 'Ovie Aigbe', phone: '08030000001', categoryId: 'food', zoneId: 'emaudo', prepMins: 25, promoText: '20% off orders over ₦5,000',
    products: [
      { name: 'Jollof rice and chicken', sku: 'jollof', priceKobo: 350000, icon: 'utensils', description: 'Party jollof, one drumstick' },
      { name: 'White rice, stew and beef', sku: 'whiterice', priceKobo: 300000, icon: 'utensils' },
      { name: 'Egusi and pounded yam', sku: 'egusi', priceKobo: 420000, icon: 'utensils', description: 'Assorted meat' },
    ] },
  { name: 'Campus Grill', ownerName: 'Tega Obi', phone: '08030000002', categoryId: 'food', zoneId: 'gate', prepMins: 30,
    products: [
      { name: 'Jollof rice and chicken', sku: 'jollof', priceKobo: 380000, icon: 'utensils', description: 'Grilled quarter chicken' },
      { name: 'Chicken shawarma', sku: 'shawarma', priceKobo: 320000, icon: 'utensils' },
    ] },
  { name: 'Rehoboth Pharmacy', ownerName: 'Pharm. Uyi', phone: '08030000004', categoryId: 'pharmacy', zoneId: 'eguare', prepMins: 20,
    products: [
      { name: 'Paracetamol 500mg', sku: 'paracetamol', priceKobo: 50000, icon: 'pill', description: 'Card of 10, over the counter' },
      { name: 'Vitamin C 1000mg', sku: 'vitc', priceKobo: 180000, icon: 'pill' },
      { name: 'Antimalarial combination', sku: 'antimalarial', priceKobo: 450000, icon: 'pill', requiresPharmacist: true },
    ] },
  { name: 'Grace Chemist', ownerName: 'Pharm. Grace', phone: '08030000005', categoryId: 'pharmacy', zoneId: 'emaudo', prepMins: 22,
    products: [
      { name: 'Paracetamol 500mg', sku: 'paracetamol', priceKobo: 45000, icon: 'pill', description: 'Card of 10, over the counter' },
      { name: 'Vitamin C 1000mg', sku: 'vitc', priceKobo: 200000, icon: 'pill' },
    ] },
  { name: 'Ekpoma Provisions', ownerName: 'Sunday A.', phone: '08030000006', categoryId: 'grocery', zoneId: 'emaudo', prepMins: 35,
    products: [
      { name: 'Powdered milk 400g', sku: 'milk', priceKobo: 360000, icon: 'basket' },
      { name: 'Rice 5kg', sku: 'rice', priceKobo: 950000, icon: 'basket' },
      { name: 'Bottled water, 12 pack', sku: 'water', priceKobo: 240000, icon: 'cup' },
    ] },
  { name: 'Junction Mart', ownerName: 'Ada N.', phone: '08030000007', categoryId: 'grocery', zoneId: 'gate', prepMins: 30,
    products: [
      { name: 'Powdered milk 400g', sku: 'milk', priceKobo: 340000, icon: 'basket' },
      { name: 'Rice 5kg', sku: 'rice', priceKobo: 990000, icon: 'basket' },
      { name: 'Toothpaste 150g', sku: 'toothpaste', priceKobo: 160000, icon: 'box' },
    ] },
  { name: 'Sunrise Bakery', ownerName: 'Faith Edobor', phone: '08030000003', categoryId: 'bakery', zoneId: 'ujoelen', prepMins: 18,
    products: [
      { name: 'Family loaf', sku: 'bread', priceKobo: 150000, icon: 'bread', description: 'Baked this morning' },
      { name: 'Meat pie', sku: 'meatpie', priceKobo: 80000, icon: 'bread' },
    ] },
];

const RIDERS = [
  { name: 'Osas Igbinedion', phone: '08030008820', bike: 'Bajaj Boxer · EKP 442 QR', zoneId: 'emaudo' },
  { name: 'Sunday Eromosele', phone: '08050001140', bike: 'Haojue · EKP 118 XA', zoneId: 'gate' },
];

async function main() {
  await connectDb();

  const admin = await User.findOneAndUpdate(
    { phone: ADMIN_PHONE },
    { $set: { name: 'Operations', phoneVerified: true }, $addToSet: { roles: { $each: ['customer', 'admin'] } } },
    { upsert: true, new: true }
  );
  console.log(`admin ready: ${admin.phone}`);

  for (const v of VENDORS) {
    const vendor = await Vendor.findOneAndUpdate(
      { phone: v.phone },
      {
        $set: {
          name: v.name, ownerName: v.ownerName, categoryId: v.categoryId, zoneId: v.zoneId,
          prepMins: v.prepMins, status: 'active', isOpen: true, commissionPct: 10,
          promoText: v.promoText, payoutBank: 'Account on file',
        },
      },
      { upsert: true, new: true }
    );
    await User.findOneAndUpdate(
      { phone: v.phone },
      { $set: { name: v.ownerName, vendorId: vendor._id, phoneVerified: true }, $addToSet: { roles: 'vendor' } },
      { upsert: true }
    );
    for (const p of v.products) {
      const exists = await Product.findOne({ vendorId: vendor._id, sku: p.sku });
      if (exists) continue;
      await Product.create({ ...p, vendorId: vendor._id, available: true });
    }
    console.log(`vendor ready: ${v.name}`);
  }

  for (const r of RIDERS) {
    const rider = await Rider.findOneAndUpdate(
      { phone: r.phone },
      { $set: { name: r.name, bike: r.bike, zoneId: r.zoneId, status: 'active' } },
      { upsert: true, new: true }
    );
    await User.findOneAndUpdate(
      { phone: r.phone },
      { $set: { name: r.name, riderId: rider._id, phoneVerified: true }, $addToSet: { roles: 'rider' } },
      { upsert: true }
    );
    console.log(`rider ready: ${r.name}`);
  }

  console.log('\nSeed complete.');
  console.log(`Sign in to /ops/signin with ${ADMIN_PHONE}`);
  process.exit(0);
}

main().catch((e) => { console.error(e); process.exit(1); });
