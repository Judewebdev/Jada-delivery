# KADA

Local commerce and on-demand delivery for Ekpoma, Edo State. Next.js 14 App Router,
TypeScript, MongoDB, Paystack, deployed on Vercel.

KADA is not a restaurant app. Restaurants are one of six vendor categories, and the
data model, pricing and fulfilment logic are category-aware from the ground up.

---

## Architecture

```
UI (app router pages, client components)
  ↓  fetch
API routes (validation, authz, rate limiting)
  ↓
Services (business logic, one file per domain)
  ↓
Models (Mongoose schemas)  ·  External providers (Paystack, Termii, Resend, Google)
```

No page or component talks to the database directly. No service reads `process.env`
directly. Every provider sits behind an interface so it can be swapped.

```
src/
  app/
    page.tsx                 Landing
    join/                    Customer signup/signin, vendor and rider applications
    shop/                    Customer app (home, search, store, cart, orders, account)
    vendor/                  Business console (orders, products, payouts)
    rider/                   Rider app (runs, pickup codes, earnings)
    ops/                     Admin console. Separate cookie, separate sign in
    api/                     Route handlers
  components/                UI kit, cart, toast, shell
  lib/
    types.ts                 Order state machine, categories, zones, slots
    models/                  Mongoose schemas
    services/                auth, order, catalog, vendor, rider, payment, sms, email, maps, notification
    session.ts auth.ts       JWT cookies, role guards
    rate-limit.ts            Fixed-window limiter
  middleware.ts              Edge guard for /ops
scripts/seed.ts              Reference data + admin bootstrap
```

### The order state machine

One definition in `src/lib/types.ts` drives all four surfaces, so a status can never
mean two different things in two different places.

```
PENDING_PAYMENT → PAID → CONFIRMED → PREPARING → READY_FOR_PICKUP
  → RIDER_ASSIGNED → PICKED_UP → IN_TRANSIT → DELIVERED
                                            ↘ CANCELLED / FAILED
```

Each transition declares which roles may perform it. `OrderService.transition` refuses
anything the machine does not allow, regardless of what the client sends.

### Money

All amounts are integers in kobo. Floats are never used for currency. Prices are
recomputed server-side from the database at quote time and again at order time; a
price arriving from the browser is only ever used to detect a mismatch.

### Payments

An order becomes `PAID` only when Paystack confirms it, either through
`POST /api/orders/verify` (which calls Paystack's verify endpoint server-side) or
through the signed webhook at `POST /api/payments/webhook`. The browser reporting
success is never sufficient. `markPaid` is idempotent, so both paths are safe.

---

## Running locally

```bash
cp .env.example .env.local     # fill in MONGODB_URI and SESSION_SECRET at minimum
npm install
npm run seed                   # creates vendors, products, riders and the admin account
npm run dev
```

Without an SMS key the OTP is logged server-side and returned in non-production
responses so the app is testable. That never happens when `NODE_ENV=production`.

Sign in at `/join` with any seeded phone number, or at `/ops/signin` with
`ADMIN_BOOTSTRAP_PHONE`.

### Seeded accounts

| Phone | Role |
|---|---|
| 08010000000 | Admin (Ops) and customer |
| 08030000001 | Mama Ovie Kitchen (vendor) |
| 08030000005 | Grace Chemist (vendor) |
| 08030008820 | Osas Igbinedion (rider) |

---

## Deploying to Vercel

1. Push to GitHub.
2. Import the repo in Vercel. Framework preset is detected; build command is
   `next build`, no changes needed.
3. Add the environment variables below under **Settings → Environment Variables**
   for Production, Preview and Development.
4. Deploy, then run `npm run seed` once locally against the production
   `MONGODB_URI` to create the admin account and reference data.
5. In MongoDB Atlas → Network Access, allow `0.0.0.0/0` (Vercel functions do not
   have static IPs) and rely on the connection string credentials.

---

## Integration checklist

Everything below is built and wired. Each item needs a credential you supply.

### 1. MongoDB — required

- Create a free cluster at **cloud.mongodb.com**.
- **Connect → Drivers → Node.js** gives the connection string.
- Paste into Vercel as `MONGODB_URI`. Append your database name, e.g.
  `...mongodb.net/kada?retryWrites=true&w=majority`.
- Under **Network Access**, add `0.0.0.0/0`.

### 2. Session secret — required

```bash
openssl rand -base64 32
```

Paste into Vercel as `SESSION_SECRET`. Changing it signs everyone out, which is the
correct emergency response if you ever suspect it leaked.

### 3. Paystack — required for real payments

- **dashboard.paystack.com → Settings → API Keys & Webhooks**.
- Copy the **Secret Key** into `PAYSTACK_SECRET_KEY`. It must never be prefixed with
  `NEXT_PUBLIC_`; that would ship it to the browser.
- Copy the **Public Key** into `NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY`.
- On the same page set the **Webhook URL** to
  `https://yourdomain.com/api/payments/webhook`.
- Test keys work immediately. Live keys need a registered business, a bank account
  and Paystack's compliance review.

Until these are set, checkout returns a clear message rather than pretending to
succeed.

### 4. Google Maps — optional today, needed for address autocomplete

- **console.cloud.google.com → APIs & Services**. Enable **Geocoding API**,
  **Places API** and **Maps JavaScript API**.
- Create two keys:
  - Browser key → `NEXT_PUBLIC_GOOGLE_MAPS_API_KEY`, restricted by HTTP referrer to
    your domain.
  - Server key → `GOOGLE_MAPS_SERVER_KEY`, restricted by API rather than IP, since
    Vercel functions have no fixed IP.
- Set a **budget alert**. Geocoding is billed per request and this is the single
  easiest way to receive a surprise bill.
- Zones are flat-priced by design, so maps are a convenience for address entry, not
  a dependency of pricing.

### 5. SMS — needed for real OTP delivery

- **termii.com** → dashboard → API key.
- Set `SMS_PROVIDER=termii`, `SMS_API_KEY`, and `SMS_SENDER_ID` (your sender ID must
  be approved by Termii before it will deliver).
- To use a different provider, add a branch to `SmsService.send`. Nothing else in the
  codebase changes.

### 6. Email — optional

- **resend.com** → API key, and verify your sending domain.
- Set `EMAIL_PROVIDER=resend`, `EMAIL_API_KEY`, `EMAIL_FROM`.

### 7. Push notifications — not yet wired

`NotificationService` writes an in-app record and can escalate to SMS. Web Push
requires a service worker plus VAPID keys; the service interface is ready for it and
the call sites do not change.

---

## Security posture

- Sessions are signed JWTs in `httpOnly`, `SameSite=Lax`, `Secure` cookies.
- Ops uses a **separate cookie** (`kada_ops`) with an 8 hour lifetime. A customer
  session can never satisfy an admin check.
- `middleware.ts` blocks unauthenticated `/ops` page loads, and every admin API route
  independently calls `requireAdmin()`. Deleting the middleware would not expose data.
- Every mutating route validates its body with Zod before touching a service.
- Rate limits: OTP requests 10 per IP and 5 per phone per 15 minutes; verification 20
  per IP; order creation 12 per 5 minutes; applications 5 per hour.
- OTP codes are hashed at rest, expire in 10 minutes, allow 5 attempts, single use.
- Order ownership is always re-read from the database, never taken from the request.
- Error responses are human sentences. Stack traces are logged server-side only.

---

## What is deliberately not built yet

Stated plainly so nothing here looks more finished than it is.

- **Wallet top-up.** Balances exist and refunds credit them; funding a wallet
  directly is not yet a flow. Card and transfer at checkout work today.
- **Run batching.** Orders are dispatched one drop at a time. The slot model,
  pricing and data are in place; grouping three drops into one run is the next
  dispatch change and the one that moves the economics.
- **Tips and ratings.** Fields exist on the order document; the post-delivery UI is
  not built.
- **Product images.** Products render with category icons. Image upload needs a
  storage provider decision (Vercel Blob or Cloudinary).
- **Push notifications.** Interface ready, transport not wired.
- **Vendor and rider self-service onboarding beyond application.** Approval creates
  the account; document upload currently records which documents were confirmed
  rather than storing files.
