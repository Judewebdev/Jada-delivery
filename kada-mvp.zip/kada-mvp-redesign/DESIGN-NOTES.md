# What changed, and why

Two complaints, two unrelated causes.

## 1. "It looks like Chowdeck"

Correct, and my fault. I used their layout grammar.

**Their grammar:** promo banner carousel → circular category tiles → grid of
restaurant cards, each dominated by a photo.

That grammar assumes two things KADA does not have. It assumes professional food
photography for every listing, and it assumes the customer already knows which
shop they want. Copying it without photos produces grey placeholder boxes, which
is exactly why the old home read as unfinished.

**The new grammar:**

| Old | New |
|---|---|
| Purple hero banner | No banner. The search field is the hero |
| "What do you need today?" headline above a search box | `I need…` as the headline, with the input directly under it |
| 8 large category tiles in a grid | Category chips in one scrollable row, secondary |
| Vendor photo cards in a 3-column grid | An indexed ledger: numbered rows, name, ETA and fee aligned right |
| Popular items carousel | **Same item, different price** |

### The centrepiece

`Same item, different price` shows one product across every vendor that stocks
it, with the low and high anchored at opposite ends of a spread bar and the
saving called out in yellow.

This is the single screen a restaurant-first competitor cannot copy. Chowdeck's
model is one restaurant per basket, so cross-vendor price comparison has nowhere
to live in their product. Yours is built on it. The tagline "search the product,
not the shop" is now something the home screen actually does rather than
something it claims.

Visual decisions that follow from it:

- **Numbers, not photos.** Rows are indexed `01, 02, 03`. Prices and times use
  tabular figures so columns line up. The interface looks like a price list
  because that is what it is. This is honest and it survives having no imagery.
- **Rules, not cards.** Hairline borders and a 2px section rule replace floating
  card shadows. Less visual noise per screen.
- **Yellow earns its place.** It now appears only on a saving. When it means one
  thing, it carries weight.

## 2. "The dashboard is slow"

This was never a design problem and no component library would have fixed it.

**The cause:** every dashboard rendered an empty shell, waited for hydration,
then called an API, which then opened a MongoDB connection. On Atlas free tier a
cold connection is two to four seconds, and that happened *after* the browser had
already finished its work.

**The fixes:**

1. **Server-rendered first paint.** The vendor dashboard now fetches on the
   server and ships real orders in the first response. No spinner, no waterfall.
2. **Streaming on the shop home.** The shell renders from the session cookie
   alone with no database read. Each section streams in behind its own Suspense
   boundary, so a slow query delays one block instead of the whole page.
3. **Route-level `loading.tsx`.** Every surface now has an instant skeleton that
   mirrors its real layout. Navigation never shows a blank screen.
4. **Connection tuning.** Smaller pool, 60s idle retention, fail-fast timeouts
   (5s instead of 30s), and zlib compression, which matters on mobile backhaul.
5. **Polling halved and made visibility-aware.** 8s became 15s, and it pauses
   entirely when the tab is hidden. A phone in a pocket no longer burns a
   vendor's data.
6. **Optimistic actions.** Accepting an order moves the row immediately, then
   reconciles. The vendor never waits on the network to see their own tap.

**What is still slow and cannot be fixed in code:** the very first request after
a period of inactivity. That is Vercel's serverless cold start plus Atlas waking
up. It goes away on a paid Atlas tier, or once you have enough traffic to keep
instances warm. Do not pay for that yet.
