import type { Config } from 'tailwindcss';

/**
 * KADA design tokens.
 * Brand: deep purple #2E0A4E, warm yellow #F9C74F, white.
 * Neutrals support the brand, they never compete with it.
 */
const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        purple: {
          900: '#1B0430',
          700: '#2E0A4E',
          500: '#4A2270',
          300: '#7A5A9B',
          100: '#EDE7F3',
          50: '#F7F4FA',
        },
        yellow: {
          600: '#DFAB2C',
          500: '#F9C74F',
          200: '#FDECC0',
          100: '#FEF7E6',
        },
        ink: {
          900: '#191527',
          600: '#5F5A6B',
          400: '#9B97A6',
          300: '#CFCCD8',
          200: '#E4E2EA',
          100: '#F1F0F4',
          50: '#F7F7F9',
          25: '#FCFCFD',
        },
        ok: { 600: '#1C7A4B', 50: '#E9F4EE' },
        warn: { 700: '#8A5A08', 50: '#FDF4E3' },
        err: { 600: '#B3261E', 50: '#FBEDEC' },
      },
      fontFamily: {
        sans: ['Manrope', 'system-ui', '-apple-system', 'Segoe UI', 'sans-serif'],
      },
      borderRadius: {
        xs: '8px',
        sm: '12px',
        md: '16px',
        lg: '20px',
        xl: '28px',
      },
      spacing: {
        1: '4px', 2: '8px', 3: '12px', 4: '16px', 5: '24px',
        6: '32px', 7: '40px', 8: '48px', 9: '64px', 10: '80px',
        tap: '44px',
      },
      boxShadow: {
        1: '0 1px 2px rgba(25,21,39,.05)',
        2: '0 4px 14px -6px rgba(25,21,39,.12)',
        3: '0 18px 44px -12px rgba(25,21,39,.28)',
      },
      transitionTimingFunction: {
        kada: 'cubic-bezier(.2,.8,.2,1)',
      },
      keyframes: {
        shimmer: { '0%': { backgroundPosition: '100% 50%' }, '100%': { backgroundPosition: '0 50%' } },
        rise: { from: { transform: 'translateY(20px)', opacity: '0.4' }, to: { transform: 'none', opacity: '1' } },
        fade: { from: { opacity: '0' }, to: { opacity: '1' } },
        pulseDot: { '0%,100%': { opacity: '1' }, '50%': { opacity: '.35' } },
        spin: { to: { transform: 'rotate(360deg)' } },
      },
      animation: {
        shimmer: 'shimmer 1.3s ease infinite',
        rise: 'rise .32s cubic-bezier(.2,.8,.2,1)',
        fade: 'fade .2s cubic-bezier(.2,.8,.2,1)',
        pulseDot: 'pulseDot 1.8s cubic-bezier(.2,.8,.2,1) infinite',
        spin: 'spin .7s linear infinite',
      },
    },
  },
  plugins: [],
};
export default config;
