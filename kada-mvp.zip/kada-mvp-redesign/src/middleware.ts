import { NextResponse, type NextRequest } from 'next/server';
import { jwtVerify } from 'jose';

/**
 * Edge guard for the Ops console. This is defence in depth only: every admin
 * API route re-checks authorisation server-side, so removing this file would
 * not expose data. Its job is to stop an unauthenticated person ever rendering
 * an admin screen.
 */
const OPS_COOKIE = 'kada_ops';

async function isAdmin(token: string | undefined, secret: string): Promise<boolean> {
  if (!token) return false;
  try {
    const { payload } = await jwtVerify(token, new TextEncoder().encode(secret), { issuer: 'kada' });
    return Array.isArray(payload.roles) && (payload.roles as string[]).includes('admin');
  } catch {
    return false;
  }
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  if (!pathname.startsWith('/ops')) return NextResponse.next();
  if (pathname === '/ops/signin') return NextResponse.next();

  const secret = process.env.SESSION_SECRET;
  if (!secret) return NextResponse.redirect(new URL('/ops/signin', req.url));

  const ok = await isAdmin(req.cookies.get(OPS_COOKIE)?.value, secret);
  if (!ok) {
    const url = new URL('/ops/signin', req.url);
    url.searchParams.set('next', pathname);
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}

export const config = { matcher: ['/ops/:path*'] };
