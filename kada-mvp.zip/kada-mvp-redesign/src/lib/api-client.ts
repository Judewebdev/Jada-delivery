/**
 * Single fetch wrapper. Every API error reaches the UI as a human sentence,
 * never a status code or a stack trace.
 */
export class ApiError extends Error {
  constructor(public status: number, message: string, public field?: string) {
    super(message);
  }
}

export async function api<T>(path: string, init?: RequestInit & { json?: unknown }): Promise<T> {
  const { json, ...rest } = init ?? {};
  let res: Response;
  try {
    res = await fetch(path, {
      ...rest,
      headers: { ...(json ? { 'Content-Type': 'application/json' } : {}), ...(rest.headers ?? {}) },
      body: json ? JSON.stringify(json) : rest.body,
      cache: 'no-store',
    });
  } catch {
    throw new ApiError(0, 'We could not reach the server. Check your connection and try again.');
  }

  let data: unknown = null;
  try { data = await res.json(); } catch { /* empty body is fine */ }

  if (!res.ok) {
    const e = data as { error?: string; field?: string } | null;
    throw new ApiError(res.status, e?.error ?? 'Something went wrong. Please try again.', e?.field);
  }
  return data as T;
}
