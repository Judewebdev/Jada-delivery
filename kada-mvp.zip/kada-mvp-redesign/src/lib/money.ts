/**
 * All money is stored and computed in kobo as integers. Floats are never used
 * for currency anywhere in this codebase.
 */
export const naira = (kobo: number): string =>
  '\u20A6' + Math.round(kobo / 100).toLocaleString('en-NG');

export const toKobo = (n: number): number => Math.round(n * 100);
export const fromKobo = (kobo: number): number => kobo / 100;
