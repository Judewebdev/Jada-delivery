import { serverEnv, publicEnv, isConfigured } from '@/lib/env';

/**
 * MapsService. Geocoding and distance run server-side with a separate,
 * IP-restricted server key. The public key is browser-only and referrer
 * restricted. Coordinates are cached on the document that needs them, so an
 * address is geocoded once rather than on every render.
 */
export interface Coords { lat: number; lng: number }
export interface GeocodeResult { ok: boolean; coords?: Coords; formatted?: string; error?: string }

const KEY = () => serverEnv.googleMapsServerKey || publicEnv.googleMapsKey;

export const MapsService = {
  isLive: () => isConfigured.maps() || Boolean(serverEnv.googleMapsServerKey),

  async geocode(address: string): Promise<GeocodeResult> {
    if (!this.isLive()) return { ok: false, error: 'Maps key not configured' };
    const url = new URL('https://maps.googleapis.com/maps/api/geocode/json');
    url.searchParams.set('address', `${address}, ${publicEnv.city}, Edo State, Nigeria`);
    url.searchParams.set('key', KEY());
    const res = await fetch(url, { next: { revalidate: 86400 } });
    const data = (await res.json()) as {
      status: string;
      results?: { geometry: { location: Coords }; formatted_address: string }[];
    };
    if (data.status !== 'OK' || !data.results?.length) {
      return { ok: false, error: `Geocoding returned ${data.status}` };
    }
    const first = data.results[0];
    return { ok: true, coords: first.geometry.location, formatted: first.formatted_address };
  },

  /** Haversine. Used for rider ranking; avoids a paid Distance Matrix call. */
  distanceKm(a: Coords, b: Coords): number {
    const R = 6371;
    const dLat = ((b.lat - a.lat) * Math.PI) / 180;
    const dLng = ((b.lng - a.lng) * Math.PI) / 180;
    const s =
      Math.sin(dLat / 2) ** 2 +
      Math.cos((a.lat * Math.PI) / 180) * Math.cos((b.lat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
    return Math.round(R * 2 * Math.asin(Math.sqrt(s)) * 10) / 10;
  },
};
