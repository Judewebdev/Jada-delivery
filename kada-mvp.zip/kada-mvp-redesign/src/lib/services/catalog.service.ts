import { connectDb } from '@/lib/db';
import { Product, Vendor } from '@/lib/models';

/**
 * CatalogService. Search is product-first: a query for "paracetamol" returns the
 * product grouped across every vendor that stocks it, cheapest first. Searching
 * only by business name would defeat the point of the platform.
 */

export interface ProductHit {
  id: string; name: string; sku: string; priceKobo: number; icon: string;
  available: boolean; requiresPharmacist: boolean; description?: string;
  vendor: { id: string; name: string; categoryId: string; zoneId: string; isOpen: boolean; prepMins: number; rating: number };
}
export interface SearchResult {
  groups: { sku: string; name: string; offers: ProductHit[] }[];
  vendors: { id: string; name: string; categoryId: string; zoneId: string; isOpen: boolean; rating: number; ratingCount: number; prepMins: number; promoText?: string }[];
}

const escapeRegex = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

export const CatalogService = {
  async listVendors(opts: { categoryId?: string; zoneId?: string } = {}) {
    await connectDb();
    const q: Record<string, unknown> = { status: 'active' };
    if (opts.categoryId) q.categoryId = opts.categoryId;
    const vendors = await Vendor.find(q).sort({ isOpen: -1, rating: -1 }).limit(60).lean();
    return vendors.map((v) => ({
      id: String(v._id), name: v.name, categoryId: v.categoryId, zoneId: v.zoneId,
      isOpen: v.isOpen, rating: v.rating, ratingCount: v.ratingCount,
      prepMins: v.prepMins, promoText: v.promoText,
    }));
  },

  async getVendor(id: string) {
    await connectDb();
    const v = await Vendor.findOne({ _id: id, status: 'active' }).lean();
    if (!v) return null;
    const products = await Product.find({ vendorId: v._id }).sort({ available: -1, name: 1 }).lean();
    return {
      vendor: {
        id: String(v._id), name: v.name, categoryId: v.categoryId, zoneId: v.zoneId,
        isOpen: v.isOpen, rating: v.rating, ratingCount: v.ratingCount, prepMins: v.prepMins,
        promoText: v.promoText, address: v.address,
      },
      products: products.map((p) => ({
        id: String(p._id), name: p.name, sku: p.sku, priceKobo: p.priceKobo, icon: p.icon,
        available: p.available, requiresPharmacist: p.requiresPharmacist, description: p.description,
      })),
    };
  },

  async search(term: string): Promise<SearchResult> {
    await connectDb();
    const q = term.trim();
    if (q.length < 2) return { groups: [], vendors: [] };
    const rx = new RegExp(escapeRegex(q), 'i');

    const [products, vendorsByName] = await Promise.all([
      Product.find({ $or: [{ name: rx }, { sku: rx }] }).limit(80).lean(),
      Vendor.find({ name: rx, status: 'active' }).limit(20).lean(),
    ]);

    const vendorIds = [...new Set(products.map((p) => String(p.vendorId)))];
    const vendorDocs = await Vendor.find({ _id: { $in: vendorIds }, status: 'active' }).lean();
    const vendorMap = new Map(vendorDocs.map((v) => [String(v._id), v]));

    const hits: ProductHit[] = [];
    for (const p of products) {
      const v = vendorMap.get(String(p.vendorId));
      if (!v) continue;
      hits.push({
        id: String(p._id), name: p.name, sku: p.sku, priceKobo: p.priceKobo, icon: p.icon,
        available: p.available, requiresPharmacist: p.requiresPharmacist, description: p.description,
        vendor: {
          id: String(v._id), name: v.name, categoryId: v.categoryId, zoneId: v.zoneId,
          isOpen: v.isOpen, prepMins: v.prepMins, rating: v.rating,
        },
      });
    }

    const bySku = new Map<string, ProductHit[]>();
    for (const h of hits) {
      const arr = bySku.get(h.sku) ?? [];
      arr.push(h);
      bySku.set(h.sku, arr);
    }
    const groups = [...bySku.entries()].map(([sku, offers]) => ({
      sku,
      name: offers[0].name,
      offers: offers.sort((a, b) => Number(b.available) - Number(a.available) || a.priceKobo - b.priceKobo),
    }));

    const merged = new Map<string, (typeof vendorDocs)[number]>();
    [...vendorsByName, ...vendorDocs].forEach((v) => merged.set(String(v._id), v));

    return {
      groups,
      vendors: [...merged.values()].map((v) => ({
        id: String(v._id), name: v.name, categoryId: v.categoryId, zoneId: v.zoneId,
        isOpen: v.isOpen, rating: v.rating, ratingCount: v.ratingCount,
        prepMins: v.prepMins, promoText: v.promoText,
      })),
    };
  },

  /**
   * The price spread: items stocked by more than one vendor, with the cheapest
   * and dearest side by side. This is the home screen's centrepiece and the one
   * thing a restaurant-first competitor structurally cannot show.
   */
  async priceSpread(limit = 4) {
    await connectDb();
    const openVendors = await Vendor.find({ status: 'active' }).select('_id name isOpen prepMins').lean();
    const openIds = openVendors.map((v) => v._id);
    const products = await Product.find({ vendorId: { $in: openIds }, available: true }).lean();

    const bySku = new Map<string, typeof products>();
    for (const p of products) {
      const arr = bySku.get(p.sku) ?? [];
      arr.push(p);
      bySku.set(p.sku, arr);
    }

    const spreads = [...bySku.entries()]
      .filter(([, items]) => items.length > 1)
      .map(([sku, items]) => {
        const sorted = [...items].sort((a, b) => a.priceKobo - b.priceKobo);
        const low = sorted[0];
        const high = sorted[sorted.length - 1];
        const lowVendor = openVendors.find((v) => String(v._id) === String(low.vendorId));
        return {
          sku,
          name: low.name,
          icon: low.icon,
          places: items.length,
          lowKobo: low.priceKobo,
          highKobo: high.priceKobo,
          savingKobo: high.priceKobo - low.priceKobo,
          cheapestId: String(low._id),
          cheapestVendor: { id: String(low.vendorId), name: lowVendor?.name ?? '' },
        };
      })
      .sort((a, b) => b.savingKobo - a.savingKobo)
      .slice(0, limit);

    return spreads;
  },

  async popular(limit = 8) {
    await connectDb();
    const products = await Product.find({ available: true }).limit(limit).lean();
    const vendorDocs = await Vendor.find({ _id: { $in: products.map((p) => p.vendorId) } }).lean();
    const map = new Map(vendorDocs.map((v) => [String(v._id), v]));
    return products.map((p) => ({
      id: String(p._id), name: p.name, priceKobo: p.priceKobo, icon: p.icon,
      vendorName: map.get(String(p.vendorId))?.name ?? '',
      vendorId: String(p.vendorId),
    }));
  },
};
