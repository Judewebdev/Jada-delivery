import { connectDb } from '@/lib/db';
import { Rider, Order } from '@/lib/models';
import { HttpError } from '@/lib/auth';

export const RiderService = {
  async get(id: string) {
    await connectDb();
    const r = await Rider.findById(id).lean();
    if (!r) throw new HttpError(404, 'Rider not found.');
    return r;
  },
  async setOnline(id: string, online: boolean) {
    await connectDb();
    const r = await Rider.findById(id);
    if (!r) throw new HttpError(404, 'Rider not found.');
    if (r.status !== 'active') throw new HttpError(403, 'Your account is not active yet.');
    r.online = online;
    await r.save();
    return r.toObject();
  },
  async setSlots(id: string, slots: string[]) {
    await connectDb();
    return Rider.findByIdAndUpdate(id, { slots: slots.slice(0, 8) }, { new: true }).lean();
  },
  async activeJobs(riderId: string) {
    await connectDb();
    return Order.find({ riderId, status: { $in: ['RIDER_ASSIGNED', 'PICKED_UP', 'IN_TRANSIT'] } })
      .sort({ statusAt: 1 }).lean();
  },
  async earnings(riderId: string) {
    await connectDb();
    const r = await Rider.findById(riderId).lean();
    if (!r) throw new HttpError(404, 'Rider not found.');
    return { runs: r.runsCompleted, earnedKobo: r.earnedKobo, tipsKobo: r.tipsKobo, totalKobo: r.earnedKobo + r.tipsKobo };
  },
};
