import { connectDb } from '@/lib/db';
import { Vendor, Product, Order } from '@/lib/models';
import { HttpError } from '@/lib/auth';

export const VendorService = {
  async get(id: string) {
    await connectDb();
    const v = await Vendor.findById(id).lean();
    if (!v) throw new HttpError(404, 'Business not found.');
    return v;
  },
  async setOpen(id: string, isOpen: boolean) {
    await connectDb();
    return Vendor.findByIdAndUpdate(id, { isOpen }, { new: true }).lean();
  },
  async products(vendorId: string) {
    await connectDb();
    return Product.find({ vendorId }).sort({ name: 1 }).lean();
  },
  async setAvailability(vendorId: string, productId: string, available: boolean) {
    await connectDb();
    const p = await Product.findOne({ _id: productId, vendorId });
    if (!p) throw new HttpError(404, 'That product is not on your list.');
    p.available = available;
    await p.save();
    return p.toObject();
  },
  async setPrice(vendorId: string, productId: string, priceKobo: number) {
    await connectDb();
    if (!Number.isInteger(priceKobo) || priceKobo < 5000 || priceKobo > 50000000) {
      throw new HttpError(400, 'That price does not look right.');
    }
    const p = await Product.findOne({ _id: productId, vendorId });
    if (!p) throw new HttpError(404, 'That product is not on your list.');
    p.priceKobo = priceKobo;
    await p.save();
    return p.toObject();
  },
  async payoutSummary(vendorId: string) {
    await connectDb();
    const delivered = await Order.find({ vendorId, status: 'DELIVERED' })
      .select('subtotalKobo discountKobo commissionKobo').lean();
    const gross = delivered.reduce((a, o) => a + o.subtotalKobo - o.discountKobo, 0);
    const commission = delivered.reduce((a, o) => a + o.commissionKobo, 0);
    return { orders: delivered.length, grossKobo: gross, commissionKobo: commission, netKobo: gross - commission };
  },
};
