import { serverEnv, isConfigured } from '@/lib/env';

/**
 * EmailService. Transactional only. Marketing/newsletter is deliberately a
 * separate concern so a bounce on one never blocks the other.
 */
export interface EmailMessage { to: string; subject: string; html: string; text?: string }
export interface EmailResult { delivered: boolean; provider: string; id?: string; error?: string }

async function sendResend(msg: EmailMessage): Promise<EmailResult> {
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${serverEnv.emailApiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      from: serverEnv.emailFrom,
      to: [msg.to],
      subject: msg.subject,
      html: msg.html,
      text: msg.text,
    }),
  });
  const data = (await res.json()) as { id?: string; message?: string };
  if (!res.ok) return { delivered: false, provider: 'resend', error: data.message ?? 'send failed' };
  return { delivered: true, provider: 'resend', id: data.id };
}

export const EmailService = {
  isLive: () => isConfigured.email(),

  async send(msg: EmailMessage): Promise<EmailResult> {
    if (!isConfigured.email()) {
      console.info('[email:not-configured]', msg.to, msg.subject);
      return { delivered: false, provider: 'console', error: 'EMAIL_API_KEY not configured' };
    }
    switch (serverEnv.emailProvider) {
      case 'resend':
        return sendResend(msg);
      default:
        return { delivered: false, provider: serverEnv.emailProvider, error: 'unknown provider' };
    }
  },

  async orderConfirmation(to: string, reference: string, totalNaira: string): Promise<EmailResult> {
    return this.send({
      to,
      subject: `Order ${reference} confirmed`,
      html: `<p>Your order <strong>${reference}</strong> is confirmed.</p><p>Total paid: ${totalNaira}</p>`,
      text: `Your order ${reference} is confirmed. Total paid: ${totalNaira}`,
    });
  },
};
