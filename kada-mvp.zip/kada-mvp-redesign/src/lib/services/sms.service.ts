import { serverEnv, isConfigured } from '@/lib/env';

/**
 * SmsService. Provider-agnostic by design so a Nigerian provider can be swapped
 * in without touching any caller. Add a case to `send` and set SMS_PROVIDER.
 */
export interface SmsMessage { to: string; body: string }
export interface SmsResult { delivered: boolean; provider: string; id?: string; error?: string }

async function sendTermii(msg: SmsMessage): Promise<SmsResult> {
  const res = await fetch('https://api.ng.termii.com/api/sms/send', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      to: msg.to,
      from: serverEnv.smsSenderId,
      sms: msg.body,
      type: 'plain',
      channel: 'generic',
      api_key: serverEnv.smsApiKey,
    }),
  });
  const data = (await res.json()) as { message_id?: string; message?: string };
  if (!res.ok) return { delivered: false, provider: 'termii', error: data.message ?? 'send failed' };
  return { delivered: true, provider: 'termii', id: data.message_id };
}

export const SmsService = {
  isLive: () => isConfigured.sms(),

  async send(msg: SmsMessage): Promise<SmsResult> {
    if (!isConfigured.sms()) {
      // No credential configured. Log rather than pretend a message was sent.
      console.info('[sms:not-configured]', msg.to, msg.body);
      return { delivered: false, provider: 'console', error: 'SMS_API_KEY not configured' };
    }
    switch (serverEnv.smsProvider) {
      case 'termii':
        return sendTermii(msg);
      default:
        console.info('[sms:unknown-provider]', serverEnv.smsProvider);
        return { delivered: false, provider: serverEnv.smsProvider, error: 'unknown provider' };
    }
  },

  async sendOtp(phone: string, code: string): Promise<SmsResult> {
    return this.send({ to: phone, body: `Your KADA code is ${code}. It expires in 10 minutes.` });
  },
};
