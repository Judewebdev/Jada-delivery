import { serverEnv, publicEnv, isConfigured } from '@/lib/env';
import crypto from 'crypto';

/**
 * PaymentService. Paystack is behind this interface so the app is never
 * permanently married to one PSP.
 *
 * Security rule that everything else depends on: an order becomes PAID only
 * after this service verifies the transaction directly with Paystack, or after
 * a signed webhook is validated. The browser saying "payment succeeded" is
 * never sufficient and is never trusted.
 */

export interface InitResult {
  ok: boolean;
  authorizationUrl?: string;
  accessCode?: string;
  reference?: string;
  error?: string;
}
export interface VerifyResult {
  ok: boolean;
  paid: boolean;
  amountKobo?: number;
  reference?: string;
  channel?: string;
  raw?: unknown;
  error?: string;
}

const API = 'https://api.paystack.co';

async function paystack<T>(path: string, init?: RequestInit): Promise<{ ok: boolean; data?: T; message?: string }> {
  const res = await fetch(`${API}${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${serverEnv.paystackSecret}`,
      'Content-Type': 'application/json',
      ...(init?.headers ?? {}),
    },
    cache: 'no-store',
  });
  const json = (await res.json()) as { status: boolean; message: string; data: T };
  if (!res.ok || !json.status) return { ok: false, message: json.message ?? `Paystack ${res.status}` };
  return { ok: true, data: json.data };
}

export const PaymentService = {
  isLive: () => isConfigured.paystack(),
  publicKey: () => publicEnv.paystackPublicKey,

  /** Server-side initialisation. The secret key never reaches the browser. */
  async initialize(opts: {
    email: string;
    amountKobo: number;
    reference: string;
    metadata?: Record<string, unknown>;
  }): Promise<InitResult> {
    if (!isConfigured.paystack()) {
      return { ok: false, error: 'Payments are not configured yet. Add PAYSTACK_SECRET_KEY.' };
    }
    const r = await paystack<{ authorization_url: string; access_code: string; reference: string }>(
      '/transaction/initialize',
      {
        method: 'POST',
        body: JSON.stringify({
          email: opts.email,
          amount: opts.amountKobo,
          reference: opts.reference,
          currency: 'NGN',
          callback_url: `${publicEnv.appUrl}/orders/verify`,
          metadata: opts.metadata ?? {},
        }),
      }
    );
    if (!r.ok || !r.data) return { ok: false, error: r.message };
    return {
      ok: true,
      authorizationUrl: r.data.authorization_url,
      accessCode: r.data.access_code,
      reference: r.data.reference,
    };
  },

  /** The only path by which an order may be marked paid. */
  async verify(reference: string): Promise<VerifyResult> {
    if (!isConfigured.paystack()) {
      return { ok: false, paid: false, error: 'Payments are not configured yet.' };
    }
    const r = await paystack<{ status: string; amount: number; reference: string; channel: string }>(
      `/transaction/verify/${encodeURIComponent(reference)}`
    );
    if (!r.ok || !r.data) return { ok: false, paid: false, error: r.message };
    return {
      ok: true,
      paid: r.data.status === 'success',
      amountKobo: r.data.amount,
      reference: r.data.reference,
      channel: r.data.channel,
      raw: r.data,
    };
  },

  /** Validates the x-paystack-signature header on webhook deliveries. */
  verifyWebhookSignature(rawBody: string, signature: string | null): boolean {
    if (!signature || !isConfigured.paystack()) return false;
    const hash = crypto
      .createHmac('sha512', serverEnv.paystackSecret)
      .update(rawBody, 'utf8')
      .digest('hex');
    const a = Buffer.from(hash);
    const b = Buffer.from(signature);
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  },

  newReference(): string {
    return `KADA_${Date.now().toString(36).toUpperCase()}_${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
  },
};
