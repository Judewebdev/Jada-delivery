import crypto from 'crypto';
import { connectDb } from '@/lib/db';
import { OtpToken, User, Vendor, Rider } from '@/lib/models';
import { HttpError } from '@/lib/auth';
import { SmsService } from './sms.service';
import { serverEnv } from '@/lib/env';
import type { Role } from '@/lib/types';

/**
 * AuthService. Phone plus one-time code. Codes are hashed at rest, expire in
 * ten minutes, allow five attempts, and cannot be reused. Nothing here ever
 * returns the code to the client in production.
 */

const OTP_TTL_MS = 10 * 60 * 1000;
const MAX_ATTEMPTS = 5;

export function normalisePhone(raw: string): string {
  const d = String(raw).replace(/\D/g, '');
  if (d.startsWith('234') && d.length === 13) return '0' + d.slice(3);
  if (d.startsWith('0') && d.length === 11) return d;
  if (d.length === 10) return '0' + d;
  throw new HttpError(400, 'That does not look like a Nigerian phone number.', 'phone');
}

const hash = (code: string, phone: string) =>
  crypto.createHash('sha256').update(`${code}:${phone}:${serverEnv.sessionSecret}`).digest('hex');

export const AuthService = {
  async requestOtp(rawPhone: string) {
    await connectDb();
    const phone = normalisePhone(rawPhone);
    const code = String(crypto.randomInt(100000, 999999));

    await OtpToken.updateMany({ phone, consumed: false }, { consumed: true });
    await OtpToken.create({
      phone,
      codeHash: hash(code, phone),
      attempts: 0,
      consumed: false,
      expiresAt: new Date(Date.now() + OTP_TTL_MS),
    });

    const sms = await SmsService.sendOtp(phone, code);
    const exists = Boolean(await User.exists({ phone }));

    return {
      phone,
      exists,
      delivered: sms.delivered,
      // Only surfaced outside production so the app is testable before an SMS
      // provider is connected. Never returned on a production deployment.
      devCode: process.env.NODE_ENV === 'production' ? undefined : code,
    };
  },

  async verifyOtp(rawPhone: string, code: string) {
    await connectDb();
    const phone = normalisePhone(rawPhone);
    const token = await OtpToken.findOne({ phone, consumed: false }).sort({ createdAt: -1 });
    if (!token) throw new HttpError(400, 'Request a new code to continue.', 'code');
    if (token.expiresAt.getTime() < Date.now()) {
      throw new HttpError(400, 'That code has expired. Request a new one.', 'code');
    }
    if (token.attempts >= MAX_ATTEMPTS) {
      throw new HttpError(429, 'Too many attempts. Request a new code.', 'code');
    }
    if (token.codeHash !== hash(String(code).trim(), phone)) {
      token.attempts += 1;
      await token.save();
      throw new HttpError(400, 'That code is not correct.', 'code');
    }
    token.consumed = true;
    await token.save();

    const user = await User.findOne({ phone });
    return { phone, user };
  },

  async createCustomer(input: { phone: string; name: string; zoneId: string; landmark?: string; email?: string }) {
    await connectDb();
    const phone = normalisePhone(input.phone);
    const existing = await User.findOne({ phone });
    if (existing) return existing;
    return User.create({
      phone,
      name: input.name.trim(),
      email: input.email?.trim().toLowerCase(),
      zoneId: input.zoneId,
      landmark: input.landmark ?? '',
      roles: ['customer'] as Role[],
      phoneVerified: true,
      walletKobo: 0,
    });
  },

  /** Resolves the roles a verified phone actually holds, from source records. */
  async resolveRoles(phone: string) {
    await connectDb();
    const user = await User.findOne({ phone });
    if (!user) return null;
    const roles = new Set<Role>(user.roles);
    const vendor = await Vendor.findOne({ phone, status: 'active' }).select('_id').lean();
    const rider = await Rider.findOne({ phone, status: 'active' }).select('_id').lean();
    if (vendor) roles.add('vendor');
    if (rider) roles.add('rider');
    if (user.roles.includes('admin')) roles.add('admin');

    if (vendor && String(user.vendorId ?? '') !== String(vendor._id)) {
      user.vendorId = vendor._id;
    }
    if (rider && String(user.riderId ?? '') !== String(rider._id)) {
      user.riderId = rider._id;
    }
    user.roles = [...roles];
    await user.save();

    return {
      user,
      session: {
        sub: String(user._id),
        roles: [...roles],
        name: user.name,
        vendorId: vendor ? String(vendor._id) : undefined,
        riderId: rider ? String(rider._id) : undefined,
      },
    };
  },
};
