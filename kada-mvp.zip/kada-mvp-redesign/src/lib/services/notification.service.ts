import { connectDb } from '@/lib/db';
import { Notification, User } from '@/lib/models';
import { SmsService } from './sms.service';
import type { Types } from 'mongoose';

/**
 * NotificationService. In-app record is always written. Push is preferred over
 * SMS because SMS costs money per message; SMS is reserved for events the
 * customer must not miss and only when push is unavailable.
 */
export type NotifyKind = 'order_update' | 'payment' | 'account' | 'promo';

export const NotificationService = {
  async notify(opts: {
    userId: Types.ObjectId | string;
    title: string;
    body: string;
    kind: NotifyKind;
    orderId?: Types.ObjectId | string;
    alsoSms?: boolean;
  }) {
    await connectDb();
    await Notification.create({
      userId: opts.userId,
      title: opts.title,
      body: opts.body,
      channel: 'inapp',
      orderId: opts.orderId,
    });

    if (opts.alsoSms) {
      const user = await User.findById(opts.userId).select('phone').lean();
      if (user?.phone) {
        await SmsService.send({ to: user.phone, body: `${opts.title}. ${opts.body}` });
      }
    }
  },

  async listFor(userId: string, limit = 20) {
    await connectDb();
    return Notification.find({ userId }).sort({ createdAt: -1 }).limit(limit).lean();
  },
};
