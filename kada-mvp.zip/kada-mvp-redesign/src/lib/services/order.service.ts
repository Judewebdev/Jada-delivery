import { connectDb } from '@/lib/db';
import { Order, Product, Vendor, User, Rider, type IOrder } from '@/lib/models';
import { HttpError } from '@/lib/auth';
import {
  canTransition, zoneById, slotById, categoryById,
  SERVICE_FEE_RATE, SERVICE_FEE_MIN, LIVE_STATUSES,
  type OrderStatus, type Role,
} from '@/lib/types';
import { PaymentService } from './payment.service';
import { NotificationService } from './notification.service';
import type { Types } from 'mongoose';
import crypto from 'crypto';

/**
 * OrderService. All pricing is recomputed here from the database. A price that
 * arrives from the browser is only ever used to detect a mismatch, never to
 * charge. This is the single most important rule in the payment path.
 */

export interface CartLineInput { productId: string; qty: number }

export interface Quote {
  vendorId: string;
  lines: { productId: string; name: string; unitPriceKobo: number; qty: number }[];
  subtotalKobo: number;
  discountKobo: number;
  deliveryFeeKobo: number;
  serviceFeeKobo: number;
  totalKobo: number;
  commissionKobo: number;
  etaMins: number;
}

export const OrderService = {
  /** Recomputes an authoritative quote from live product and vendor records. */
  async quote(input: { lines: CartLineInput[]; zoneId: string; slotId: string }): Promise<Quote> {
    await connectDb();
    if (!input.lines.length) throw new HttpError(400, 'Your cart is empty.');
    if (input.lines.length > 40) throw new HttpError(400, 'That is too many items for one order.');

    const ids = input.lines.map((l) => l.productId);
    const products = await Product.find({ _id: { $in: ids } }).lean();
    if (products.length !== new Set(ids).size) {
      throw new HttpError(400, 'One of those items is no longer listed.');
    }

    const vendorIds = new Set(products.map((p) => String(p.vendorId)));
    if (vendorIds.size > 1) {
      throw new HttpError(400, 'One order can only contain items from one business.');
    }
    const vendorId = [...vendorIds][0];
    const vendor = await Vendor.findById(vendorId).lean();
    if (!vendor) throw new HttpError(404, 'That business is no longer available.');
    if (vendor.status !== 'active') throw new HttpError(409, `${vendor.name} is not accepting orders right now.`);
    if (!vendor.isOpen) throw new HttpError(409, `${vendor.name} is closed at the moment.`);

    const lines = input.lines.map((l) => {
      const p = products.find((x) => String(x._id) === l.productId)!;
      if (!p.available) throw new HttpError(409, `${p.name} just went out of stock.`);
      const qty = Math.floor(l.qty);
      if (qty < 1 || qty > 20) throw new HttpError(400, 'Quantity must be between 1 and 20.');
      return { productId: String(p._id), name: p.name, unitPriceKobo: p.priceKobo, qty };
    });

    const subtotalKobo = lines.reduce((a, l) => a + l.unitPriceKobo * l.qty, 0);
    const discountKobo = vendor.promoText && subtotalKobo >= 500000 ? Math.round(subtotalKobo * 0.2) : 0;
    const zone = zoneById(input.zoneId);
    const slot = slotById(input.slotId);
    const deliveryFeeKobo = zone.fee;
    const serviceFeeKobo = Math.max(SERVICE_FEE_MIN, Math.round(subtotalKobo * SERVICE_FEE_RATE)) + slot.surcharge;
    const totalKobo = subtotalKobo - discountKobo + deliveryFeeKobo + serviceFeeKobo;
    const commissionKobo = Math.round((subtotalKobo - discountKobo) * (vendor.commissionPct / 100));

    return {
      vendorId,
      lines,
      subtotalKobo,
      discountKobo,
      deliveryFeeKobo,
      serviceFeeKobo,
      totalKobo,
      commissionKobo,
      etaMins: vendor.prepMins + zone.etaMins,
    };
  },

  /** Creates an order in PENDING_PAYMENT and returns the payment handoff. */
  async create(input: {
    userId: string;
    lines: CartLineInput[];
    zoneId: string;
    slotId: string;
    landmark: string;
    paymentMethod: 'wallet' | 'paystack';
    email?: string;
  }) {
    await connectDb();
    const q = await this.quote({ lines: input.lines, zoneId: input.zoneId, slotId: input.slotId });
    const user = await User.findById(input.userId);
    if (!user) throw new HttpError(401, 'Please sign in again.');

    if (input.paymentMethod === 'wallet' && user.walletKobo < q.totalKobo) {
      throw new HttpError(402, 'Your wallet balance is not enough for this order.');
    }

    const reference = PaymentService.newReference();
    const order = await Order.create({
      reference,
      userId: user._id,
      vendorId: q.vendorId,
      lines: q.lines,
      subtotalKobo: q.subtotalKobo,
      discountKobo: q.discountKobo,
      deliveryFeeKobo: q.deliveryFeeKobo,
      serviceFeeKobo: q.serviceFeeKobo,
      totalKobo: q.totalKobo,
      commissionKobo: q.commissionKobo,
      zoneId: input.zoneId,
      landmark: input.landmark || user.landmark || '',
      slotId: input.slotId,
      status: 'PENDING_PAYMENT',
      statusAt: new Date(),
      paymentMethod: input.paymentMethod,
      paymentRef: reference,
      events: [{ status: 'PENDING_PAYMENT', note: 'Order created', byRole: 'customer', byId: String(user._id), at: new Date() }],
    });

    if (input.paymentMethod === 'wallet') {
      user.walletKobo -= q.totalKobo;
      await user.save();
      await this.markPaid(String(order._id), reference, q.totalKobo, 'wallet');
      return { order: await Order.findById(order._id).lean(), redirectUrl: null as string | null };
    }

    const init = await PaymentService.initialize({
      email: input.email || user.email || `${user.phone}@customer.kada.ng`,
      amountKobo: q.totalKobo,
      reference,
      metadata: { orderId: String(order._id), userId: String(user._id) },
    });
    if (!init.ok) {
      order.status = 'FAILED';
      order.cancelReason = init.error ?? 'Could not start payment';
      await order.save();
      throw new HttpError(502, init.error ?? 'We could not start the payment. Please try again.');
    }
    return { order: order.toObject(), redirectUrl: init.authorizationUrl ?? null };
  },

  /** Idempotent. Safe to call from both the verify route and the webhook. */
  async markPaid(orderId: string, reference: string, amountKobo: number, channel: string) {
    await connectDb();
    const order = await Order.findById(orderId);
    if (!order) throw new HttpError(404, 'Order not found.');
    if (order.status !== 'PENDING_PAYMENT') return order.toObject();

    if (amountKobo < order.totalKobo) {
      order.status = 'FAILED';
      order.cancelReason = 'Amount paid did not match the order total';
      await order.save();
      throw new HttpError(400, 'The amount paid did not match this order.');
    }

    order.status = 'PAID';
    order.statusAt = new Date();
    order.paidAt = new Date();
    order.paymentRef = reference;
    order.events.push({ status: 'PAID', note: `Payment confirmed via ${channel}`, byRole: 'system', at: new Date() });
    await order.save();

    await NotificationService.notify({
      userId: order.userId,
      title: `Order ${order.reference} confirmed`,
      body: 'Payment received. The vendor has been notified.',
      kind: 'payment',
      orderId: order._id,
    });
    return order.toObject();
  },

  /** Enforces the shared state machine and role permissions. */
  async transition(opts: {
    orderId: string;
    to: OrderStatus;
    role: Role;
    actorId: string;
    note?: string;
    riderId?: string;
  }) {
    await connectDb();
    const order = await Order.findById(opts.orderId);
    if (!order) throw new HttpError(404, 'Order not found.');

    if (opts.role === 'vendor') {
      const vendor = await Vendor.findById(order.vendorId).select('_id').lean();
      if (!vendor) throw new HttpError(404, 'Vendor not found.');
    }

    if (!canTransition(order.status, opts.to, opts.role)) {
      throw new HttpError(409, `An order that is ${order.status} cannot move to ${opts.to}.`);
    }

    if (opts.to === 'READY_FOR_PICKUP' && !order.pickupCode) {
      order.pickupCode = String(crypto.randomInt(1000, 9999));
    }
    if (opts.to === 'RIDER_ASSIGNED') {
      if (!opts.riderId) throw new HttpError(400, 'A rider is required for this step.');
      order.riderId = opts.riderId as unknown as Types.ObjectId;
    }
    if (opts.to === 'DELIVERED' && order.riderId) {
      const runPay = 150000; // kobo, flat per run for the MVP
      await Rider.findByIdAndUpdate(order.riderId, {
        $inc: { runsCompleted: 1, earnedKobo: runPay },
      });
    }
    if (opts.to === 'CANCELLED') {
      order.cancelReason = opts.note ?? 'Cancelled';
      if (order.paidAt) {
        await User.findByIdAndUpdate(order.userId, { $inc: { walletKobo: order.totalKobo } });
      }
    }

    order.status = opts.to;
    order.statusAt = new Date();
    order.events.push({ status: opts.to, note: opts.note ?? '', byRole: opts.role, byId: opts.actorId, at: new Date() });
    await order.save();

    await NotificationService.notify({
      userId: order.userId,
      title: `Order ${order.reference}`,
      body: opts.note || opts.to,
      kind: 'order_update',
      orderId: order._id,
      alsoSms: opts.to === 'DELIVERED' || opts.to === 'CANCELLED',
    });

    return order.toObject();
  },

  /** Rider confirms possession with the vendor's four digit code. */
  async confirmPickup(orderId: string, code: string, riderId: string) {
    await connectDb();
    const order = await Order.findById(orderId);
    if (!order) throw new HttpError(404, 'Order not found.');
    if (String(order.riderId) !== riderId) throw new HttpError(403, 'This run is not assigned to you.');
    if (!order.pickupCode || order.pickupCode !== code) {
      throw new HttpError(400, 'That code does not match. Ask the vendor to read it again.');
    }
    return this.transition({ orderId, to: 'PICKED_UP', role: 'rider', actorId: riderId, note: 'Pickup code confirmed' });
  },

  async listForUser(userId: string, limit = 25) {
    await connectDb();
    return Order.find({ userId }).sort({ createdAt: -1 }).limit(limit).lean();
  },
  async listForVendor(vendorId: string, limit = 60) {
    await connectDb();
    return Order.find({ vendorId, status: { $ne: 'PENDING_PAYMENT' } })
      .sort({ createdAt: -1 }).limit(limit).lean();
  },
  async listLive(limit = 100): Promise<IOrder[]> {
    await connectDb();
    return Order.find({ status: { $in: LIVE_STATUSES } }).sort({ statusAt: 1 }).limit(limit).lean() as Promise<IOrder[]>;
  },
  async listOffers(zoneId?: string) {
    await connectDb();
    const q: Record<string, unknown> = { status: 'READY_FOR_PICKUP', riderId: { $exists: false } };
    if (zoneId) q.zoneId = zoneId;
    return Order.find(q).sort({ statusAt: 1 }).limit(20).lean();
  },

  categoryCommission: (categoryId: string) => categoryById(categoryId).commission,
};
