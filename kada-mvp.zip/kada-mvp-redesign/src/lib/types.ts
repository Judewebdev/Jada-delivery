/**
 * Domain types shared by every surface. The order state machine defined here is
 * the single source of truth: customer, vendor, rider and ops all read from it,
 * so a status can never mean two different things in two different places.
 */

export type Role = 'customer' | 'vendor' | 'rider' | 'admin';

export const ORDER_STATUSES = [
  'PENDING_PAYMENT',
  'PAID',
  'CONFIRMED',
  'PREPARING',
  'READY_FOR_PICKUP',
  'RIDER_ASSIGNED',
  'PICKED_UP',
  'IN_TRANSIT',
  'DELIVERED',
  'CANCELLED',
  'FAILED',
] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];

/** Who is allowed to move an order out of a given state. */
export const TRANSITIONS: Record<OrderStatus, { to: OrderStatus; by: Role[] }[]> = {
  PENDING_PAYMENT: [
    { to: 'PAID', by: ['admin'] },
    { to: 'FAILED', by: ['admin', 'customer'] },
    { to: 'CANCELLED', by: ['customer', 'admin'] },
  ],
  PAID: [
    { to: 'CONFIRMED', by: ['vendor', 'admin'] },
    { to: 'CANCELLED', by: ['vendor', 'admin'] },
  ],
  CONFIRMED: [
    { to: 'PREPARING', by: ['vendor', 'admin'] },
    { to: 'CANCELLED', by: ['vendor', 'admin'] },
  ],
  PREPARING: [
    { to: 'READY_FOR_PICKUP', by: ['vendor', 'admin'] },
    { to: 'CANCELLED', by: ['admin'] },
  ],
  READY_FOR_PICKUP: [
    { to: 'RIDER_ASSIGNED', by: ['rider', 'admin'] },
    { to: 'CANCELLED', by: ['admin'] },
  ],
  RIDER_ASSIGNED: [
    { to: 'PICKED_UP', by: ['rider', 'admin'] },
    { to: 'READY_FOR_PICKUP', by: ['admin'] },
    { to: 'CANCELLED', by: ['admin'] },
  ],
  PICKED_UP: [
    { to: 'IN_TRANSIT', by: ['rider', 'admin'] },
    { to: 'CANCELLED', by: ['admin'] },
  ],
  IN_TRANSIT: [
    { to: 'DELIVERED', by: ['rider', 'admin'] },
    { to: 'FAILED', by: ['rider', 'admin'] },
  ],
  DELIVERED: [],
  CANCELLED: [],
  FAILED: [{ to: 'CANCELLED', by: ['admin'] }],
};

export function canTransition(from: OrderStatus, to: OrderStatus, role: Role): boolean {
  return TRANSITIONS[from].some((t) => t.to === to && t.by.includes(role));
}

/** Customer-facing labels. Internal status names never reach the UI. */
export const STATUS_COPY: Record<OrderStatus, { title: string; detail: string }> = {
  PENDING_PAYMENT: { title: 'Awaiting payment', detail: 'Complete payment to send this to the vendor' },
  PAID: { title: 'Order received', detail: 'Payment confirmed and sent to the vendor' },
  CONFIRMED: { title: 'Vendor confirmed', detail: 'They accepted your order' },
  PREPARING: { title: 'Preparing', detail: 'Your items are being packed' },
  READY_FOR_PICKUP: { title: 'Ready', detail: 'Waiting for a rider to collect' },
  RIDER_ASSIGNED: { title: 'Rider assigned', detail: 'A rider is on the way to collect' },
  PICKED_UP: { title: 'Picked up', detail: 'Your order is with the rider' },
  IN_TRANSIT: { title: 'On the way', detail: 'Heading to your address' },
  DELIVERED: { title: 'Delivered', detail: 'Enjoy. You can rate and tip' },
  CANCELLED: { title: 'Cancelled', detail: 'This order was cancelled and refunded' },
  FAILED: { title: 'Delivery failed', detail: 'We could not complete this delivery' },
};

/** Progress track shown to customers. Terminal failure states are excluded. */
export const CUSTOMER_TRACK: OrderStatus[] = [
  'PAID', 'CONFIRMED', 'PREPARING', 'RIDER_ASSIGNED', 'PICKED_UP', 'IN_TRANSIT', 'DELIVERED',
];

export const LIVE_STATUSES: OrderStatus[] = [
  'PAID', 'CONFIRMED', 'PREPARING', 'READY_FOR_PICKUP', 'RIDER_ASSIGNED', 'PICKED_UP', 'IN_TRANSIT',
];

/** Vendor categories. The platform is local commerce, not restaurants. */
export const CATEGORIES = [
  { id: 'food', name: 'Food', icon: 'utensils', commission: 13 },
  { id: 'grocery', name: 'Groceries', icon: 'basket', commission: 9 },
  { id: 'pharmacy', name: 'Pharmacy', icon: 'pill', commission: 9 },
  { id: 'essentials', name: 'Essentials', icon: 'box', commission: 9 },
  { id: 'drinks', name: 'Drinks', icon: 'cup', commission: 13 },
  { id: 'bakery', name: 'Bakery', icon: 'bread', commission: 13 },
] as const;
export type CategoryId = (typeof CATEGORIES)[number]['id'];

/** Delivery zones. Fees are flat per zone in kobo. */
export const ZONES = [
  { id: 'gate', name: 'AAU Main Gate', area: 'Campus and faculty blocks', fee: 40000, etaMins: 25 },
  { id: 'emaudo', name: 'Emaudo', area: 'Hostels and junction', fee: 50000, etaMins: 30 },
  { id: 'ujoelen', name: 'Ujoelen', area: 'Ujoelen and Ihumudumu road', fee: 60000, etaMins: 35 },
  { id: 'eguare', name: 'Eguare', area: 'Market and town centre', fee: 70000, etaMins: 40 },
  { id: 'iruekpen', name: 'Iruekpen', area: 'Outer zone', fee: 90000, etaMins: 50 },
] as const;
export type ZoneId = (typeof ZONES)[number]['id'];

export const DISPATCH_SLOTS = [
  { id: 'now', label: 'Send now', detail: 'Next available rider', surcharge: 30000 },
  { id: 's1230', label: '12:30 batch', detail: 'Order before 12:00', surcharge: 0 },
  { id: 's1500', label: '3:00 batch', detail: 'Order before 14:30', surcharge: 0 },
  { id: 's1830', label: '6:30 batch', detail: 'Order before 18:00', surcharge: 0 },
] as const;
export type SlotId = (typeof DISPATCH_SLOTS)[number]['id'];

export const SERVICE_FEE_RATE = 0.06;
export const SERVICE_FEE_MIN = 15000; // kobo
export const FOUNDING_COMMISSION = 10;

export const zoneById = (id: string) => ZONES.find((z) => z.id === id) ?? ZONES[1];
export const categoryById = (id: string) => CATEGORIES.find((c) => c.id === id) ?? CATEGORIES[0];
export const slotById = (id: string) => DISPATCH_SLOTS.find((s) => s.id === id) ?? DISPATCH_SLOTS[1];
