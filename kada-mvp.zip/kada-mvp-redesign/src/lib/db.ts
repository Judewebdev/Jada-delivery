import mongoose from 'mongoose';
import { serverEnv } from './env';

/**
 * Cached Mongoose connection. Serverless functions run cold often, so the
 * connection is memoised on globalThis to avoid opening a socket per request.
 */
type Cache = { conn: typeof mongoose | null; promise: Promise<typeof mongoose> | null };
const globalCache = globalThis as unknown as { _kadaMongo?: Cache };
const cache: Cache = globalCache._kadaMongo ?? { conn: null, promise: null };
globalCache._kadaMongo = cache;

export async function connectDb(): Promise<typeof mongoose> {
  if (cache.conn) return cache.conn;
  if (!cache.promise) {
    cache.promise = mongoose.connect(serverEnv.mongoUri, {
      bufferCommands: false,
      // Serverless: a small pool per instance, kept warm rather than churned.
      maxPoolSize: 5,
      minPoolSize: 0,
      maxIdleTimeMS: 60_000,
      // Fail fast instead of hanging a request for 30 seconds on a bad network.
      serverSelectionTimeoutMS: 5000,
      socketTimeoutMS: 20_000,
      connectTimeoutMS: 5000,
      // Cuts payload size materially on Nigerian mobile backhaul.
      compressors: ['zlib'],
    });
    cache.promise.catch(() => { cache.promise = null; });
  }
  cache.conn = await cache.promise;
  return cache.conn;
}
