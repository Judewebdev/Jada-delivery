/**
 * In-memory fixed-window rate limiter. Adequate for a single-region MVP on
 * Vercel; swap the store for Upstash Redis when traffic justifies it. The
 * interface stays the same, so nothing that calls this needs to change.
 */
type Bucket = { count: number; resetAt: number };
const g = globalThis as unknown as { _kadaBuckets?: Map<string, Bucket> };
const buckets = g._kadaBuckets ?? new Map<string, Bucket>();
g._kadaBuckets = buckets;

export interface LimitResult { ok: boolean; remaining: number; retryAfterSec: number }

export function rateLimit(key: string, max: number, windowSec: number): LimitResult {
  const now = Date.now();
  const b = buckets.get(key);
  if (!b || b.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowSec * 1000 });
    return { ok: true, remaining: max - 1, retryAfterSec: 0 };
  }
  b.count += 1;
  if (b.count > max) {
    return { ok: false, remaining: 0, retryAfterSec: Math.ceil((b.resetAt - now) / 1000) };
  }
  return { ok: true, remaining: max - b.count, retryAfterSec: 0 };
}

export function clientKey(req: Request, suffix: string): string {
  const ip =
    req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
    req.headers.get('x-real-ip') ||
    'unknown';
  return `${ip}:${suffix}`;
}
