import { NextResponse } from 'next/server';
import { APP_COOKIE, OPS_COOKIE, readSession, type SessionPayload } from './session';
import type { Role } from './types';

export class HttpError extends Error {
  constructor(public status: number, message: string, public field?: string) {
    super(message);
  }
}

export const unauthorized = () =>
  NextResponse.json({ error: 'You need to sign in to do that.' }, { status: 401 });
export const forbidden = () =>
  NextResponse.json({ error: 'You do not have access to this.' }, { status: 403 });

/** Requires an app session (customer, vendor or rider) with one of the roles. */
export async function requireRole(...roles: Role[]): Promise<SessionPayload> {
  const s = await readSession(APP_COOKIE);
  if (!s) throw new HttpError(401, 'You need to sign in to do that.');
  if (roles.length && !roles.some((r) => s.roles.includes(r))) {
    throw new HttpError(403, 'You do not have access to this.');
  }
  return s;
}

/** Requires the separate Ops session. Never satisfied by a customer cookie. */
export async function requireAdmin(): Promise<SessionPayload> {
  const s = await readSession(OPS_COOKIE);
  if (!s) throw new HttpError(401, 'Admin sign in required.');
  if (!s.roles.includes('admin')) throw new HttpError(403, 'Admin access required.');
  return s;
}

export function errorResponse(e: unknown) {
  if (e instanceof HttpError) {
    return NextResponse.json({ error: e.message, field: e.field }, { status: e.status });
  }
  // Never leak a stack trace to a user.
  console.error('[kada] unhandled', e);
  return NextResponse.json(
    { error: 'Something went wrong on our side. Please try again.' },
    { status: 500 }
  );
}
