import { SignJWT, jwtVerify } from 'jose';
import { cookies } from 'next/headers';
import { serverEnv } from './env';
import type { Role } from './types';

/**
 * Two independent session cookies. Customer/vendor/rider share one; the Ops
 * console has its own. A customer session can never satisfy an admin check,
 * even if someone edits a cookie value, because the payload is signed and the
 * admin route requires the separate cookie name plus an admin role claim.
 */
export const APP_COOKIE = 'kada_session';
export const OPS_COOKIE = 'kada_ops';

export interface SessionPayload {
  sub: string;          // user id
  roles: Role[];
  name: string;
  vendorId?: string;
  riderId?: string;
}

const key = () => new TextEncoder().encode(serverEnv.sessionSecret);

export async function signSession(payload: SessionPayload, maxAgeSeconds = 60 * 60 * 24 * 30) {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setIssuer('kada')
    .setExpirationTime(Math.floor(Date.now() / 1000) + maxAgeSeconds)
    .sign(key());
}

export async function verifySession(token: string): Promise<SessionPayload | null> {
  try {
    const { payload } = await jwtVerify(token, key(), { issuer: 'kada' });
    if (!payload.sub || !Array.isArray(payload.roles)) return null;
    return {
      sub: String(payload.sub),
      roles: payload.roles as Role[],
      name: String(payload.name ?? ''),
      vendorId: payload.vendorId ? String(payload.vendorId) : undefined,
      riderId: payload.riderId ? String(payload.riderId) : undefined,
    };
  } catch {
    return null;
  }
}

const cookieOptions = (maxAge: number) => ({
  httpOnly: true as const,
  secure: process.env.NODE_ENV === 'production',
  sameSite: 'lax' as const,
  path: '/',
  maxAge,
});

export async function setSessionCookie(name: string, payload: SessionPayload, maxAge = 60 * 60 * 24 * 30) {
  const token = await signSession(payload, maxAge);
  cookies().set(name, token, cookieOptions(maxAge));
}

export function clearSessionCookie(name: string) {
  cookies().set(name, '', { ...cookieOptions(0), maxAge: 0 });
}

export async function readSession(name: string): Promise<SessionPayload | null> {
  const token = cookies().get(name)?.value;
  if (!token) return null;
  return verifySession(token);
}
