/**
 * Environment access. Nothing outside this file reads process.env directly.
 * Public values are inlined at build time; server values are read lazily so a
 * missing credential surfaces as a clear error at call time, not at import time.
 */

function required(name: string, value: string | undefined): string {
  if (!value) {
    throw new Error(
      `Missing environment variable ${name}. Add it in Vercel under Settings > Environment Variables, then redeploy.`
    );
  }
  return value;
}

export const publicEnv = {
  appUrl: process.env.NEXT_PUBLIC_APP_URL ?? 'http://localhost:3000',
  paystackPublicKey: process.env.NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY ?? '',
  googleMapsKey: process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY ?? '',
  brandName: process.env.NEXT_PUBLIC_BRAND_NAME ?? 'KADA',
  city: process.env.NEXT_PUBLIC_CITY ?? 'Ekpoma',
};

export const serverEnv = {
  get mongoUri() { return required('MONGODB_URI', process.env.MONGODB_URI); },
  get sessionSecret() { return required('SESSION_SECRET', process.env.SESSION_SECRET); },
  get paystackSecret() { return required('PAYSTACK_SECRET_KEY', process.env.PAYSTACK_SECRET_KEY); },
  get smsProvider() { return process.env.SMS_PROVIDER ?? 'console'; },
  get smsApiKey() { return process.env.SMS_API_KEY ?? ''; },
  get smsSenderId() { return process.env.SMS_SENDER_ID ?? 'KADA'; },
  get emailProvider() { return process.env.EMAIL_PROVIDER ?? 'console'; },
  get emailApiKey() { return process.env.EMAIL_API_KEY ?? ''; },
  get emailFrom() { return process.env.EMAIL_FROM ?? 'no-reply@kada.ng'; },
  get googleMapsServerKey() { return process.env.GOOGLE_MAPS_SERVER_KEY ?? ''; },
  get adminBootstrapPhone() { return process.env.ADMIN_BOOTSTRAP_PHONE ?? ''; },
};

export const isConfigured = {
  mongo: () => Boolean(process.env.MONGODB_URI),
  paystack: () => Boolean(process.env.PAYSTACK_SECRET_KEY),
  sms: () => Boolean(process.env.SMS_API_KEY),
  email: () => Boolean(process.env.EMAIL_API_KEY),
  maps: () => Boolean(process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY),
};
