import { Schema, model, models, type Model, type Types } from 'mongoose';
import { ORDER_STATUSES, type OrderStatus, type Role } from '@/lib/types';

/* ------------------------------------------------------------------ USER */
export interface IUser {
  _id: Types.ObjectId;
  phone: string;
  name: string;
  email?: string;
  roles: Role[];
  zoneId?: string;
  landmark?: string;
  coords?: { lat: number; lng: number };
  walletKobo: number;
  phoneVerified: boolean;
  vendorId?: Types.ObjectId;
  riderId?: Types.ObjectId;
  createdAt: Date;
  updatedAt: Date;
}
const UserSchema = new Schema<IUser>(
  {
    phone: { type: String, required: true, unique: true, index: true },
    name: { type: String, required: true, trim: true },
    email: { type: String, lowercase: true, trim: true, sparse: true },
    roles: { type: [String], default: ['customer'], index: true },
    zoneId: String,
    landmark: String,
    coords: { lat: Number, lng: Number },
    walletKobo: { type: Number, default: 0, min: 0 },
    phoneVerified: { type: Boolean, default: false },
    vendorId: { type: Schema.Types.ObjectId, ref: 'Vendor' },
    riderId: { type: Schema.Types.ObjectId, ref: 'Rider' },
  },
  { timestamps: true }
);

/* ---------------------------------------------------------------- VENDOR */
export interface IVendor {
  _id: Types.ObjectId;
  name: string;
  ownerName: string;
  phone: string;
  categoryId: string;
  zoneId: string;
  address: string;
  coords?: { lat: number; lng: number };
  isOpen: boolean;
  status: 'pending' | 'active' | 'suspended';
  prepMins: number;
  commissionPct: number;
  rating: number;
  ratingCount: number;
  payoutBank?: string;
  payoutAccountMasked?: string;
  licenceRef?: string;
  promoText?: string;
  createdAt: Date;
  updatedAt: Date;
}
const VendorSchema = new Schema<IVendor>(
  {
    name: { type: String, required: true, trim: true, index: 'text' },
    ownerName: { type: String, required: true },
    phone: { type: String, required: true, index: true },
    categoryId: { type: String, required: true, index: true },
    zoneId: { type: String, required: true, index: true },
    address: { type: String, default: '' },
    coords: { lat: Number, lng: Number },
    isOpen: { type: Boolean, default: false },
    status: { type: String, enum: ['pending', 'active', 'suspended'], default: 'pending', index: true },
    prepMins: { type: Number, default: 25, min: 1, max: 180 },
    commissionPct: { type: Number, default: 10, min: 0, max: 40 },
    rating: { type: Number, default: 0 },
    ratingCount: { type: Number, default: 0 },
    payoutBank: String,
    payoutAccountMasked: String,
    licenceRef: String,
    promoText: String,
  },
  { timestamps: true }
);

/* --------------------------------------------------------------- PRODUCT */
export interface IProduct {
  _id: Types.ObjectId;
  vendorId: Types.ObjectId;
  name: string;
  sku: string;
  description?: string;
  priceKobo: number;
  available: boolean;
  requiresPharmacist: boolean;
  imageUrl?: string;
  icon: string;
  createdAt: Date;
  updatedAt: Date;
}
const ProductSchema = new Schema<IProduct>(
  {
    vendorId: { type: Schema.Types.ObjectId, ref: 'Vendor', required: true, index: true },
    name: { type: String, required: true, trim: true },
    sku: { type: String, required: true, index: true },
    description: String,
    priceKobo: { type: Number, required: true, min: 0 },
    available: { type: Boolean, default: true, index: true },
    requiresPharmacist: { type: Boolean, default: false },
    imageUrl: String,
    icon: { type: String, default: 'box' },
  },
  { timestamps: true }
);
ProductSchema.index({ name: 'text', sku: 'text' });

/* ----------------------------------------------------------------- RIDER */
export interface IRider {
  _id: Types.ObjectId;
  name: string;
  phone: string;
  bike: string;
  zoneId: string;
  online: boolean;
  status: 'pending' | 'active' | 'paused';
  runsCompleted: number;
  completionPct: number;
  rating: number;
  slots: string[];
  earnedKobo: number;
  tipsKobo: number;
  guarantorName?: string;
  guarantorPhone?: string;
  createdAt: Date;
  updatedAt: Date;
}
const RiderSchema = new Schema<IRider>(
  {
    name: { type: String, required: true },
    phone: { type: String, required: true, index: true },
    bike: { type: String, default: '' },
    zoneId: { type: String, required: true, index: true },
    online: { type: Boolean, default: false, index: true },
    status: { type: String, enum: ['pending', 'active', 'paused'], default: 'pending', index: true },
    runsCompleted: { type: Number, default: 0 },
    completionPct: { type: Number, default: 100 },
    rating: { type: Number, default: 0 },
    slots: { type: [String], default: [] },
    earnedKobo: { type: Number, default: 0 },
    tipsKobo: { type: Number, default: 0 },
    guarantorName: String,
    guarantorPhone: String,
  },
  { timestamps: true }
);

/* ----------------------------------------------------------------- ORDER */
export interface IOrderLine {
  productId: Types.ObjectId;
  name: string;
  unitPriceKobo: number;
  qty: number;
}
export interface IOrderEvent {
  status: OrderStatus | 'NOTE';
  note: string;
  byRole: Role | 'system';
  byId?: string;
  at: Date;
}
export interface IOrder {
  _id: Types.ObjectId;
  reference: string;
  userId: Types.ObjectId;
  vendorId: Types.ObjectId;
  riderId?: Types.ObjectId;
  lines: IOrderLine[];
  subtotalKobo: number;
  discountKobo: number;
  deliveryFeeKobo: number;
  serviceFeeKobo: number;
  totalKobo: number;
  commissionKobo: number;
  tipKobo: number;
  zoneId: string;
  landmark: string;
  slotId: string;
  status: OrderStatus;
  statusAt: Date;
  paymentMethod: 'wallet' | 'paystack';
  paymentRef?: string;
  paidAt?: Date;
  pickupCode?: string;
  rating?: number;
  review?: string;
  cancelReason?: string;
  events: IOrderEvent[];
  createdAt: Date;
  updatedAt: Date;
}
const OrderSchema = new Schema<IOrder>(
  {
    reference: { type: String, required: true, unique: true, index: true },
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    vendorId: { type: Schema.Types.ObjectId, ref: 'Vendor', required: true, index: true },
    riderId: { type: Schema.Types.ObjectId, ref: 'Rider', index: true },
    lines: [
      {
        productId: { type: Schema.Types.ObjectId, ref: 'Product', required: true },
        name: { type: String, required: true },
        unitPriceKobo: { type: Number, required: true },
        qty: { type: Number, required: true, min: 1 },
      },
    ],
    subtotalKobo: { type: Number, required: true },
    discountKobo: { type: Number, default: 0 },
    deliveryFeeKobo: { type: Number, required: true },
    serviceFeeKobo: { type: Number, required: true },
    totalKobo: { type: Number, required: true },
    commissionKobo: { type: Number, default: 0 },
    tipKobo: { type: Number, default: 0 },
    zoneId: { type: String, required: true, index: true },
    landmark: { type: String, default: '' },
    slotId: { type: String, default: 's1230' },
    status: { type: String, enum: ORDER_STATUSES, default: 'PENDING_PAYMENT', index: true },
    statusAt: { type: Date, default: Date.now },
    paymentMethod: { type: String, enum: ['wallet', 'paystack'], required: true },
    paymentRef: { type: String, index: true },
    paidAt: Date,
    pickupCode: String,
    rating: Number,
    review: String,
    cancelReason: String,
    events: [
      {
        status: String,
        note: String,
        byRole: String,
        byId: String,
        at: { type: Date, default: Date.now },
      },
    ],
  },
  { timestamps: true }
);
OrderSchema.index({ status: 1, createdAt: -1 });

/* --------------------------------------------------------------- PAYMENT */
export interface IPayment {
  _id: Types.ObjectId;
  orderId: Types.ObjectId;
  userId: Types.ObjectId;
  reference: string;
  provider: 'paystack' | 'wallet';
  amountKobo: number;
  status: 'initialized' | 'success' | 'failed' | 'abandoned';
  rawVerification?: unknown;
  createdAt: Date;
  updatedAt: Date;
}
const PaymentSchema = new Schema<IPayment>(
  {
    orderId: { type: Schema.Types.ObjectId, ref: 'Order', required: true, index: true },
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    reference: { type: String, required: true, unique: true, index: true },
    provider: { type: String, enum: ['paystack', 'wallet'], required: true },
    amountKobo: { type: Number, required: true },
    status: { type: String, enum: ['initialized', 'success', 'failed', 'abandoned'], default: 'initialized', index: true },
    rawVerification: Schema.Types.Mixed,
  },
  { timestamps: true }
);

/* ----------------------------------------------------------- APPLICATION */
export interface IApplication {
  _id: Types.ObjectId;
  type: 'vendor' | 'rider';
  name: string;
  phone: string;
  summary: string;
  documents: string[];
  missing: string[];
  payload: Record<string, unknown>;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: Date;
  updatedAt: Date;
}
const ApplicationSchema = new Schema<IApplication>(
  {
    type: { type: String, enum: ['vendor', 'rider'], required: true, index: true },
    name: { type: String, required: true },
    phone: { type: String, required: true, index: true },
    summary: { type: String, default: '' },
    documents: { type: [String], default: [] },
    missing: { type: [String], default: [] },
    payload: { type: Schema.Types.Mixed, default: {} },
    status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending', index: true },
  },
  { timestamps: true }
);

/* ------------------------------------------------------------- OTP TOKEN */
export interface IOtpToken {
  _id: Types.ObjectId;
  phone: string;
  codeHash: string;
  purpose: 'signin' | 'signup';
  attempts: number;
  consumed: boolean;
  expiresAt: Date;
  createdAt: Date;
}
const OtpTokenSchema = new Schema<IOtpToken>(
  {
    phone: { type: String, required: true, index: true },
    codeHash: { type: String, required: true },
    purpose: { type: String, enum: ['signin', 'signup'], default: 'signin' },
    attempts: { type: Number, default: 0 },
    consumed: { type: Boolean, default: false },
    expiresAt: { type: Date, required: true },
  },
  { timestamps: { createdAt: true, updatedAt: false } }
);
OtpTokenSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

/* --------------------------------------------------------- NOTIFICATION */
export interface INotification {
  _id: Types.ObjectId;
  userId: Types.ObjectId;
  title: string;
  body: string;
  channel: 'push' | 'sms' | 'email' | 'inapp';
  orderId?: Types.ObjectId;
  read: boolean;
  createdAt: Date;
}
const NotificationSchema = new Schema<INotification>(
  {
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    title: { type: String, required: true },
    body: { type: String, default: '' },
    channel: { type: String, enum: ['push', 'sms', 'email', 'inapp'], default: 'inapp' },
    orderId: { type: Schema.Types.ObjectId, ref: 'Order' },
    read: { type: Boolean, default: false },
  },
  { timestamps: { createdAt: true, updatedAt: false } }
);

/* -------------------------------------------------------- MODEL EXPORTS */
export const User: Model<IUser> = models.User || model<IUser>('User', UserSchema);
export const Vendor: Model<IVendor> = models.Vendor || model<IVendor>('Vendor', VendorSchema);
export const Product: Model<IProduct> = models.Product || model<IProduct>('Product', ProductSchema);
export const Rider: Model<IRider> = models.Rider || model<IRider>('Rider', RiderSchema);
export const Order: Model<IOrder> = models.Order || model<IOrder>('Order', OrderSchema);
export const Payment: Model<IPayment> = models.Payment || model<IPayment>('Payment', PaymentSchema);
export const Application: Model<IApplication> =
  models.Application || model<IApplication>('Application', ApplicationSchema);
export const OtpToken: Model<IOtpToken> = models.OtpToken || model<IOtpToken>('OtpToken', OtpTokenSchema);
export const Notification: Model<INotification> =
  models.Notification || model<INotification>('Notification', NotificationSchema);
