import Link from 'next/link';
import { Icon } from '@/components/ui/icon';
import { naira } from '@/lib/money';
import { CATEGORIES, zoneById } from '@/lib/types';

/**
 * Home is a product index, not a store grid.
 *
 * The competitor grammar is: banner carousel, circular category tiles, grid of
 * restaurant photo cards. That grammar assumes photography exists and that the
 * user already knows which shop they want. Neither is true here, and copying it
 * produces a worse version of someone else's app.
 *
 * So: the search field is the hero, results are typographic ledger rows aligned
 * on price, and the centrepiece is the one view a restaurant-first competitor
 * cannot structurally build — the same item priced across several vendors.
 */

/* ------------------------------------------------------------ search hero */
export function NeedComposer({ zoneId }: { zoneId: string }) {
  const zone = zoneById(zoneId);
  return (
    <section className="border-b border-ink-200 px-4 pb-6 pt-5 sm:px-6">
      <div className="mx-auto w-full max-w-[1180px]">
        <div className="flex items-center justify-between gap-3">
          <Link
            href="/shop/account"
            className="inline-flex min-h-[36px] items-center gap-1.5 rounded-full bg-ink-50 px-3 text-[12.5px] font-bold text-ink-600"
          >
            <Icon name="pin" size={14} stroke={2} />
            {zone.name}
            <Icon name="down" size={14} stroke={2} />
          </Link>
          <span className="text-[12.5px] font-semibold text-ink-400">
            {zone.etaMins} min · {naira(zone.fee)}
          </span>
        </div>

        <h1 className="mt-5 text-[clamp(30px,8.5vw,44px)] font-extrabold leading-[1.02] tracking-[-0.04em]">
          I need
          <span className="text-purple-300">…</span>
        </h1>

        <Link
          href="/shop/search"
          className="mt-4 flex min-h-[58px] items-center gap-3 rounded-md border-[1.5px] border-ink-900 bg-white px-4 font-semibold text-ink-400 transition active:scale-[0.99]"
        >
          <Icon name="search" size={20} />
          <span className="flex-1 truncate">paracetamol, rice, bread, jollof</span>
          <span className="hidden rounded-xs bg-ink-900 px-2 py-1 text-[11px] font-extrabold text-white sm:block">
            SEARCH
          </span>
        </Link>

        <div className="no-scrollbar mt-3 flex gap-2 overflow-x-auto">
          {CATEGORIES.map((c) => (
            <Link
              key={c.id}
              href={`/shop/search?category=${c.id}`}
              className="flex min-h-[36px] flex-none items-center gap-2 rounded-full border border-ink-200 px-3 text-[13px] font-bold text-ink-600 transition hover:border-ink-900 hover:text-ink-900"
            >
              <Icon name={c.icon} size={15} stroke={2} />
              {c.name}
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------------------------------------------------- price spread */
export interface Spread {
  sku: string; name: string; icon: string; places: number;
  lowKobo: number; highKobo: number; savingKobo: number;
  cheapestId: string; cheapestVendor: { id: string; name: string };
}

export function PriceSpread({ items }: { items: Spread[] }) {
  if (!items.length) return null;
  return (
    <section className="px-4 py-8 sm:px-6">
      <div className="mx-auto w-full max-w-[1180px]">
        <div className="mb-4 flex items-baseline justify-between gap-3">
          <h2 className="text-[19px] font-extrabold tracking-[-0.022em]">Same item, different price</h2>
          <Link href="/shop/search" className="text-[12.5px] font-bold text-purple-700">Search all</Link>
        </div>

        <div className="grid gap-px overflow-hidden rounded-lg bg-ink-200 sm:grid-cols-2">
          {items.map((s) => (
            <Link
              key={s.sku}
              href={`/shop/search?q=${encodeURIComponent(s.name)}`}
              className="group bg-white p-4 transition hover:bg-ink-25"
            >
              <div className="flex items-start gap-3">
                <span className="grid h-10 w-10 flex-none place-items-center rounded-sm bg-purple-50 text-purple-700">
                  <Icon name={s.icon} size={20} />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[15px] font-bold">{s.name}</p>
                  <p className="mt-0.5 text-[12.5px] text-ink-400">
                    {s.places} places · cheapest at {s.cheapestVendor.name}
                  </p>
                </div>
              </div>

              {/* The spread bar. Low anchored left, high right, saving called out. */}
              <div className="mt-4 flex items-end gap-3">
                <span className="flex-none">
                  <span className="block text-[11px] font-extrabold uppercase tracking-wider text-ok-600">Low</span>
                  <span className="num block text-[19px] font-extrabold leading-tight">{naira(s.lowKobo)}</span>
                </span>
                <span className="relative mb-2 h-[3px] flex-1 rounded-full bg-ink-100">
                  <span className="absolute inset-y-0 left-0 w-1/2 rounded-full bg-gradient-to-r from-ok-600 to-yellow-500" />
                </span>
                <span className="flex-none text-right">
                  <span className="block text-[11px] font-extrabold uppercase tracking-wider text-ink-400">High</span>
                  <span className="num block text-[19px] font-extrabold leading-tight text-ink-400">{naira(s.highKobo)}</span>
                </span>
              </div>

              {s.savingKobo > 0 && (
                <p className="mt-3 inline-flex items-center gap-1.5 rounded-xs bg-yellow-100 px-2 py-1 text-[12px] font-extrabold text-warn-700">
                  Save {naira(s.savingKobo)}
                </p>
              )}
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------ open ledger */
export interface VendorRow {
  id: string; name: string; categoryId: string; isOpen: boolean;
  prepMins: number; rating: number; promoText?: string;
}

export function OpenLedger({ vendors, zoneId }: { vendors: VendorRow[]; zoneId: string }) {
  const zone = zoneById(zoneId);
  const open = vendors.filter((v) => v.isOpen);
  const closed = vendors.filter((v) => !v.isOpen);

  return (
    <section className="px-4 pb-10 sm:px-6">
      <div className="mx-auto w-full max-w-[1180px]">
        <div className="mb-1 flex items-baseline justify-between gap-3 border-b-2 border-ink-900 pb-2">
          <h2 className="text-[19px] font-extrabold tracking-[-0.022em]">Open now</h2>
          <span className="num text-[12.5px] font-bold text-ink-400">{open.length}</span>
        </div>

        {open.length === 0 ? (
          <div className="py-10 text-center">
            <p className="text-[15px] font-bold">Nothing is open right now</p>
            <p className="mx-auto mt-2 max-w-[34ch] text-[13.5px] text-ink-600">
              Most businesses here trade between 8am and 8pm. Search anyway and we will show you who opens next.
            </p>
          </div>
        ) : (
          <ul>
            {open.map((v, i) => (
              <li key={v.id}>
                <Link
                  href={`/shop/store/${v.id}`}
                  className="flex items-center gap-3 border-b border-ink-100 py-3.5 transition hover:bg-ink-25"
                >
                  {/* Index number instead of a photo. Honest, and it scans fast. */}
                  <span className="num w-6 flex-none text-[12.5px] font-extrabold text-ink-300">
                    {String(i + 1).padStart(2, '0')}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-2">
                      <span className="truncate text-[15.5px] font-bold">{v.name}</span>
                      {v.promoText && (
                        <span className="hidden flex-none rounded-xs bg-yellow-100 px-1.5 py-0.5 text-[11px] font-extrabold text-warn-700 sm:inline">
                          Offer
                        </span>
                      )}
                    </span>
                    <span className="mt-0.5 flex items-center gap-2 text-[12.5px] text-ink-400">
                      <span>{CATEGORIES.find((c) => c.id === v.categoryId)?.name}</span>
                      {v.rating > 0 && (
                        <>
                          <span aria-hidden>·</span>
                          <span className="inline-flex items-center gap-1">
                            <Icon name="star" size={12} stroke={2} />
                            {v.rating}
                          </span>
                        </>
                      )}
                    </span>
                  </span>
                  <span className="num flex-none text-right">
                    <span className="block text-[14px] font-extrabold">{v.prepMins + zone.etaMins}<span className="text-[11px] font-bold text-ink-400"> min</span></span>
                    <span className="block text-[12px] text-ink-400">{naira(zone.fee)}</span>
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        )}

        {closed.length > 0 && (
          <details className="mt-6 group">
            <summary className="flex min-h-[44px] cursor-pointer list-none items-center gap-2 text-[13.5px] font-bold text-ink-400">
              <Icon name="down" size={16} stroke={2} />
              {closed.length} closed right now
            </summary>
            <ul className="mt-1">
              {closed.map((v) => (
                <li key={v.id} className="flex items-center gap-3 border-b border-ink-100 py-3 opacity-50">
                  <span className="w-6 flex-none" />
                  <span className="min-w-0 flex-1 truncate text-[15px] font-bold">{v.name}</span>
                  <span className="flex-none text-[12.5px] text-ink-400">Closed</span>
                </li>
              ))}
            </ul>
          </details>
        )}
      </div>
    </section>
  );
}
