/**
 * Skeletons mirror the real layout so the page never jumps when data lands.
 * They are server-rendered as part of the Suspense fallback, which means they
 * appear in the very first byte rather than after hydration.
 */
export function SpreadSkeleton() {
  return (
    <section className="px-4 py-8 sm:px-6" aria-hidden="true">
      <div className="mx-auto w-full max-w-[1180px]">
        <div className="skeleton mb-4 h-5 w-[220px]" />
        <div className="grid gap-px overflow-hidden rounded-lg bg-ink-200 sm:grid-cols-2">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="bg-white p-4">
              <div className="flex gap-3">
                <div className="skeleton h-10 w-10 rounded-sm" />
                <div className="flex-1">
                  <div className="skeleton h-3.5 w-1/2" />
                  <div className="skeleton mt-2 h-2.5 w-3/4" />
                </div>
              </div>
              <div className="skeleton mt-5 h-6 w-full" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function LedgerSkeleton() {
  return (
    <section className="px-4 pb-10 sm:px-6" aria-hidden="true">
      <div className="mx-auto w-full max-w-[1180px]">
        <div className="mb-3 border-b-2 border-ink-900 pb-2">
          <div className="skeleton h-5 w-[120px]" />
        </div>
        {[0, 1, 2, 3, 4].map((i) => (
          <div key={i} className="flex items-center gap-3 border-b border-ink-100 py-4">
            <div className="skeleton h-3 w-5" />
            <div className="flex-1">
              <div className="skeleton h-3.5 w-1/3" />
              <div className="skeleton mt-2 h-2.5 w-1/4" />
            </div>
            <div className="skeleton h-6 w-12" />
          </div>
        ))}
      </div>
    </section>
  );
}

export function PanelSkeleton({ rows = 3 }: { rows?: number }) {
  return (
    <div className="mx-auto w-full max-w-[900px] px-4 pt-5 sm:px-6" aria-hidden="true">
      <div className="skeleton h-7 w-[180px]" />
      <div className="skeleton mt-3 h-3 w-[240px]" />
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="skeleton mt-4 h-[140px] w-full rounded-lg" />
      ))}
    </div>
  );
}
