'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

/**
 * Refreshes the server component every few seconds while an order is live, so
 * a status changed by the vendor or rider appears without a manual reload.
 * Polling is the right tool at this scale; sockets are an optimisation for later.
 */
export function OrderPoller({ active, intervalMs = 6000 }: { active: boolean; intervalMs?: number }) {
  const router = useRouter();
  useEffect(() => {
    if (!active) return;
    const id = setInterval(() => router.refresh(), intervalMs);
    return () => clearInterval(id);
  }, [active, intervalMs, router]);
  return null;
}
