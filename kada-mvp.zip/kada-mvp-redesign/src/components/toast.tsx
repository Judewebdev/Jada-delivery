'use client';

import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';
import { Icon } from './ui/icon';

type Tone = 'ok' | 'error' | 'info';
interface ToastItem { id: number; message: string; tone: Tone }
interface Ctx { toast: (message: string, tone?: Tone) => void }

const ToastCtx = createContext<Ctx>({ toast: () => {} });
export const useToast = () => useContext(ToastCtx);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);

  const toast = useCallback((message: string, tone: Tone = 'ok') => {
    const id = Date.now() + Math.random();
    setItems((prev) => [...prev.slice(-2), { id, message, tone }]);
    setTimeout(() => setItems((prev) => prev.filter((t) => t.id !== id)), 3200);
  }, []);

  const value = useMemo(() => ({ toast }), [toast]);

  return (
    <ToastCtx.Provider value={value}>
      {children}
      <div
        aria-live="polite"
        role="status"
        className="pointer-events-none fixed inset-x-3 bottom-[92px] z-[90] flex flex-col items-center gap-2 sm:bottom-6"
      >
        {items.map((t) => (
          <div
            key={t.id}
            className="flex max-w-[88vw] animate-rise items-center gap-3 rounded-md bg-purple-900 px-4 py-3 text-[13.5px] font-bold text-white shadow-3"
          >
            <Icon name={t.tone === 'error' ? 'alert' : t.tone === 'info' ? 'refresh' : 'check'} size={18} />
            <span>{t.message}</span>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}
