'use client';

import { forwardRef, type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode } from 'react';
import { Icon } from './icon';

/* ------------------------------------------------------------------ utils */
export const cx = (...parts: (string | false | null | undefined)[]) =>
  parts.filter(Boolean).join(' ');

/* ----------------------------------------------------------------- Button */
type Variant = 'primary' | 'accent' | 'soft' | 'outline' | 'ghost' | 'danger' | 'onBrand' | 'ok';
type Size = 'sm' | 'md' | 'lg';

const VARIANTS: Record<Variant, string> = {
  primary: 'bg-purple-700 text-white hover:bg-purple-500',
  accent: 'bg-yellow-500 text-purple-900 hover:bg-yellow-600',
  soft: 'bg-purple-100 text-purple-700 hover:bg-purple-50',
  outline: 'border-[1.5px] border-ink-300 text-ink-900 hover:border-purple-700 hover:text-purple-700',
  ghost: 'text-ink-600 hover:bg-ink-50 hover:text-ink-900',
  danger: 'border-[1.5px] border-ink-200 text-err-600 hover:border-err-600',
  onBrand: 'bg-white/15 text-white hover:bg-white/25',
  ok: 'bg-ok-600 text-white hover:opacity-90',
};
const SIZES: Record<Size, string> = {
  sm: 'min-h-[36px] px-3 text-[13.5px] rounded-sm',
  md: 'min-h-[44px] px-5 text-[15px] rounded-md',
  lg: 'min-h-[54px] px-5 text-[16px] rounded-md',
};

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
  block?: boolean;
  icon?: string;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant = 'primary', size = 'md', loading, block, icon, className, children, disabled, ...rest },
  ref
) {
  return (
    <button
      ref={ref}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      className={cx(
        'relative inline-flex items-center justify-center gap-2 font-bold transition-[background,border-color,transform,color] duration-200 ease-kada',
        'active:scale-[0.975] disabled:cursor-not-allowed disabled:bg-ink-100 disabled:text-ink-400 disabled:border-transparent disabled:active:scale-100',
        VARIANTS[variant], SIZES[size], block && 'flex w-full', className
      )}
      {...rest}
    >
      {loading && (
        <span
          className={cx(
            'absolute h-[18px] w-[18px] animate-spin rounded-full border-2 border-t-transparent',
            variant === 'primary' || variant === 'ok' || variant === 'onBrand'
              ? 'border-white/40 border-t-white'
              : 'border-purple-700/25 border-t-purple-700'
          )}
        />
      )}
      <span className={cx('inline-flex items-center gap-2', loading && 'invisible')}>
        {icon && <Icon name={icon} size={size === 'sm' ? 16 : 18} />}
        {children}
      </span>
    </button>
  );
});

/* ------------------------------------------------------------------ Field */
export interface FieldProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  hint?: string;
  error?: string;
}
export const Field = forwardRef<HTMLInputElement, FieldProps>(function Field(
  { label, hint, error, id, className, ...rest }, ref
) {
  const inputId = id ?? `f-${label.toLowerCase().replace(/\s+/g, '-')}`;
  return (
    <div className="mb-4">
      <label htmlFor={inputId} className="mb-2 block text-[13.5px] font-semibold">{label}</label>
      <input
        ref={ref}
        id={inputId}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? `${inputId}-err` : hint ? `${inputId}-hint` : undefined}
        className={cx(
          'w-full min-h-[44px] rounded-sm border-[1.5px] bg-white px-4 py-3 outline-none transition-[border-color,box-shadow] duration-200 ease-kada',
          'placeholder:text-ink-400 hover:border-ink-300 focus:border-purple-700 focus:shadow-[0_0_0_3px_theme(colors.purple.100)]',
          error ? 'border-err-600 focus:border-err-600 focus:shadow-[0_0_0_3px_theme(colors.err.50)]' : 'border-ink-200',
          className
        )}
        {...rest}
      />
      {error ? (
        <p id={`${inputId}-err`} role="alert" className="mt-2 text-xs font-bold text-err-600">{error}</p>
      ) : hint ? (
        <p id={`${inputId}-hint`} className="mt-2 text-xs text-ink-400">{hint}</p>
      ) : null}
    </div>
  );
});

/* ------------------------------------------------------------------- Card */
export function Card({ children, className, tone = 'plain' }: {
  children: ReactNode; className?: string;
  tone?: 'plain' | 'flat' | 'brand' | 'warn' | 'ok' | 'bad';
}) {
  const tones = {
    plain: 'border border-ink-200 bg-white',
    flat: 'bg-ink-50',
    brand: 'bg-purple-700 text-white sig',
    warn: 'border border-yellow-200 bg-warn-50',
    ok: 'border border-ok-600/25 bg-ok-50',
    bad: 'border border-err-600/25 bg-err-50',
  };
  return <div className={cx('rounded-lg p-4', tones[tone], className)}>{children}</div>;
}

/* -------------------------------------------------------------------- Tag */
export function Tag({ children, tone = 'plain', className }: {
  children: ReactNode; tone?: 'plain' | 'brand' | 'accent' | 'ok' | 'err' | 'onBrand'; className?: string;
}) {
  const tones = {
    plain: 'bg-ink-100 text-ink-600',
    brand: 'bg-purple-100 text-purple-700',
    accent: 'bg-yellow-200 text-warn-700',
    ok: 'bg-ok-50 text-ok-600',
    err: 'bg-err-50 text-err-600',
    onBrand: 'bg-white/15 text-white',
  };
  return (
    <span className={cx('inline-flex items-center gap-1 whitespace-nowrap rounded-full px-2 py-1 text-xs font-extrabold', tones[tone], className)}>
      {children}
    </span>
  );
}

/* --------------------------------------------------------------- Skeleton */
export function Skeleton({ className }: { className?: string }) {
  return <div className={cx('skeleton', className)} aria-hidden="true" />;
}

/* ------------------------------------------------------------ StateScreen */
export function StateScreen({ icon, title, body, action, tone = 'neutral' }: {
  icon: string; title: string; body: string; action?: ReactNode; tone?: 'neutral' | 'error';
}) {
  return (
    <div className="px-5 py-9 text-center" role={tone === 'error' ? 'alert' : undefined}>
      <span className={cx(
        'mx-auto mb-4 grid h-14 w-14 place-items-center rounded-md',
        tone === 'error' ? 'bg-err-50 text-err-600' : 'bg-purple-100 text-purple-700'
      )}>
        <Icon name={icon} size={26} />
      </span>
      <h2 className="text-[19px] font-extrabold tracking-[-0.022em]">{title}</h2>
      <p className="mx-auto mt-2 max-w-[34ch] text-[13.5px] leading-relaxed text-ink-600">{body}</p>
      {action && <div className="mt-5 flex justify-center">{action}</div>}
    </div>
  );
}

/* ------------------------------------------------------------------ Sheet */
export function Sheet({ open, onClose, title, children }: {
  open: boolean; onClose: () => void; title: string; children: ReactNode;
}) {
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-[80] flex animate-fade items-end justify-center bg-ink-900/50 sm:items-center"
      onClick={onClose}
      role="presentation"
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        onClick={(e) => e.stopPropagation()}
        className="max-h-[88dvh] w-full max-w-[520px] animate-rise overflow-y-auto rounded-t-xl bg-white p-5 shadow-3 sm:rounded-xl"
      >
        <div className="mb-4 flex items-start justify-between gap-3">
          <h2 className="text-[19px] font-extrabold tracking-[-0.022em]">{title}</h2>
          <button onClick={onClose} aria-label="Close" className="tap grid w-11 place-items-center rounded-sm hover:bg-ink-50">
            <Icon name="close" size={20} />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

/* --------------------------------------------------------------- Selector */
export function Selector({ checked, onClick, title, sub, right, icon, multiple }: {
  checked: boolean; onClick: () => void; title: string; sub?: string;
  right?: ReactNode; icon?: string; multiple?: boolean;
}) {
  return (
    <button
      type="button"
      role={multiple ? 'checkbox' : 'radio'}
      aria-checked={checked}
      onClick={onClick}
      className={cx(
        'mb-2 flex w-full items-center gap-3 rounded-md border-[1.5px] px-4 py-3 text-left transition-[border-color,background] duration-200 ease-kada tap',
        checked ? 'border-purple-700 bg-purple-50' : 'border-ink-200 hover:border-ink-300'
      )}
    >
      <span className={cx(
        'grid h-[22px] w-[22px] flex-none place-items-center border-2 text-white',
        multiple ? 'rounded-xs' : 'rounded-full',
        checked ? 'border-purple-700 bg-purple-700' : 'border-ink-300'
      )}>
        {checked && <Icon name="check" size={13} stroke={3} />}
      </span>
      {icon && (
        <span className="grid h-[38px] w-[38px] flex-none place-items-center rounded-sm bg-ink-50 text-purple-700">
          <Icon name={icon} />
        </span>
      )}
      <span className="min-w-0 flex-1">
        <span className="block text-[14.5px] font-bold">{title}</span>
        {sub && <span className="block text-xs text-ink-400">{sub}</span>}
      </span>
      {right}
    </button>
  );
}
