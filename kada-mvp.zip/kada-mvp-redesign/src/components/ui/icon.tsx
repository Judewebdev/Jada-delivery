/**
 * One icon family. 24px grid, 1.75 stroke, currentColor. Mixing icon sets is
 * the fastest way to make a product look assembled from parts.
 */
const PATHS: Record<string, string> = {
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.6-3.6"/>',
  pin: '<path d="M12 21s7-5.6 7-11a7 7 0 1 0-14 0c0 5.4 7 11 7 11Z"/><circle cx="12" cy="10" r="2.5"/>',
  bell: '<path d="M6 9a6 6 0 1 1 12 0c0 4.5 2 6 2 6H4s2-1.5 2-6Z"/><path d="M10 19.5a2.2 2.2 0 0 0 4 0"/>',
  home: '<path d="M4 11 12 4l8 7v8a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1Z"/>',
  receipt: '<path d="M6 3.5h12v17l-3-1.8-3 1.8-3-1.8-3 1.8Z"/><path d="M9 8.5h6M9 12.5h6"/>',
  wallet: '<rect x="3" y="6" width="18" height="13" rx="3"/><path d="M3 10h18"/><circle cx="16.5" cy="14.5" r="1.2"/>',
  user: '<circle cx="12" cy="8" r="3.5"/><path d="M5 20c0-3.6 3.1-6 7-6s7 2.4 7 6"/>',
  users: '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-5.5 6-5.5s6 2.2 6 5.5"/><path d="M16 5.4a3.2 3.2 0 0 1 0 6M17.5 14.8c2.1.6 3.5 2.4 3.5 5.2"/>',
  plus: '<path d="M12 5.5v13M5.5 12h13"/>',
  minus: '<path d="M5.5 12h13"/>',
  left: '<path d="M15 5.5 8.5 12 15 18.5"/>',
  right: '<path d="M9 5.5 15.5 12 9 18.5"/>',
  down: '<path d="M6 9.5 12 15.5 18 9.5"/>',
  check: '<path d="M5 12.5 10 17.5 19 7"/>',
  clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.2V12l3 2"/>',
  bike: '<circle cx="6" cy="17" r="3.2"/><circle cx="18" cy="17" r="3.2"/><path d="M9 17h4l3.5-7M13 7h3M6.5 17l4-8"/>',
  store: '<path d="M4 9.5h16V20a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1Z"/><path d="M3 9.5 4.6 4.5h14.8L21 9.5"/><path d="M9.5 9.5V4.5M14.5 9.5V4.5"/>',
  utensils: '<path d="M6.5 3v7a2 2 0 0 0 4 0V3M8.5 10v11"/><path d="M16.5 3c-1.5 1-2 3-2 5.5s.8 3.5 2 3.5V21"/>',
  basket: '<path d="M4.5 9.5h15L18 20H6Z"/><path d="M8.5 9.5 11 3.5M15.5 9.5 13 3.5"/>',
  pill: '<path d="M9.6 4.4a4.5 4.5 0 0 1 6.4 6.4l-5.2 5.2a4.5 4.5 0 0 1-6.4-6.4Z"/><path d="M7 7 14 14"/>',
  cup: '<path d="M6 8h11l-1 10.5a2 2 0 0 1-2 1.8H9a2 2 0 0 1-2-1.8Z"/><path d="M17 10.5h2a2 2 0 1 1 0 4h-2"/>',
  bread: '<path d="M4.5 12c0-3.6 3.4-6 7.5-6s7.5 2.4 7.5 6v5.5a1.5 1.5 0 0 1-1.5 1.5H6a1.5 1.5 0 0 1-1.5-1.5Z"/><path d="M9 9.5v9M14 9.5v9"/>',
  box: '<path d="M12 3.2 20 7.6v8.8L12 20.8 4 16.4V7.6Z"/><path d="M4 7.6 12 12l8-4.4M12 12v8.8"/>',
  phone: '<rect x="7" y="2.8" width="10" height="18.4" rx="2.5"/><path d="M11 18h2"/>',
  call: '<path d="M6.5 3.5h3l1.5 4-2 1.5a12 12 0 0 0 6 6l1.5-2 4 1.5v3a2 2 0 0 1-2.2 2A16.5 16.5 0 0 1 4.5 5.7 2 2 0 0 1 6.5 3.5Z"/>',
  cart: '<circle cx="9.5" cy="19.5" r="1.4"/><circle cx="17" cy="19.5" r="1.4"/><path d="M3 4h2.2l2.6 11h10L20.5 7.5H6"/>',
  shield: '<path d="M12 3.2 19 6v6c0 4.4-2.9 7.3-7 8.8-4.1-1.5-7-4.4-7-8.8V6Z"/><path d="M9.2 11.8 11.4 14l3.6-3.8"/>',
  star: '<path d="m12 3.6 2.6 5.3 5.9.9-4.3 4.1 1 5.8-5.2-2.7-5.2 2.7 1-5.8L3.5 9.8l5.9-.9Z"/>',
  alert: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.6v5M12 16.2h.01"/>',
  close: '<path d="M6 6l12 12M18 6 6 18"/>',
  spark: '<path d="M12 3.5 13.7 9l5.5 1.7-5.5 1.7L12 18l-1.7-5.6L4.8 10.7 10.3 9Z"/>',
  refresh: '<path d="M20 12a8 8 0 1 1-2.6-5.9"/><path d="M20 4v5h-5"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  calendar: '<rect x="3.5" y="5" width="17" height="16" rx="3"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
  inbox: '<path d="M3.5 13.5 6 5.5h12l2.5 8v5a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2Z"/><path d="M3.5 13.5H9a3 3 0 0 0 6 0h5.5"/>',
  settings: '<circle cx="12" cy="12" r="3.2"/><path d="M12 2.5v3M12 18.5v3M21.5 12h-3M5.5 12h-3M18.7 5.3l-2.1 2.1M7.4 16.6l-2.1 2.1M18.7 18.7l-2.1-2.1M7.4 7.4 5.3 5.3"/>',
  money: '<rect x="2.5" y="6" width="19" height="12" rx="2.5"/><circle cx="12" cy="12" r="2.6"/><path d="M6 12h.01M18 12h.01"/>',
  logout: '<path d="M14 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8"/><path d="M17 8.5 20.5 12 17 15.5M20.5 12H10"/>',
};

export type IconName = keyof typeof PATHS | string;

export function Icon({ name, size = 20, stroke = 1.75, className = '' }: {
  name: IconName; size?: number; stroke?: number; className?: string;
}) {
  return (
    <svg
      width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
      strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round"
      aria-hidden="true" className={className}
      dangerouslySetInnerHTML={{ __html: PATHS[name] ?? '' }}
    />
  );
}
