'use client';

import { useState } from 'react';
import { useCart, type CartLine } from './cart';
import { useToast } from './toast';
import { Icon } from './ui/icon';
import { Sheet, Button } from './ui';

/**
 * Add and quantity control. One order can only contain one business, so a
 * conflicting add asks first rather than silently discarding the cart.
 */
export function AddToCart({ product, compact, disabled }: {
  product: Omit<CartLine, 'qty'>; compact?: boolean; disabled?: boolean;
}) {
  const cart = useCart();
  const { toast } = useToast();
  const [conflict, setConflict] = useState(false);
  const line = cart.lines.find((l) => l.productId === product.productId);
  const size = compact ? 30 : 38;

  if (line) {
    return (
      <div className="flex flex-none items-center gap-3">
        <button
          onClick={() => cart.setQty(product.productId, line.qty - 1)}
          aria-label={`Remove one ${product.name}`}
          className="grid h-[34px] w-[34px] place-items-center rounded-sm bg-purple-100 text-purple-700 active:scale-90"
        ><Icon name="minus" size={16} /></button>
        <b className="num min-w-[16px] text-center">{line.qty}</b>
        <button
          onClick={() => cart.setQty(product.productId, line.qty + 1)}
          aria-label={`Add one ${product.name}`}
          className="grid h-[34px] w-[34px] place-items-center rounded-sm bg-purple-100 text-purple-700 active:scale-90"
        ><Icon name="plus" size={16} /></button>
      </div>
    );
  }

  return (
    <>
      <button
        disabled={disabled}
        onClick={() => {
          const r = cart.add(product);
          if (r === 'conflict') setConflict(true);
          else toast(`${product.name} added`);
        }}
        aria-label={disabled ? `${product.name} unavailable` : `Add ${product.name} to cart`}
        style={{ width: size, height: size }}
        className="grid flex-none place-items-center rounded-sm bg-purple-700 text-white transition active:scale-90 disabled:bg-ink-100 disabled:text-ink-400 disabled:active:scale-100"
      >
        <Icon name="plus" size={compact ? 16 : 18} />
      </button>

      <Sheet open={conflict} onClose={() => setConflict(false)} title="Start a new cart?">
        <p className="text-[13.5px] leading-relaxed text-ink-600">
          Your cart has items from {cart.lines[0]?.vendorName}. Adding {product.name} from {product.vendorName} will
          clear it. One order, one business, so it arrives together.
        </p>
        <Button
          block size="lg" className="mt-5"
          onClick={() => { cart.replaceWith(product); setConflict(false); toast('New cart started'); }}
        >Start new cart</Button>
        <Button block variant="ghost" className="mt-2" onClick={() => setConflict(false)}>Keep my cart</Button>
      </Sheet>
    </>
  );
}
