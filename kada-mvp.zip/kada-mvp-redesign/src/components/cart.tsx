'use client';

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';

/**
 * Cart lives on the client because it is a draft, not a record. It is
 * deliberately thin: it holds product ids and quantities only. Every price the
 * customer is charged is recomputed server-side at quote and at order time.
 */
export interface CartLine { productId: string; qty: number; name: string; priceKobo: number; vendorId: string; vendorName: string }
interface Ctx {
  lines: CartLine[];
  vendorId: string | null;
  count: number;
  subtotalKobo: number;
  add: (line: Omit<CartLine, 'qty'>) => 'added' | 'conflict';
  setQty: (productId: string, qty: number) => void;
  clear: () => void;
  replaceWith: (line: Omit<CartLine, 'qty'>) => void;
  ready: boolean;
}

const KEY = 'kada.cart.v1';
const CartCtx = createContext<Ctx | null>(null);

export function useCart(): Ctx {
  const c = useContext(CartCtx);
  if (!c) throw new Error('useCart must be used inside CartProvider');
  return c;
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(KEY);
      if (raw) setLines(JSON.parse(raw) as CartLine[]);
    } catch { /* storage can be blocked; the cart just starts empty */ }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    try { window.localStorage.setItem(KEY, JSON.stringify(lines)); } catch { /* ignore */ }
  }, [lines, ready]);

  const vendorId = lines[0]?.vendorId ?? null;

  const add = useCallback((line: Omit<CartLine, 'qty'>) => {
    let result: 'added' | 'conflict' = 'added';
    setLines((prev) => {
      if (prev.length && prev[0].vendorId !== line.vendorId) { result = 'conflict'; return prev; }
      const found = prev.find((l) => l.productId === line.productId);
      if (found) return prev.map((l) => (l.productId === line.productId ? { ...l, qty: Math.min(20, l.qty + 1) } : l));
      return [...prev, { ...line, qty: 1 }];
    });
    return result;
  }, []);

  const setQty = useCallback((productId: string, qty: number) => {
    setLines((prev) =>
      qty <= 0 ? prev.filter((l) => l.productId !== productId)
               : prev.map((l) => (l.productId === productId ? { ...l, qty: Math.min(20, qty) } : l))
    );
  }, []);

  const clear = useCallback(() => setLines([]), []);
  const replaceWith = useCallback((line: Omit<CartLine, 'qty'>) => setLines([{ ...line, qty: 1 }]), []);

  const value = useMemo<Ctx>(() => ({
    lines, vendorId, ready,
    count: lines.reduce((a, l) => a + l.qty, 0),
    subtotalKobo: lines.reduce((a, l) => a + l.priceKobo * l.qty, 0),
    add, setQty, clear, replaceWith,
  }), [lines, vendorId, ready, add, setQty, clear, replaceWith]);

  return <CartCtx.Provider value={value}>{children}</CartCtx.Provider>;
}
