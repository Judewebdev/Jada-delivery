'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from './ui';
import { api } from '@/lib/api-client';

export function SignOutButton({ surface = 'app', className }: { surface?: 'app' | 'ops'; className?: string }) {
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  return (
    <Button
      variant="danger" block loading={busy} className={className}
      onClick={async () => {
        setBusy(true);
        try { await api(`/api/auth/signout?surface=${surface}`, { method: 'POST' }); } catch { /* sign out anyway */ }
        router.push(surface === 'ops' ? '/ops/signin' : '/');
        router.refresh();
      }}
    >
      Sign out
    </Button>
  );
}
