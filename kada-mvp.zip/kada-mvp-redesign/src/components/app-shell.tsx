'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Icon } from './ui/icon';
import { useCart } from './cart';
import { naira } from '@/lib/money';

export interface NavItem { href: string; icon: string; label: string }

/**
 * Shared shell. Bottom tab bar on mobile, side rail from 1024px. Desktop is not
 * a stretched phone: the rail replaces the tab bar and content gains a max width
 * rather than spreading across the viewport.
 */
export function AppShell({
  nav, children, title, showCart = false,
}: { nav: NavItem[]; children: React.ReactNode; title: string; showCart?: boolean }) {
  const pathname = usePathname();
  const cart = useCart();
  const active = (href: string) => pathname === href || (href !== '/shop' && pathname.startsWith(href));

  return (
    <div className="flex min-h-dvh bg-white">
      <nav aria-label="Main" className="sticky top-0 hidden h-dvh w-[240px] flex-none flex-col overflow-y-auto border-r border-ink-200 px-3 py-6 lg:flex">
        <Link href="/" className="flex items-baseline px-3 pb-8 text-[22px] font-extrabold tracking-[-0.05em] text-purple-700">
          kada<span className="ml-1 h-[7px] w-[7px] rounded-full bg-yellow-500" aria-hidden />
          <span className="ml-2 text-[11px] font-extrabold uppercase tracking-wider text-ink-400">{title}</span>
        </Link>
        {nav.map((n) => (
          <Link
            key={n.href} href={n.href}
            aria-current={active(n.href) ? 'page' : undefined}
            className={`mb-0.5 flex min-h-[46px] items-center gap-3 rounded-sm px-3 font-bold transition ${
              active(n.href) ? 'bg-purple-700 text-white' : 'text-ink-600 hover:bg-ink-50 hover:text-ink-900'
            }`}
          >
            <Icon name={n.icon} size={21} />
            {n.label}
          </Link>
        ))}
      </nav>

      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex-1 pb-24 lg:pb-12">{children}</div>
      </div>

      {showCart && cart.count > 0 && (
        <Link
          href="/shop/cart"
          className="fixed inset-x-3 bottom-[84px] z-[55] flex min-h-[56px] animate-rise items-center gap-3 rounded-md bg-purple-700 px-4 text-white shadow-3 lg:inset-x-auto lg:bottom-6 lg:right-6 lg:w-[340px]"
        >
          <span className="rounded-xs bg-white/20 px-2 py-0.5 text-[13px] font-extrabold">{cart.count}</span>
          <b className="num flex-1">{naira(cart.subtotalKobo)}</b>
          <span className="text-[13.5px] font-extrabold">View cart</span>
          <Icon name="right" size={18} />
        </Link>
      )}

      <nav aria-label="Main" className="safe-bottom fixed inset-x-0 bottom-0 z-[60] flex border-t border-ink-200 bg-white pt-2 lg:hidden">
        {nav.map((n) => (
          <Link
            key={n.href} href={n.href}
            aria-current={active(n.href) ? 'page' : undefined}
            className={`relative flex min-h-[44px] flex-1 flex-col items-center justify-center gap-0.5 text-[11px] font-bold ${
              active(n.href) ? 'text-purple-700' : 'text-ink-400'
            }`}
          >
            <Icon name={n.icon} size={22} />
            {n.label}
          </Link>
        ))}
      </nav>
    </div>
  );
}
