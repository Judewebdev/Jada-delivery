import Link from 'next/link';
import { Icon } from '@/components/ui/icon';
import { CATEGORIES } from '@/lib/types';
import { publicEnv } from '@/lib/env';

export const dynamic = 'force-static';

const TRUST = [
  ['shield', 'Prepaid, riders carry no cash'],
  ['clock', 'Refunds land in minutes'],
  ['money', 'Every fee shown before you pay'],
] as const;

const PILLARS = [
  ['money', 'You see the whole price', 'Item price, delivery fee, service fee, total. Nothing is added at your door, because there is nothing to add.'],
  ['shield', 'Nobody carries cash', 'Every order is prepaid, so a refund never depends on chasing a rider. It reverses to your wallet in minutes.'],
  ['bike', 'One rider, several drops', 'Orders in the same zone share a run. That is what makes delivery affordable in a town this size.'],
] as const;

export default function Landing() {
  return (
    <div className="min-h-dvh">
      <header className="sticky top-0 z-50 border-b border-transparent bg-white/90 backdrop-blur-md">
        <div className="mx-auto flex h-[60px] w-full max-w-[1180px] items-center gap-3 px-4 sm:px-6">
          <Link href="/" className="flex items-baseline text-[21px] font-extrabold tracking-[-0.05em] text-purple-700">
            {publicEnv.brandName.toLowerCase()}
            <span className="ml-1 h-[7px] w-[7px] rounded-full bg-yellow-500" aria-hidden />
          </Link>
          <nav className="ml-6 hidden gap-5 md:flex" aria-label="Sections">
            <a href="#how" className="text-sm font-semibold text-ink-600 hover:text-purple-700">How it works</a>
            <a href="#join" className="text-sm font-semibold text-ink-600 hover:text-purple-700">Join</a>
          </nav>
          <div className="ml-auto flex items-center gap-2">
            <Link href="/join?mode=signin" className="hidden min-h-[36px] items-center rounded-sm px-3 text-[13.5px] font-bold text-ink-600 hover:bg-ink-50 sm:inline-flex">
              Sign in
            </Link>
            <Link href="/join" className="inline-flex min-h-[36px] items-center rounded-sm bg-purple-700 px-3 text-[13.5px] font-bold text-white">
              Start an order
            </Link>
          </div>
        </div>
      </header>

      <main>
        <section className="mx-auto grid w-full max-w-[1180px] items-center gap-8 px-4 py-8 sm:px-6 lg:grid-cols-[1.05fr_.95fr] lg:py-16">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full bg-purple-50 px-3 py-1.5 text-xs font-extrabold text-purple-700">
              <span className="h-[7px] w-[7px] animate-pulseDot rounded-full bg-ok-600" aria-hidden />
              Live in {publicEnv.city}
            </span>
            <h1 className="mt-4 text-[clamp(31px,8.4vw,54px)] font-extrabold leading-[1.03] tracking-[-0.04em]">
              Search the{' '}
              <span className="relative whitespace-nowrap text-purple-700">
                <span className="absolute inset-x-[-2px] bottom-[0.05em] -z-10 h-[0.28em] rounded-[3px] bg-yellow-500" aria-hidden />
                product
              </span>
              , not the shop.
            </h1>
            <p className="mt-4 max-w-[46ch] text-base leading-relaxed text-ink-600">
              Food, medicine, groceries and everyday essentials from the businesses already around you.
              One checkout, one rider network, one price you can see before you pay.
            </p>
            <div className="mt-5 flex flex-col gap-2 sm:flex-row">
              <Link href="/join" className="inline-flex min-h-[54px] items-center justify-center rounded-md bg-purple-700 px-5 font-bold text-white transition active:scale-[0.98]">
                Start an order
              </Link>
              <Link href="#join" className="inline-flex min-h-[54px] items-center justify-center rounded-md border-[1.5px] border-ink-300 px-5 font-bold transition hover:border-purple-700 hover:text-purple-700">
                Sell or ride with us
              </Link>
            </div>
            <ul className="mt-5 flex flex-wrap gap-x-4 gap-y-2">
              {TRUST.map(([icon, text]) => (
                <li key={text} className="flex items-center gap-1.5 text-[12.5px] font-semibold text-ink-600">
                  <span className="text-ok-600"><Icon name={icon} size={15} stroke={2} /></span>
                  {text}
                </li>
              ))}
            </ul>
          </div>

          <div className="overflow-hidden rounded-xl border border-ink-200 shadow-2">
            <div className="bg-purple-700 p-4">
              <div className="flex min-h-[50px] items-center gap-3 rounded-md bg-white px-4">
                <span className="text-ink-400"><Icon name="search" /></span>
                <span className="font-bold">Paracetamol</span>
              </div>
            </div>
            <div className="p-4">
              <p className="mb-3 text-[11.5px] font-extrabold uppercase tracking-wider text-ink-400">
                Available in 2 places
              </p>
              {[
                { v: 'Grace Chemist', p: '₦450', best: true },
                { v: 'Rehoboth Pharmacy', p: '₦500', best: false },
              ].map((o) => (
                <div
                  key={o.v}
                  className={`mb-2 flex items-center gap-3 rounded-md border p-3 ${o.best ? 'border-purple-700 bg-purple-50' : 'border-ink-200'}`}
                >
                  <span className="grid h-10 w-10 flex-none place-items-center rounded-sm bg-ink-50 text-purple-300">
                    <Icon name="pill" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-2">
                      <b className="text-[14.5px]">{o.v}</b>
                      {o.best && <span className="rounded-full bg-yellow-200 px-2 py-0.5 text-xs font-extrabold text-warn-700">Best price</span>}
                    </span>
                    <span className="mt-0.5 block text-xs text-ink-400">In stock · about 35 min</span>
                  </span>
                  <b className="num text-[15px]">{o.p}</b>
                </div>
              ))}
              <p className="mt-3 text-xs text-ink-400">
                Two pharmacies, two prices. You see both before you open either one.
              </p>
            </div>
          </div>
        </section>

        <section id="how" className="mx-auto w-full max-w-[1180px] px-4 py-12 sm:px-6">
          <p className="mb-3 text-[11.5px] font-extrabold uppercase tracking-[0.08em] text-purple-300">Not a food app</p>
          <h2 className="text-[clamp(24px,6vw,36px)] font-extrabold leading-tight tracking-[-0.035em]">
            Everything a household actually buys.
          </h2>
          <div className="mt-5 grid grid-cols-3 gap-2 sm:grid-cols-6">
            {CATEGORIES.map((c) => (
              <div key={c.id} className="flex flex-col items-center gap-2 rounded-md p-3">
                <span className="grid h-12 w-12 place-items-center rounded-md bg-purple-100 text-purple-700">
                  <Icon name={c.icon} size={22} />
                </span>
                <span className="text-center text-[11.5px] font-bold leading-tight">{c.name}</span>
              </div>
            ))}
          </div>
          <div className="mt-5 grid gap-3 md:grid-cols-3">
            {PILLARS.map(([icon, title, body]) => (
              <div key={title} className="rounded-lg border border-ink-200 p-5">
                <span className="mb-3 grid h-11 w-11 place-items-center rounded-md bg-purple-100 text-purple-700">
                  <Icon name={icon} size={22} />
                </span>
                <b className="text-[15.5px]">{title}</b>
                <p className="mt-2 text-[13.5px] leading-relaxed text-ink-600">{body}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="join" className="mx-auto w-full max-w-[1180px] px-4 pb-16 sm:px-6">
          <div className="rounded-xl bg-purple-700 px-5 py-12 text-center text-white sm:px-8">
            <p className="mb-3 text-[11.5px] font-extrabold uppercase tracking-[0.08em] text-yellow-500">Join</p>
            <h2 className="mx-auto max-w-[20ch] text-[clamp(24px,6vw,36px)] font-extrabold leading-tight tracking-[-0.035em]">
              No signup fee. No monthly fee. Paid every Monday.
            </h2>
            <p className="mx-auto mt-4 max-w-[52ch] text-[15px] leading-relaxed text-white/75">
              10% commission for your first 90 days, then 13%. Nothing on delivery fees, nothing on tips.
              We publish the rate before you sign.
            </p>
            <div className="mt-6 flex flex-col justify-center gap-2 sm:flex-row">
              <Link href="/join?role=vendor" className="inline-flex min-h-[54px] items-center justify-center rounded-md bg-yellow-500 px-5 font-bold text-purple-900">
                Register a business
              </Link>
              <Link href="/join?role=rider" className="inline-flex min-h-[54px] items-center justify-center rounded-md bg-white/15 px-5 font-bold text-white">
                Apply as a rider
              </Link>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-ink-200 py-8">
        <div className="mx-auto flex w-full max-w-[1180px] flex-col gap-2 px-4 text-[13.5px] text-ink-400 sm:px-6">
          <span className="text-[19px] font-extrabold tracking-[-0.05em] text-purple-700">
            {publicEnv.brandName.toLowerCase()}
          </span>
          <p>Local commerce, delivered. Built in {publicEnv.city}, for {publicEnv.city} first.</p>
        </div>
      </footer>
    </div>
  );
}
