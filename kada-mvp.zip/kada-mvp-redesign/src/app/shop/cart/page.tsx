'use client';

import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useCart } from '@/components/cart';
import { useToast } from '@/components/toast';
import { api, ApiError } from '@/lib/api-client';
import { naira } from '@/lib/money';
import { Icon } from '@/components/ui/icon';
import { Button, Card, Selector, Skeleton, StateScreen } from '@/components/ui';
import { ZONES, DISPATCH_SLOTS } from '@/lib/types';

interface Quote {
  subtotalKobo: number; discountKobo: number; deliveryFeeKobo: number;
  serviceFeeKobo: number; totalKobo: number; etaMins: number;
}
interface Me {
  user: { id: string; name: string; zoneId?: string; landmark?: string; walletKobo: number } | null;
}

export default function CartPage() {
  const cart = useCart();
  const router = useRouter();
  const { toast } = useToast();

  const [me, setMe] = useState<Me['user']>(null);
  const [zoneId, setZoneId] = useState('emaudo');
  const [slotId, setSlotId] = useState('s1230');
  const [landmark, setLandmark] = useState('');
  const [method, setMethod] = useState<'wallet' | 'paystack'>('paystack');
  const [quote, setQuote] = useState<Quote | null>(null);
  const [quoting, setQuoting] = useState(false);
  const [quoteError, setQuoteError] = useState<string | null>(null);
  const [placing, setPlacing] = useState(false);

  useEffect(() => {
    api<Me>('/api/auth/me').then((r) => {
      setMe(r.user);
      if (r.user?.zoneId) setZoneId(r.user.zoneId);
      if (r.user?.landmark) setLandmark(r.user.landmark);
    }).catch(() => undefined);
  }, []);

  const refreshQuote = useCallback(() => {
    if (!cart.lines.length) { setQuote(null); return; }
    setQuoting(true); setQuoteError(null);
    api<Quote>('/api/orders/quote', {
      method: 'POST',
      json: { lines: cart.lines.map((l) => ({ productId: l.productId, qty: l.qty })), zoneId, slotId },
    })
      .then(setQuote)
      .catch((e: ApiError) => { setQuote(null); setQuoteError(e.message); })
      .finally(() => setQuoting(false));
  }, [cart.lines, zoneId, slotId]);

  useEffect(() => { refreshQuote(); }, [refreshQuote]);

  async function placeOrder() {
    setPlacing(true);
    try {
      const r = await api<{ order: { _id: string }; redirectUrl: string | null }>('/api/orders', {
        method: 'POST',
        json: {
          lines: cart.lines.map((l) => ({ productId: l.productId, qty: l.qty })),
          zoneId, slotId, landmark, paymentMethod: method,
        },
      });
      cart.clear();
      if (r.redirectUrl) { window.location.href = r.redirectUrl; return; }
      toast('Payment successful');
      router.push(`/shop/orders/${r.order._id}`);
    } catch (e) {
      toast((e as ApiError).message, 'error');
      refreshQuote();
    } finally { setPlacing(false); }
  }

  if (!cart.ready) {
    return <div className="mx-auto max-w-[720px] px-4 pt-6"><Skeleton className="h-24 w-full rounded-lg" /></div>;
  }

  if (!cart.lines.length) {
    return (
      <div className="mx-auto w-full max-w-[720px] px-4 pt-4 sm:px-6">
        <h1 className="text-[25px] font-extrabold tracking-[-0.03em]">Your cart</h1>
        <StateScreen
          icon="cart" title="Your cart is empty"
          body="Add something from a business near you and it will show up here."
          action={<Link href="/shop" className="inline-flex min-h-[44px] items-center rounded-md bg-purple-700 px-5 font-bold text-white">Start exploring</Link>}
        />
      </div>
    );
  }

  const walletShort = method === 'wallet' && quote && me && me.walletKobo < quote.totalKobo;

  return (
    <div className="mx-auto w-full max-w-[720px] px-4 pt-3 sm:px-6">
      <div className="mb-4 flex items-center gap-2">
        <Link href="/shop" aria-label="Back" className="grid h-11 w-11 place-items-center rounded-sm hover:bg-ink-50">
          <Icon name="left" size={22} />
        </Link>
        <div>
          <h1 className="text-[25px] font-extrabold tracking-[-0.03em]">Checkout</h1>
          <p className="text-xs text-ink-400">{cart.lines[0].vendorName}</p>
        </div>
      </div>

      <h2 className="mb-1 text-[11.5px] font-extrabold uppercase tracking-wider text-ink-400">Your order</h2>
      {cart.lines.map((l) => (
        <div key={l.productId} className="flex items-center gap-3 border-b border-ink-200 py-3">
          <span className="min-w-0 flex-1">
            <span className="block text-[15.5px] font-bold">{l.name}</span>
            <span className="text-xs text-ink-600">{naira(l.priceKobo)} each</span>
          </span>
          <span className="flex flex-none items-center gap-3">
            <button onClick={() => cart.setQty(l.productId, l.qty - 1)} aria-label={`Remove one ${l.name}`}
              className="grid h-[34px] w-[34px] place-items-center rounded-sm bg-purple-100 text-purple-700 active:scale-90">
              <Icon name="minus" size={16} />
            </button>
            <b className="num min-w-[16px] text-center">{l.qty}</b>
            <button onClick={() => cart.setQty(l.productId, l.qty + 1)} aria-label={`Add one ${l.name}`}
              className="grid h-[34px] w-[34px] place-items-center rounded-sm bg-purple-100 text-purple-700 active:scale-90">
              <Icon name="plus" size={16} />
            </button>
          </span>
          <b className="num w-[76px] text-right">{naira(l.priceKobo * l.qty)}</b>
        </div>
      ))}

      <section className="pt-8">
        <h2 className="mb-3 text-[19px] font-extrabold tracking-[-0.022em]">Delivery</h2>
        {ZONES.map((z) => (
          <Selector key={z.id} checked={zoneId === z.id} onClick={() => setZoneId(z.id)}
            title={z.name} sub={z.area} right={<b className="num text-[13.5px]">{naira(z.fee)}</b>} />
        ))}
        <label className="mb-2 mt-4 block text-[13.5px] font-semibold" htmlFor="landmark">Landmark</label>
        <input
          id="landmark" value={landmark} onChange={(e) => setLandmark(e.target.value)}
          placeholder="e.g. Peace Lodge, opposite Zenith"
          className="min-h-[44px] w-full rounded-sm border-[1.5px] border-ink-200 px-4 outline-none focus:border-purple-700"
        />

        <h3 className="mb-2 mt-5 text-[11.5px] font-extrabold uppercase tracking-wider text-ink-400">Dispatch slot</h3>
        {DISPATCH_SLOTS.map((s) => (
          <Selector key={s.id} checked={slotId === s.id} onClick={() => setSlotId(s.id)}
            title={s.label} sub={s.surcharge ? `${s.detail} · +${naira(s.surcharge)}` : s.detail} />
        ))}
        <p className="text-xs text-ink-400">
          Batched slots share one rider across several drops in the same zone, so they cost less and move faster.
        </p>
      </section>

      <section className="pt-8">
        <h2 className="mb-3 text-[19px] font-extrabold tracking-[-0.022em]">Payment</h2>
        <Selector
          checked={method === 'paystack'} onClick={() => setMethod('paystack')} icon="money"
          title="Card or bank transfer" sub="Secured by Paystack"
        />
        <Selector
          checked={method === 'wallet'} onClick={() => setMethod('wallet')} icon="wallet"
          title="KADA wallet" sub={me ? `${naira(me.walletKobo)} available` : 'Loading…'}
        />
        {walletShort && (
          <Card tone="warn">
            <p className="text-[13.5px]">
              <b>Your balance is short by {naira(quote!.totalKobo - me!.walletKobo)}.</b> Pay by card or transfer instead.
            </p>
          </Card>
        )}
        <p className="mt-2 text-xs text-ink-400">
          KADA is prepaid. Riders carry no cash, so nothing is negotiated at your door.
        </p>
      </section>

      <section className="pt-8">
        <h2 className="mb-1 text-[19px] font-extrabold tracking-[-0.022em]">Summary</h2>
        {quoteError ? (
          <Card tone="bad">
            <p className="text-[13.5px]"><b>{quoteError}</b></p>
            <Button variant="outline" size="sm" className="mt-3" onClick={refreshQuote}>Try again</Button>
          </Card>
        ) : quoting && !quote ? (
          <div className="py-2">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="mb-3 h-4 w-full" />)}</div>
        ) : quote ? (
          <>
            {[
              ['Subtotal', quote.subtotalKobo],
              ...(quote.discountKobo ? [['Discount', -quote.discountKobo] as [string, number]] : []),
              ['Delivery', quote.deliveryFeeKobo],
              ['Service fee', quote.serviceFeeKobo],
            ].map(([label, value]) => (
              <div key={label as string} className="flex justify-between border-b border-ink-200 py-3">
                <span className="text-ink-600">{label as string}</span>
                <b className={`num ${(value as number) < 0 ? 'text-ok-600' : ''}`}>
                  {(value as number) < 0 ? `−${naira(-(value as number))}` : naira(value as number)}
                </b>
              </div>
            ))}
            <div className="mt-2 flex justify-between border-t-2 border-ink-900 pt-4 text-[18px] font-extrabold">
              <span>Total</span><span className="num">{naira(quote.totalKobo)}</span>
            </div>
            <p className="mt-3 text-xs text-ink-400">
              This is the final amount. Nothing is added at your door. Arrives in about {quote.etaMins} minutes.
            </p>
          </>
        ) : null}
      </section>

      <Button
        size="lg" block className="mt-6" loading={placing}
        disabled={!quote || Boolean(walletShort) || quoting}
        onClick={() => void placeOrder()}
      >
        {quote ? `Pay ${naira(quote.totalKobo)}` : 'Calculating…'}
      </Button>
      <p className="mt-3 text-center text-xs text-ink-400">
        Prices are recalculated on our server before you are charged.
      </p>
      <div className="h-16" />
    </div>
  );
}
