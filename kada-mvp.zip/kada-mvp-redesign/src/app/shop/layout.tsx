import { redirect } from 'next/navigation';
import { readSession, APP_COOKIE } from '@/lib/session';
import { AppShell } from '@/components/app-shell';

export const dynamic = 'force-dynamic';

const NAV = [
  { href: '/shop', icon: 'home', label: 'Home' },
  { href: '/shop/search', icon: 'search', label: 'Search' },
  { href: '/shop/orders', icon: 'receipt', label: 'Orders' },
  { href: '/shop/account', icon: 'user', label: 'Account' },
];

export default async function ShopLayout({ children }: { children: React.ReactNode }) {
  const session = await readSession(APP_COOKIE);
  if (!session) redirect('/join');
  return <AppShell nav={NAV} title="Shop" showCart>{children}</AppShell>;
}
