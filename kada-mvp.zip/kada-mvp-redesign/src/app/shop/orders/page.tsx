import Link from 'next/link';
import { readSession, APP_COOKIE } from '@/lib/session';
import { OrderService } from '@/lib/services/order.service';
import { STATUS_COPY, type OrderStatus } from '@/lib/types';
import { naira } from '@/lib/money';
import { Icon } from '@/components/ui/icon';
import { StateScreen, Tag } from '@/components/ui';

export const dynamic = 'force-dynamic';

export default async function OrdersPage() {
  const session = await readSession(APP_COOKIE);
  const orders = await OrderService.listForUser(session!.sub);

  return (
    <div className="mx-auto w-full max-w-[820px] px-4 pt-5 sm:px-6">
      <h1 className="text-[25px] font-extrabold tracking-[-0.03em]">Orders</h1>
      {orders.length === 0 ? (
        <StateScreen
          icon="receipt"
          title="You have not ordered anything yet"
          body="Once you place an order it appears here, and you can follow it from payment to your door."
          action={<Link href="/shop" className="inline-flex min-h-[44px] items-center rounded-md bg-purple-700 px-5 font-bold text-white">Start exploring</Link>}
        />
      ) : (
        <div className="mt-4 space-y-3">
          {orders.map((o) => {
            const copy = STATUS_COPY[o.status as OrderStatus];
            const tone = o.status === 'DELIVERED' ? 'ok' : ['CANCELLED', 'FAILED'].includes(o.status) ? 'err' : 'accent';
            return (
              <Link key={String(o._id)} href={`/shop/orders/${String(o._id)}`}
                className="flex items-center gap-3 rounded-lg border border-ink-200 p-4 transition hover:border-ink-300">
                <span className="grid h-11 w-11 flex-none place-items-center rounded-sm bg-purple-100 text-purple-700">
                  <Icon name={o.status === 'DELIVERED' ? 'check' : 'bike'} size={22} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="flex flex-wrap items-center gap-2">
                    <b className="num text-[15px]">{o.reference}</b>
                    <Tag tone={tone}>{copy.title}</Tag>
                  </span>
                  <span className="mt-1 block text-xs text-ink-400">
                    {o.lines.length} item{o.lines.length > 1 ? 's' : ''} · {naira(o.totalKobo)}
                  </span>
                </span>
                <Icon name="right" size={18} />
              </Link>
            );
          })}
        </div>
      )}
      <div className="h-10" />
    </div>
  );
}
