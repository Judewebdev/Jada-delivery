import Link from 'next/link';
import { notFound, redirect } from 'next/navigation';
import { connectDb } from '@/lib/db';
import { Order, Vendor, Rider } from '@/lib/models';
import { readSession, APP_COOKIE } from '@/lib/session';
import { CUSTOMER_TRACK, STATUS_COPY, slotById, type OrderStatus } from '@/lib/types';
import { naira } from '@/lib/money';
import { Icon } from '@/components/ui/icon';
import { Card, Tag } from '@/components/ui';
import { OrderPoller } from '@/components/order-poller';

export const dynamic = 'force-dynamic';

export default async function OrderPage({ params }: { params: { id: string } }) {
  if (!/^[a-f0-9]{24}$/i.test(params.id)) notFound();
  const session = await readSession(APP_COOKIE);
  if (!session) redirect('/join');

  await connectDb();
  const order = await Order.findById(params.id).lean();
  if (!order) notFound();
  // Ownership is checked server-side. A guessed id returns nothing.
  if (String(order.userId) !== session.sub) notFound();

  const [vendor, rider] = await Promise.all([
    Vendor.findById(order.vendorId).select('name phone').lean(),
    order.riderId ? Rider.findById(order.riderId).select('name bike phone').lean() : null,
  ]);

  const status = order.status as OrderStatus;
  const idx = CUSTOMER_TRACK.indexOf(status);
  const terminal = ['CANCELLED', 'FAILED'].includes(status);
  const pct = idx >= 0 ? (idx / (CUSTOMER_TRACK.length - 1)) * 100 : 0;

  return (
    <div className="mx-auto w-full max-w-[720px] px-4 pt-3 sm:px-6">
      <OrderPoller active={!terminal && status !== 'DELIVERED'} />

      <div className="mb-4 flex items-center gap-2">
        <Link href="/shop/orders" aria-label="Back" className="grid h-11 w-11 place-items-center rounded-sm hover:bg-ink-50">
          <Icon name="left" size={22} />
        </Link>
        <div>
          <h1 className="num text-[25px] font-extrabold tracking-[-0.03em]">{order.reference}</h1>
          <p className="text-xs text-ink-400">{vendor?.name}</p>
        </div>
      </div>

      {terminal ? (
        <Card tone="bad">
          <h2 className="text-[19px] font-extrabold">{STATUS_COPY[status].title}</h2>
          <p className="mt-2 text-[13.5px] text-ink-600">
            {order.cancelReason || STATUS_COPY[status].detail}. {naira(order.totalKobo)} has been returned to your wallet.
          </p>
        </Card>
      ) : (
        <Card tone="brand" className="p-6">
          <p className="text-[13.5px] text-white/70">{status === 'DELIVERED' ? 'Delivered' : 'Status'}</p>
          <div className="mt-1 text-[30px] font-extrabold tracking-[-0.035em]">{STATUS_COPY[status].title}</div>
          <div className="mt-4 h-1.5 overflow-hidden rounded-full bg-white/20">
            <div className="h-full rounded-full bg-yellow-500 transition-[width] duration-500" style={{ width: `${pct}%` }} />
          </div>
          <p className="mt-3 text-xs text-white/70">{STATUS_COPY[status].detail}</p>
        </Card>
      )}

      {rider && (
        <Card className="mt-4">
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 flex-none place-items-center rounded-full bg-purple-100 text-purple-700">
              <Icon name="bike" size={22} />
            </span>
            <span className="min-w-0 flex-1">
              <b className="block">{rider.name}</b>
              <span className="text-xs text-ink-400">{rider.bike}</span>
            </span>
            <a href={`tel:${rider.phone}`} className="inline-flex min-h-[36px] items-center gap-2 rounded-sm bg-purple-100 px-3 text-[13.5px] font-bold text-purple-700">
              <Icon name="call" size={16} /> Call
            </a>
          </div>
        </Card>
      )}

      {!terminal && (
        <ol className="mt-8 space-y-0">
          {CUSTOMER_TRACK.map((s, i) => {
            const state = i < idx ? 'done' : i === idx ? 'now' : 'todo';
            return (
              <li key={s} className="relative flex gap-4 pb-5 last:pb-0">
                {i < CUSTOMER_TRACK.length - 1 && (
                  <span className={`absolute left-[11px] top-[26px] bottom-0 w-0.5 ${state === 'done' ? 'bg-ok-600' : 'bg-ink-200'}`} aria-hidden />
                )}
                <span className={`z-10 grid h-6 w-6 flex-none place-items-center rounded-full border-2 text-white ${
                  state === 'done' ? 'border-ok-600 bg-ok-600' : state === 'now' ? 'border-purple-700 bg-purple-700' : 'border-ink-200 bg-white'
                }`}>
                  {state === 'done' && <Icon name="check" size={13} stroke={3} />}
                </span>
                <span className={state === 'todo' ? 'text-ink-400' : ''}>
                  <b className={`block text-[15px] ${state === 'now' ? 'text-purple-700' : ''}`}>{STATUS_COPY[s].title}</b>
                  <span className="text-xs">{STATUS_COPY[s].detail}</span>
                </span>
              </li>
            );
          })}
        </ol>
      )}

      <Card tone="flat" className="mt-6">
        {order.lines.map((l) => (
          <div key={String(l.productId)} className="flex justify-between border-b border-ink-200 py-2.5 last:border-0 text-[13.5px]">
            <span className="text-ink-600">{l.qty} × {l.name}</span>
            <b className="num">{naira(l.unitPriceKobo * l.qty)}</b>
          </div>
        ))}
      </Card>

      <Card className="mt-3">
        <div className="flex justify-between border-b border-ink-200 py-3"><span className="text-ink-600">Paid with</span><b>{order.paymentMethod === 'wallet' ? 'KADA wallet' : 'Card or transfer'}</b></div>
        <div className="flex justify-between border-b border-ink-200 py-3"><span className="text-ink-600">Dispatch slot</span><b>{slotById(order.slotId).label}</b></div>
        <div className="flex justify-between py-3"><span className="text-ink-600">Total</span><b className="num">{naira(order.totalKobo)}</b></div>
      </Card>

      {order.pickupCode && ['READY_FOR_PICKUP', 'RIDER_ASSIGNED'].includes(status) && (
        <p className="mt-4 text-center text-xs text-ink-400">
          <Tag tone="brand">Your rider confirms a code with the vendor before collecting</Tag>
        </p>
      )}
      <div className="h-16" />
    </div>
  );
}
