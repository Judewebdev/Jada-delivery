import Link from 'next/link';
import { connectDb } from '@/lib/db';
import { User } from '@/lib/models';
import { readSession, APP_COOKIE } from '@/lib/session';
import { zoneById } from '@/lib/types';
import { naira } from '@/lib/money';
import { Card } from '@/components/ui';
import { Icon } from '@/components/ui/icon';
import { SignOutButton } from '@/components/sign-out';

export const dynamic = 'force-dynamic';

export default async function AccountPage() {
  const session = await readSession(APP_COOKIE);
  await connectDb();
  const user = await User.findById(session!.sub).select('name phone zoneId landmark walletKobo roles').lean();
  const zone = zoneById(user?.zoneId ?? 'emaudo');

  return (
    <div className="mx-auto w-full max-w-[720px] px-4 pt-5 sm:px-6">
      <h1 className="text-[25px] font-extrabold tracking-[-0.03em]">Account</h1>

      <Card tone="brand" className="mt-4 p-6">
        <p className="text-[13.5px] text-white/70">Wallet balance</p>
        <div className="mt-1 text-[30px] font-extrabold tracking-[-0.035em]">{naira(user?.walletKobo ?? 0)}</div>
        <p className="mt-4 text-xs leading-relaxed text-white/70">
          Refunds land here within minutes. Top up is coming once the wallet funding flow is live; until then card and
          transfer at checkout work today.
        </p>
      </Card>

      <Card className="mt-4">
        {[['Name', user?.name], ['Phone', user?.phone], ['Zone', zone.name], ['Landmark', user?.landmark || 'Not set']].map(([k, v]) => (
          <div key={k as string} className="flex justify-between border-b border-ink-200 py-3 last:border-0">
            <span className="text-ink-600">{k as string}</span><b>{v as string}</b>
          </div>
        ))}
      </Card>

      <section className="pt-8">
        <h2 className="mb-2 text-[11.5px] font-extrabold uppercase tracking-wider text-ink-400">Grow with KADA</h2>
        {[
          { href: '/join?role=vendor', icon: 'store', title: 'Sell on KADA', sub: 'Restaurants, pharmacies, shops and services' },
          { href: '/join?role=rider', icon: 'bike', title: 'Ride with KADA', sub: 'Earn on runs between your normal trips' },
        ].map((l) => (
          <Link key={l.href} href={l.href}
            className="mb-2 flex min-h-[44px] items-center gap-3 rounded-md border-[1.5px] border-ink-200 px-4 py-3 hover:border-ink-300">
            <span className="grid h-[38px] w-[38px] flex-none place-items-center rounded-sm bg-ink-50 text-purple-700">
              <Icon name={l.icon} />
            </span>
            <span className="flex-1">
              <b className="block text-[14.5px]">{l.title}</b>
              <span className="text-xs text-ink-400">{l.sub}</span>
            </span>
            <Icon name="right" size={18} />
          </Link>
        ))}
      </section>

      <SignOutButton className="mt-8" />
      <div className="h-16" />
    </div>
  );
}
