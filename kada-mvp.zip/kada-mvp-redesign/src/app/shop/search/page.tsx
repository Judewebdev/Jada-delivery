'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import Link from 'next/link';
import { api } from '@/lib/api-client';
import { naira } from '@/lib/money';
import { Icon } from '@/components/ui/icon';
import { Skeleton, StateScreen, Tag } from '@/components/ui';
import { AddToCart } from '@/components/add-to-cart';
import type { SearchResult } from '@/lib/services/catalog.service';

const POPULAR = ['Paracetamol', 'Jollof rice', 'Milk', 'Bottled water', 'Toothpaste', 'Bread'];

export default function SearchPage() {
  const [q, setQ] = useState('');
  const [tab, setTab] = useState<'products' | 'businesses'>('products');
  const [data, setData] = useState<SearchResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { inputRef.current?.focus(); }, []);

  useEffect(() => {
    const term = q.trim();
    if (term.length < 2) { setData(null); setError(null); return; }
    setLoading(true);
    const t = setTimeout(() => {
      api<SearchResult>(`/api/catalog/search?q=${encodeURIComponent(term)}`)
        .then((r) => { setData(r); setError(null); })
        .catch((e: Error) => setError(e.message))
        .finally(() => setLoading(false));
    }, 220);
    return () => clearTimeout(t);
  }, [q]);

  const counts = useMemo(() => ({
    products: data?.groups.reduce((a, g) => a + g.offers.length, 0) ?? 0,
    businesses: data?.vendors.length ?? 0,
  }), [data]);

  return (
    <div className="mx-auto w-full max-w-[1180px] px-4 pt-4 sm:px-6">
      <div className="mb-2 flex items-center gap-2">
        <Link href="/shop" aria-label="Back" className="grid h-11 w-11 flex-none place-items-center rounded-sm hover:bg-ink-50">
          <Icon name="left" size={22} />
        </Link>
        <div className="flex min-h-[52px] flex-1 items-center gap-3 rounded-md border-[1.5px] border-purple-700 bg-white px-4 shadow-[0_0_0_3px_theme(colors.purple.100)]">
          <Icon name="search" size={20} />
          <input
            ref={inputRef}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="What are you looking for?"
            aria-label="Search products and businesses"
            className="min-w-0 flex-1 bg-transparent font-semibold outline-none"
          />
          {q && (
            <button onClick={() => setQ('')} aria-label="Clear search" className="grid h-8 w-8 place-items-center rounded-sm hover:bg-ink-50">
              <Icon name="close" size={18} />
            </button>
          )}
        </div>
      </div>

      {q.trim().length < 2 ? (
        <section className="pt-6">
          <h2 className="mb-3 text-[11.5px] font-extrabold uppercase tracking-wider text-ink-400">Popular searches</h2>
          <div className="flex flex-wrap gap-2">
            {POPULAR.map((p) => (
              <button
                key={p} onClick={() => setQ(p)}
                className="min-h-[36px] rounded-full border-[1.5px] border-ink-200 px-4 text-[13.5px] font-bold text-ink-600 hover:border-purple-700 hover:text-purple-700"
              >{p}</button>
            ))}
          </div>
          <p className="mt-6 max-w-[46ch] text-[13.5px] leading-relaxed text-ink-600">
            Search the product, not the shop. Type paracetamol and you get every pharmacy that stocks it,
            cheapest first, without opening a single store page.
          </p>
        </section>
      ) : error ? (
        <StateScreen
          tone="error" icon="alert" title="Something went wrong while searching"
          body={error}
          action={<button onClick={() => setQ((s) => s + ' ')} className="min-h-[44px] rounded-md bg-purple-700 px-5 font-bold text-white">Try again</button>}
        />
      ) : loading && !data ? (
        <div className="pt-6">
          {[0, 1, 2].map((i) => (
            <div key={i} className="mb-3 flex items-center gap-3 rounded-md border border-ink-200 p-3">
              <Skeleton className="h-10 w-10 rounded-sm" />
              <div className="flex-1"><Skeleton className="h-3 w-1/2" /><Skeleton className="mt-2 h-2.5 w-3/4" /></div>
            </div>
          ))}
        </div>
      ) : (
        <>
          <div className="my-3 flex gap-2">
            {(['products', 'businesses'] as const).map((t) => (
              <button
                key={t} aria-pressed={tab === t} onClick={() => setTab(t)}
                className={`min-h-[36px] rounded-full border-[1.5px] px-4 text-[13.5px] font-bold capitalize transition ${
                  tab === t ? 'border-purple-700 bg-purple-700 text-white' : 'border-ink-200 text-ink-600'
                }`}
              >{t} ({counts[t]})</button>
            ))}
          </div>

          {tab === 'products' ? (
            counts.products === 0 ? (
              <StateScreen icon="search" title={`No products matched "${q}"`} body="Try a shorter word, or one of the popular searches." />
            ) : (
              data!.groups.map((g) => (
                <section key={g.sku} className="mt-6">
                  <div className="mb-1 flex items-baseline justify-between border-b-2 border-ink-900 pb-2">
                    <h3 className="text-[15.5px] font-bold">{g.name}</h3>
                    <span className="text-xs text-ink-400">{g.offers.length} place{g.offers.length > 1 ? 's' : ''}</span>
                  </div>
                  {g.offers.map((o, i) => {
                    const buyable = o.available && o.vendor.isOpen;
                    return (
                      <div
                        key={o.id}
                        className={`flex items-center gap-3 border-b border-ink-200 py-3 ${
                          i === 0 && g.offers.length > 1 ? 'rounded-md border-b-0 bg-purple-50 px-3' : ''
                        }`}
                      >
                        <span className="grid h-11 w-11 flex-none place-items-center rounded-sm bg-ink-50 text-purple-300">
                          <Icon name={o.icon} size={20} />
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="flex flex-wrap items-center gap-2">
                            <Link href={`/shop/store/${o.vendor.id}`} className="text-[14.5px] font-bold hover:text-purple-700">
                              {o.vendor.name}
                            </Link>
                            {i === 0 && g.offers.length > 1 && buyable && <Tag tone="accent">Best price</Tag>}
                          </span>
                          <span className="mt-1 flex flex-wrap items-center gap-2 text-xs text-ink-400">
                            {buyable ? <Tag tone="ok">In stock</Tag> : <Tag tone="err">{o.vendor.isOpen ? 'Out of stock' : 'Closed'}</Tag>}
                            <span>{o.vendor.prepMins + 30} min</span>
                          </span>
                          {o.requiresPharmacist && (
                            <span className="mt-1.5 block"><Tag tone="brand">Pharmacist confirms by phone</Tag></span>
                          )}
                        </span>
                        <span className="flex-none text-right">
                          <b className="num block text-[15px]">{naira(o.priceKobo)}</b>
                          <span className="mt-1.5 flex justify-end">
                            <AddToCart
                              disabled={!buyable}
                              product={{
                                productId: o.id, name: o.name, priceKobo: o.priceKobo,
                                vendorId: o.vendor.id, vendorName: o.vendor.name,
                              }}
                            />
                          </span>
                        </span>
                      </div>
                    );
                  })}
                </section>
              ))
            )
          ) : counts.businesses === 0 ? (
            <StateScreen icon="store" title="No businesses matched" body="Try searching for the product instead." />
          ) : (
            <div className="grid gap-3 md:grid-cols-2">
              {data!.vendors.map((v) => (
                <Link key={v.id} href={`/shop/store/${v.id}`} className="flex items-center gap-3 rounded-lg border border-ink-200 p-3 hover:border-ink-300">
                  <span className="grid h-12 w-12 flex-none place-items-center rounded-md bg-purple-100 text-purple-700">
                    <Icon name="store" size={22} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <b className="block truncate text-[15px]">{v.name}</b>
                    <span className="text-xs text-ink-400">{v.isOpen ? 'Open' : 'Closed'} · {v.prepMins} min prep</span>
                  </span>
                  <Icon name="right" size={18} />
                </Link>
              ))}
            </div>
          )}
        </>
      )}
      <div className="h-10" />
    </div>
  );
}
