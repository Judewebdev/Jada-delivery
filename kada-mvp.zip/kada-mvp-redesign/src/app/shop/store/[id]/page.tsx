import Link from 'next/link';
import { notFound } from 'next/navigation';
import { CatalogService } from '@/lib/services/catalog.service';
import { CATEGORIES, zoneById } from '@/lib/types';
import { naira } from '@/lib/money';
import { Icon } from '@/components/ui/icon';
import { Card, Tag, StateScreen } from '@/components/ui';
import { AddToCart } from '@/components/add-to-cart';
import { readSession, APP_COOKIE } from '@/lib/session';
import { connectDb } from '@/lib/db';
import { User } from '@/lib/models';

export const dynamic = 'force-dynamic';

export default async function StorePage({ params }: { params: { id: string } }) {
  if (!/^[a-f0-9]{24}$/i.test(params.id)) notFound();
  const data = await CatalogService.getVendor(params.id);
  if (!data) notFound();

  const session = await readSession(APP_COOKIE);
  await connectDb();
  const user = session ? await User.findById(session.sub).select('zoneId').lean() : null;
  const zone = zoneById(user?.zoneId ?? 'emaudo');
  const { vendor, products } = data;
  const category = CATEGORIES.find((c) => c.id === vendor.categoryId);

  return (
    <div className="mx-auto w-full max-w-[1180px] px-4 pt-3 sm:px-6">
      <Link href="/shop" aria-label="Back" className="mb-4 grid h-11 w-11 place-items-center rounded-sm hover:bg-ink-50">
        <Icon name="left" size={22} />
      </Link>

      <Card className="sig p-5">
        <div className="flex items-start gap-4">
          <span className="grid h-14 w-14 flex-none place-items-center rounded-md bg-purple-100 text-purple-700">
            <Icon name={category?.icon ?? 'store'} size={26} />
          </span>
          <div className="min-w-0">
            <h1 className="text-[22px] font-extrabold tracking-[-0.03em]">{vendor.name}</h1>
            <p className="mt-1 flex items-center gap-1.5 text-xs text-ink-400">
              <Icon name="star" size={14} stroke={2} />
              <b className="text-ink-900">{vendor.rating || 'New'}</b>
              {vendor.ratingCount > 0 && <span>({vendor.ratingCount} ratings)</span>}
              <span>·</span><span>{category?.name}</span>
            </p>
          </div>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          <Tag tone={vendor.isOpen ? 'ok' : 'plain'}>{vendor.isOpen ? 'Open now' : 'Closed'}</Tag>
          <Tag><Icon name="clock" size={13} stroke={2} /> {vendor.prepMins + zone.etaMins} min</Tag>
          <Tag>{naira(zone.fee)} delivery</Tag>
        </div>
        {vendor.promoText && (
          <div className="mt-4 rounded-sm border border-yellow-200 bg-warn-50 px-3 py-2.5">
            <b className="text-[13.5px]">{vendor.promoText}</b>
          </div>
        )}
        {vendor.categoryId === 'pharmacy' && (
          <p className="mt-3 text-xs leading-relaxed text-ink-600">
            Licensed pharmacy. Prescription items are confirmed by a pharmacist on the phone before a rider is sent.
          </p>
        )}
      </Card>

      <section className="pt-8">
        <h2 className="mb-1 text-[19px] font-extrabold tracking-[-0.022em]">Products</h2>
        {products.length === 0 ? (
          <StateScreen
            icon="basket" title="No products listed yet"
            body="Our team visits this business in person to photograph products and write the list. It usually happens within a week of approval."
          />
        ) : (
          products.map((p) => {
            const buyable = p.available && vendor.isOpen;
            return (
              <div key={p.id} className="flex items-center gap-3 border-b border-ink-200 py-3">
                <span className="grid h-12 w-12 flex-none place-items-center rounded-sm bg-ink-50 text-purple-300">
                  <Icon name={p.icon} size={22} />
                </span>
                <span className={`min-w-0 flex-1 ${buyable ? '' : 'opacity-50'}`}>
                  <span className="block text-[15.5px] font-bold">{p.name}</span>
                  {p.description && <span className="mt-0.5 block text-xs text-ink-600">{p.description}</span>}
                  <span className="mt-1.5 flex flex-wrap items-center gap-2">
                    <b className="num">{naira(p.priceKobo)}</b>
                    {!p.available && <Tag tone="err">Out of stock</Tag>}
                    {p.requiresPharmacist && <Tag tone="brand">Pharmacist call</Tag>}
                  </span>
                </span>
                <AddToCart
                  disabled={!buyable}
                  product={{ productId: p.id, name: p.name, priceKobo: p.priceKobo, vendorId: vendor.id, vendorName: vendor.name }}
                />
              </div>
            );
          })
        )}
      </section>
      <div className="h-16" />
    </div>
  );
}
