import { Suspense } from 'react';
import Link from 'next/link';
import { connectDb } from '@/lib/db';
import { User } from '@/lib/models';
import { readSession, APP_COOKIE } from '@/lib/session';
import { CatalogService } from '@/lib/services/catalog.service';
import { OrderService } from '@/lib/services/order.service';
import { STATUS_COPY, type OrderStatus } from '@/lib/types';
import { Icon } from '@/components/ui/icon';
import { NeedComposer, PriceSpread, OpenLedger } from '@/components/shop/home-sections';
import { LedgerSkeleton, SpreadSkeleton } from '@/components/shop/skeletons';

export const dynamic = 'force-dynamic';

/**
 * The shell renders immediately from the session cookie alone, with no database
 * round trip. Each data section streams in behind its own Suspense boundary, so
 * a cold Atlas connection delays one block rather than the whole screen.
 */
export default async function ShopHome() {
  const session = await readSession(APP_COOKIE);
  const zoneId = await resolveZone(session!.sub);

  return (
    <>
      <NeedComposer zoneId={zoneId} />
      <Suspense fallback={null}>
        <LiveOrderStrip userId={session!.sub} />
      </Suspense>
      <Suspense fallback={<SpreadSkeleton />}>
        <SpreadSection />
      </Suspense>
      <Suspense fallback={<LedgerSkeleton />}>
        <LedgerSection zoneId={zoneId} />
      </Suspense>
    </>
  );
}

/** Zone is the only thing the shell needs, so it is the only blocking read. */
async function resolveZone(userId: string): Promise<string> {
  try {
    await connectDb();
    const u = await User.findById(userId).select('zoneId').lean();
    return u?.zoneId ?? 'emaudo';
  } catch {
    return 'emaudo';
  }
}

async function LiveOrderStrip({ userId }: { userId: string }) {
  const orders = await OrderService.listForUser(userId, 3);
  const live = orders.find(
    (o) => !['DELIVERED', 'CANCELLED', 'FAILED', 'PENDING_PAYMENT'].includes(o.status)
  );
  if (!live) return null;
  return (
    <div className="px-4 pt-4 sm:px-6">
      <Link
        href={`/shop/orders/${String(live._id)}`}
        className="mx-auto flex w-full max-w-[1180px] items-center gap-3 rounded-md bg-ink-900 px-4 py-3 text-white"
      >
        <span className="h-2 w-2 flex-none animate-pulseDot rounded-full bg-yellow-500" aria-hidden />
        <span className="min-w-0 flex-1">
          <span className="block text-[14px] font-bold">
            {STATUS_COPY[live.status as OrderStatus].title}
          </span>
          <span className="num block text-[12px] text-white/60">{live.reference}</span>
        </span>
        <Icon name="right" size={16} />
      </Link>
    </div>
  );
}

async function SpreadSection() {
  const items = await CatalogService.priceSpread(4);
  return <PriceSpread items={items} />;
}

async function LedgerSection({ zoneId }: { zoneId: string }) {
  const vendors = await CatalogService.listVendors();
  return <OpenLedger vendors={vendors} zoneId={zoneId} />;
}
