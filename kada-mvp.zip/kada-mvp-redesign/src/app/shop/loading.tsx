import { LedgerSkeleton, SpreadSkeleton } from '@/components/shop/skeletons';

/**
 * Route-level loading UI. Next streams this instantly on navigation, so moving
 * between tabs never shows a blank screen while the server works.
 */
export default function Loading() {
  return (
    <>
      <section className="border-b border-ink-200 px-4 pb-6 pt-5 sm:px-6" aria-hidden="true">
        <div className="mx-auto w-full max-w-[1180px]">
          <div className="skeleton h-9 w-[150px] rounded-full" />
          <div className="skeleton mt-5 h-10 w-[180px]" />
          <div className="skeleton mt-4 h-[58px] w-full rounded-md" />
          <div className="mt-3 flex gap-2">
            {[0, 1, 2, 3].map((i) => <div key={i} className="skeleton h-9 w-[92px] rounded-full" />)}
          </div>
        </div>
      </section>
      <SpreadSkeleton />
      <LedgerSkeleton />
    </>
  );
}
