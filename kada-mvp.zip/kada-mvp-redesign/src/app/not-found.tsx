import Link from 'next/link';

export default function NotFound() {
  return (
    <main className="mx-auto flex min-h-dvh max-w-[520px] flex-col items-center justify-center px-4 text-center">
      <p className="text-xs font-extrabold uppercase tracking-[0.08em] text-purple-300">404</p>
      <h1 className="mt-3 text-[28px] font-extrabold tracking-[-0.03em]">We cannot find that page</h1>
      <p className="mt-3 text-[15px] text-ink-600">It may have moved, or the link may be out of date.</p>
      <Link href="/" className="mt-6 inline-flex min-h-[44px] items-center rounded-md bg-purple-700 px-5 font-bold text-white">
        Back to home
      </Link>
    </main>
  );
}
