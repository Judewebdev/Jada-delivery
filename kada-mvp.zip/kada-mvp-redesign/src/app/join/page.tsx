'use client';

import { Suspense, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Button, Field, Selector, Card, Tag } from '@/components/ui';
import { Icon } from '@/components/ui/icon';
import { useToast } from '@/components/toast';
import { api, ApiError } from '@/lib/api-client';
import { ZONES, CATEGORIES, DISPATCH_SLOTS } from '@/lib/types';

type Role = 'customer' | 'vendor' | 'rider';
type Step = 'phone' | 'code' | 'profile' | 'apply' | 'submitted';

const ROLE_COPY: Record<Role, { title: string; sub: string; cta: string }> = {
  customer: { title: 'Welcome to KADA', sub: 'Enter your phone number. We send a six digit code, so there is no password to forget.', cta: 'Send my code' },
  vendor: { title: 'Register your business', sub: 'Restaurants, pharmacies, shops and services. No signup fee, commission only.', cta: 'Send my code' },
  rider: { title: 'Ride with KADA', sub: 'Keep your normal work. Earn on batched runs in the gaps between trips.', cta: 'Send my code' },
};

function JoinFlow() {
  const router = useRouter();
  const params = useSearchParams();
  const { toast } = useToast();

  const [role, setRole] = useState<Role>((params.get('role') as Role) || 'customer');
  const [step, setStep] = useState<Step>('phone');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<{ field?: string; message: string } | null>(null);

  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [devCode, setDevCode] = useState<string | null>(null);

  // customer profile
  const [name, setName] = useState('');
  const [zoneId, setZoneId] = useState('emaudo');
  const [landmark, setLandmark] = useState('');

  // application
  const [applyStep, setApplyStep] = useState(0);
  const [bizName, setBizName] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [categoryId, setCategoryId] = useState('food');
  const [address, setAddress] = useState('');
  const [bike, setBike] = useState('');
  const [guarantorName, setGuarantorName] = useState('');
  const [guarantorPhone, setGuarantorPhone] = useState('');
  const [slots, setSlots] = useState<string[]>(['s1230']);
  const [docs, setDocs] = useState<string[]>([]);
  const [agreed, setAgreed] = useState(false);

  const fieldErr = (f: string) => (err?.field === f ? err.message : undefined);

  async function sendCode() {
    setErr(null); setBusy(true);
    try {
      const r = await api<{ exists: boolean; devCode?: string }>('/api/auth/request-otp', {
        method: 'POST', json: { phone },
      });
      setDevCode(r.devCode ?? null);
      setStep('code');
      toast(r.devCode ? `Test code: ${r.devCode}` : 'Code sent to your phone', 'info');
    } catch (e) {
      const a = e as ApiError;
      setErr({ field: a.field ?? 'phone', message: a.message });
    } finally { setBusy(false); }
  }

  async function verify() {
    setErr(null); setBusy(true);
    try {
      if (role === 'customer') {
        const r = await api<{ registered: boolean }>('/api/auth/verify-otp', {
          method: 'POST', json: { phone, code, surface: 'app' },
        });
        if (r.registered) { toast('Signed in'); router.push('/shop'); router.refresh(); return; }
        setStep('profile');
      } else {
        // Vendors and riders are verified the same way, then routed either to
        // their console if already approved, or into the application flow.
        try {
          await api('/api/auth/verify-otp', { method: 'POST', json: { phone, code, surface: 'app' } });
          router.push(role === 'vendor' ? '/vendor' : '/rider');
          return;
        } catch {
          setStep('apply');
        }
      }
    } catch (e) {
      const a = e as ApiError;
      setErr({ field: a.field ?? 'code', message: a.message });
    } finally { setBusy(false); }
  }

  async function register() {
    setErr(null); setBusy(true);
    try {
      await api('/api/auth/register', { method: 'POST', json: { phone, code, name, zoneId, landmark } });
      toast('Account created');
      router.push('/shop'); router.refresh();
    } catch (e) {
      const a = e as ApiError;
      setErr({ field: a.field, message: a.message });
    } finally { setBusy(false); }
  }

  async function submitApplication() {
    setErr(null); setBusy(true);
    try {
      const missing: string[] = [];
      if (role === 'vendor') {
        if (!docs.includes('Owner ID')) missing.push('Owner ID');
        if (categoryId === 'pharmacy' && !docs.includes('PCN licence')) missing.push('PCN premises licence');
      } else {
        if (!docs.includes('NIN slip')) missing.push('NIN slip');
        if (!guarantorName) missing.push('Guarantor visit');
      }
      await api('/api/applications', {
        method: 'POST',
        json: {
          type: role,
          name: role === 'vendor' ? bizName : name,
          phone,
          summary: role === 'vendor'
            ? `${CATEGORIES.find((c) => c.id === categoryId)?.name} · ${ZONES.find((z) => z.id === zoneId)?.name}`
            : `${bike || 'Bike on file'} · ${ZONES.find((z) => z.id === zoneId)?.name}`,
          documents: docs,
          missing,
          payload: role === 'vendor'
            ? { categoryId, zoneId, ownerName, address }
            : { zoneId, bike, guarantorName, guarantorPhone, slots },
        },
      });
      setStep('submitted');
    } catch (e) {
      const a = e as ApiError;
      setErr({ field: a.field, message: a.message });
      toast(a.message, 'error');
    } finally { setBusy(false); }
  }

  const toggleDoc = (d: string) =>
    setDocs((p) => (p.includes(d) ? p.filter((x) => x !== d) : [...p, d]));

  return (
    <div className="min-h-dvh lg:grid lg:grid-cols-[1fr_minmax(0,560px)]">
      {/* Brand panel. Hidden on mobile so the form owns the small screen. */}
      <aside className="on-dark relative hidden overflow-hidden bg-purple-700 p-10 text-white lg:flex lg:flex-col">
        <Link href="/" className="flex items-baseline text-[22px] font-extrabold tracking-[-0.05em]">
          kada<span className="ml-1 h-[7px] w-[7px] rounded-full bg-yellow-500" aria-hidden />
        </Link>
        <div className="my-auto max-w-[26ch]">
          <h2 className="text-[40px] font-extrabold leading-[1.05] tracking-[-0.04em]">
            One app for everything the house needs.
          </h2>
          <p className="mt-4 text-[15px] leading-relaxed text-white/70">
            Food, medicine, groceries and essentials from the businesses already around you.
          </p>
          <ul className="mt-8 space-y-3">
            {['Prepaid, so riders carry no cash', 'Every fee shown before you pay', 'Refunds land in your wallet in minutes'].map((t) => (
              <li key={t} className="flex items-center gap-3 text-[14px] font-semibold">
                <span className="grid h-7 w-7 flex-none place-items-center rounded-full bg-yellow-500 text-purple-900">
                  <Icon name="check" size={14} stroke={3} />
                </span>
                {t}
              </li>
            ))}
          </ul>
        </div>
        <p className="text-xs text-white/50">Ekpoma, Edo State</p>
      </aside>

      <main className="flex min-h-dvh flex-col px-4 py-6 sm:px-8">
        <div className="mb-6 flex items-center justify-between lg:hidden">
          <Link href="/" className="flex items-baseline text-[21px] font-extrabold tracking-[-0.05em] text-purple-700">
            kada<span className="ml-1 h-[7px] w-[7px] rounded-full bg-yellow-500" aria-hidden />
          </Link>
          <Link href="/" className="inline-flex min-h-[44px] items-center px-2 text-[13.5px] font-bold text-ink-600">Cancel</Link>
        </div>

        <div className="mx-auto w-full max-w-[440px] flex-1">
          {step === 'phone' && (
            <>
              <div className="mb-6 flex gap-2" role="tablist" aria-label="Account type">
                {(['customer', 'vendor', 'rider'] as Role[]).map((r) => (
                  <button
                    key={r}
                    role="tab"
                    aria-selected={role === r}
                    onClick={() => { setRole(r); setErr(null); }}
                    className={`min-h-[44px] flex-1 rounded-full border-[1.5px] px-3 text-[13.5px] font-bold capitalize transition ${
                      role === r ? 'border-purple-700 bg-purple-700 text-white' : 'border-ink-200 text-ink-600'
                    }`}
                  >
                    {r === 'vendor' ? 'Business' : r}
                  </button>
                ))}
              </div>
              <h1 className="text-[26px] font-extrabold tracking-[-0.03em]">{ROLE_COPY[role].title}</h1>
              <p className="mt-2 text-[14px] leading-relaxed text-ink-600">{ROLE_COPY[role].sub}</p>

              <form
                className="mt-6"
                onSubmit={(e) => { e.preventDefault(); void sendCode(); }}
              >
                <Field
                  label="Phone number"
                  type="tel"
                  inputMode="tel"
                  autoComplete="tel"
                  placeholder="0803 000 0000"
                  value={phone}
                  onChange={(e) => { setPhone(e.target.value); setErr(null); }}
                  error={fieldErr('phone')}
                  hint="Nigerian numbers only. This is the number riders will call."
                />
                <Button type="submit" size="lg" block loading={busy} disabled={phone.replace(/\D/g, '').length < 10}>
                  {ROLE_COPY[role].cta}
                </Button>
              </form>
              <p className="mt-4 text-center text-xs text-ink-400">
                By continuing you accept the KADA terms and privacy policy.
              </p>
            </>
          )}

          {step === 'code' && (
            <>
              <button onClick={() => setStep('phone')} className="mb-3 grid h-11 w-11 place-items-center rounded-sm hover:bg-ink-50" aria-label="Back">
                <Icon name="left" size={22} />
              </button>
              <h1 className="text-[26px] font-extrabold tracking-[-0.03em]">Enter your code</h1>
              <p className="mt-2 text-[14px] text-ink-600">We sent six digits to {phone}.</p>
              {devCode && (
                <Card tone="warn" className="mt-4">
                  <p className="text-[13.5px]">
                    <b>No SMS provider connected yet.</b> Your test code is <b className="num">{devCode}</b>.
                    Once SMS_API_KEY is set this disappears and the code only goes to the phone.
                  </p>
                </Card>
              )}
              <form className="mt-6" onSubmit={(e) => { e.preventDefault(); void verify(); }}>
                <Field
                  label="Verification code"
                  inputMode="numeric"
                  maxLength={6}
                  autoComplete="one-time-code"
                  placeholder="000000"
                  className="text-center text-[26px] font-extrabold tracking-[0.3em]"
                  value={code}
                  onChange={(e) => { setCode(e.target.value.replace(/\D/g, '').slice(0, 6)); setErr(null); }}
                  error={fieldErr('code')}
                />
                <Button type="submit" size="lg" block loading={busy} disabled={code.length < 6}>Continue</Button>
              </form>
              <button onClick={() => void sendCode()} className="mt-4 w-full text-center text-[13.5px] font-bold text-purple-700">
                Send a new code
              </button>
            </>
          )}

          {step === 'profile' && (
            <>
              <h1 className="text-[26px] font-extrabold tracking-[-0.03em]">Almost done</h1>
              <p className="mt-2 text-[14px] text-ink-600">Two things and you can start ordering.</p>
              <form className="mt-6" onSubmit={(e) => { e.preventDefault(); void register(); }}>
                <Field
                  label="Your name" value={name} autoComplete="name"
                  onChange={(e) => setName(e.target.value)} error={fieldErr('name')}
                  placeholder="First and last name"
                />
                <p className="mb-2 text-[13.5px] font-semibold">Delivery zone</p>
                {ZONES.map((z) => (
                  <Selector
                    key={z.id} checked={zoneId === z.id} onClick={() => setZoneId(z.id)}
                    title={z.name} sub={`${z.area} · about ${z.etaMins} min`}
                    right={<b className="num text-[13.5px]">₦{(z.fee / 100).toLocaleString('en-NG')}</b>}
                  />
                ))}
                <p className="mb-4 mt-2 text-xs text-ink-400">
                  Delivery is priced by zone, so the fee you see is the fee you pay.
                </p>
                <Field
                  label="Landmark or hostel name" value={landmark}
                  onChange={(e) => setLandmark(e.target.value)}
                  placeholder="e.g. Peace Lodge, opposite Zenith"
                  hint="Addresses here are landmarks, not street numbers. Be specific and your rider finds you first time."
                />
                {err && !err.field && <p role="alert" className="mb-3 text-xs font-bold text-err-600">{err.message}</p>}
                <Button type="submit" size="lg" block loading={busy} disabled={name.trim().length < 2}>
                  Create account
                </Button>
              </form>
            </>
          )}

          {step === 'apply' && (
            <ApplicationFlow
              role={role}
              step={applyStep}
              setStep={setApplyStep}
              busy={busy}
              onSubmit={() => void submitApplication()}
              state={{
                bizName, setBizName, ownerName, setOwnerName, categoryId, setCategoryId,
                address, setAddress, zoneId, setZoneId, name, setName, bike, setBike,
                guarantorName, setGuarantorName, guarantorPhone, setGuarantorPhone,
                slots, setSlots, docs, toggleDoc, agreed, setAgreed,
              }}
            />
          )}

          {step === 'submitted' && (
            <div className="py-10 text-center">
              <span className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-md bg-ok-50 text-ok-600">
                <Icon name="check" size={26} />
              </span>
              <h1 className="text-[26px] font-extrabold tracking-[-0.03em]">Application received</h1>
              <p className="mx-auto mt-3 max-w-[36ch] text-[14px] leading-relaxed text-ink-600">
                We will call you within 48 hours to verify your details
                {role === 'vendor' ? ' and build your product list.' : ' and visit your guarantor.'}
              </p>
              <p className="mx-auto mt-3 max-w-[36ch] text-xs text-ink-400">
                {role === 'vendor'
                  ? 'Someone comes to you in person to photograph your products and write your list. That part is free.'
                  : 'Verified riders get an insulated delivery bag at the training session.'}
              </p>
              <Link href="/" className="mt-6 inline-flex min-h-[44px] items-center rounded-md border-[1.5px] border-ink-300 px-5 font-bold">
                Back to home
              </Link>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

/**
 * useSearchParams needs a Suspense boundary so the shell can be prerendered
 * while the query string is read on the client.
 */
export default function JoinPage() {
  return (
    <Suspense fallback={<div className="min-h-dvh" aria-busy="true" />}>
      <JoinFlow />
    </Suspense>
  );
}

/* --------------------------------------------------------- application UI */
interface ApplyState {
  bizName: string; setBizName: (v: string) => void;
  ownerName: string; setOwnerName: (v: string) => void;
  categoryId: string; setCategoryId: (v: string) => void;
  address: string; setAddress: (v: string) => void;
  zoneId: string; setZoneId: (v: string) => void;
  name: string; setName: (v: string) => void;
  bike: string; setBike: (v: string) => void;
  guarantorName: string; setGuarantorName: (v: string) => void;
  guarantorPhone: string; setGuarantorPhone: (v: string) => void;
  slots: string[]; setSlots: (v: string[]) => void;
  docs: string[]; toggleDoc: (d: string) => void;
  agreed: boolean; setAgreed: (v: boolean) => void;
}

function ApplicationFlow({ role, step, setStep, busy, onSubmit, state }: {
  role: Role; step: number; setStep: (n: number) => void; busy: boolean;
  onSubmit: () => void; state: ApplyState;
}) {
  const total = 3;
  const vendorDocs = ['Shop front photo', 'Owner ID', 'CAC certificate', 'PCN licence'];
  const riderDocs = ['NIN slip', 'Rider permit', 'Passport photo'];

  const last = step === total - 1;
  const canContinue =
    step === 0
      ? (role === 'vendor' ? state.bizName.trim().length > 1 : state.name.trim().length > 1)
      : step === 1
        ? true
        : state.agreed;

  return (
    <>
      <div className="mb-5 flex gap-1" aria-label={`Step ${step + 1} of ${total}`}>
        {Array.from({ length: total }).map((_, i) => (
          <span key={i} className={`h-1 flex-1 rounded-full transition ${i <= step ? 'bg-purple-700' : 'bg-ink-200'}`} />
        ))}
      </div>

      {step === 0 && role === 'vendor' && (
        <>
          <h1 className="text-[26px] font-extrabold tracking-[-0.03em]">About your business</h1>
          <p className="mt-2 text-[14px] text-ink-600">Use the name people already call you.</p>
          <div className="mt-6">
            <Field label="Business name" value={state.bizName} onChange={(e) => state.setBizName(e.target.value)} placeholder="e.g. Mama Ovie Kitchen" />
            <Field label="Owner or manager" value={state.ownerName} onChange={(e) => state.setOwnerName(e.target.value)} placeholder="Who we call when an order needs attention" />
            <p className="mb-2 text-[13.5px] font-semibold">What do you sell?</p>
            <div className="mb-4 flex flex-wrap gap-2">
              {CATEGORIES.map((c) => (
                <button
                  key={c.id} type="button" aria-pressed={state.categoryId === c.id}
                  onClick={() => state.setCategoryId(c.id)}
                  className={`min-h-[36px] rounded-full border-[1.5px] px-4 text-[13.5px] font-bold transition ${
                    state.categoryId === c.id ? 'border-purple-700 bg-purple-700 text-white' : 'border-ink-200 text-ink-600'
                  }`}
                >{c.name}</button>
              ))}
            </div>
            <Field label="Shop address" value={state.address} onChange={(e) => state.setAddress(e.target.value)} placeholder="Street and landmark" />
          </div>
        </>
      )}

      {step === 0 && role === 'rider' && (
        <>
          <h1 className="text-[26px] font-extrabold tracking-[-0.03em]">About you</h1>
          <Card tone="brand" className="my-5">
            <span className="text-[13.5px] text-white/70">You earn per run, not per hour</span>
            <div className="my-1 text-[30px] font-extrabold tracking-[-0.035em]">₦1,500 – ₦2,500</div>
            <p className="text-[13.5px] leading-relaxed text-white/75">
              One run is up to three drops in the same zone. Extra drops pay ₦400 each. You keep 100% of every tip.
            </p>
          </Card>
          <Field label="Full name, as on your ID" value={state.name} onChange={(e) => state.setName(e.target.value)} />
          <Field label="Bike make and plate number" value={state.bike} onChange={(e) => state.setBike(e.target.value)} placeholder="e.g. Bajaj Boxer, EKP 442 QR" />
        </>
      )}

      {step === 1 && (
        <>
          <h1 className="text-[26px] font-extrabold tracking-[-0.03em]">
            {role === 'vendor' ? 'Location and documents' : 'Papers and guarantor'}
          </h1>
          <p className="mt-2 text-[14px] text-ink-600">
            Nothing goes live until these are checked. It usually takes 48 hours.
          </p>
          <div className="mt-6">
            <p className="mb-2 text-[13.5px] font-semibold">Nearest zone</p>
            {ZONES.map((z) => (
              <Selector key={z.id} checked={state.zoneId === z.id} onClick={() => state.setZoneId(z.id)} title={z.name} sub={z.area} />
            ))}
            <p className="mb-2 mt-4 text-[13.5px] font-semibold">Documents</p>
            {(role === 'vendor' ? vendorDocs : riderDocs).map((d) => (
              <Selector key={d} multiple checked={state.docs.includes(d)} onClick={() => state.toggleDoc(d)} title={d}
                sub={d === 'PCN licence' ? 'Required for pharmacies' : undefined} />
            ))}
            {role === 'rider' && (
              <>
                <Field label="Guarantor full name" value={state.guarantorName} onChange={(e) => state.setGuarantorName(e.target.value)} />
                <Field label="Guarantor phone" inputMode="tel" value={state.guarantorPhone} onChange={(e) => state.setGuarantorPhone(e.target.value)}
                  hint="One person we can physically visit. This is not negotiable and it protects both of us." />
                <p className="mb-2 mt-4 text-[13.5px] font-semibold">Slots you can take</p>
                {DISPATCH_SLOTS.filter((s) => s.id !== 'now').map((s) => (
                  <Selector key={s.id} multiple checked={state.slots.includes(s.id)}
                    onClick={() => state.setSlots(state.slots.includes(s.id) ? state.slots.filter((x) => x !== s.id) : [...state.slots, s.id])}
                    title={s.label} sub={s.detail} />
                ))}
              </>
            )}
          </div>
        </>
      )}

      {step === 2 && (
        <>
          <h1 className="text-[26px] font-extrabold tracking-[-0.03em]">
            {role === 'vendor' ? 'What it costs you' : 'Your terms'}
          </h1>
          {role === 'vendor' ? (
            <Card className="my-5">
              {[['Signup fee', '₦0'], ['Monthly fee', '₦0'], ['Commission, first 90 days', '10%'],
                ['Commission after 90 days', '13%'], ['Commission on delivery fees and tips', '0%'], ['Payout', 'Every Monday']]
                .map(([k, v]) => (
                  <div key={k} className="flex justify-between border-b border-ink-200 py-3 text-[14px] last:border-0">
                    <span className="text-ink-600">{k}</span><b>{v}</b>
                  </div>
                ))}
            </Card>
          ) : (
            <Card className="my-5">
              {[['Run rate', '₦1,500 – ₦2,500'], ['Extra drop above three', '₦400'],
                ["KADA's cut of your tips", '0%'], ['Payment day', 'Every Friday'], ['Cash you handle', '₦0, always prepaid']]
                .map(([k, v]) => (
                  <div key={k} className="flex justify-between border-b border-ink-200 py-3 text-[14px] last:border-0">
                    <span className="text-ink-600">{k}</span><b>{v}</b>
                  </div>
                ))}
            </Card>
          )}
          <Selector
            multiple checked={state.agreed} onClick={() => state.setAgreed(!state.agreed)}
            title={role === 'vendor' ? 'I accept the vendor agreement' : 'I accept the rider partner terms'}
            sub={role === 'vendor'
              ? 'Including the commission and the same price rule.'
              : 'Including no cash handling and the pickup code requirement.'}
          />
        </>
      )}

      <div className="mt-5 flex gap-2">
        {step > 0 && <Button variant="outline" size="lg" onClick={() => setStep(step - 1)}>Back</Button>}
        <Button
          size="lg" block loading={busy} disabled={!canContinue}
          onClick={() => (last ? onSubmit() : setStep(step + 1))}
        >
          {last ? 'Submit application' : 'Continue'}
        </Button>
      </div>
      {step === 2 && !state.agreed && (
        <p className="mt-3 text-center text-xs text-ink-400">
          <Tag tone="plain">Tick the box to continue</Tag>
        </p>
      )}
    </>
  );
}
