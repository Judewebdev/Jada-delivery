'use client';

export default function GlobalError({ reset }: { error: Error; reset: () => void }) {
  return (
    <main className="mx-auto flex min-h-dvh max-w-[520px] flex-col items-center justify-center px-4 text-center">
      <h1 className="text-[26px] font-extrabold tracking-[-0.03em]">Something went wrong while loading this</h1>
      <p className="mt-3 text-[15px] text-ink-600">
        It is not your fault. Try again, and if it keeps happening give us a call.
      </p>
      <button onClick={reset} className="mt-6 inline-flex min-h-[44px] items-center rounded-md bg-purple-700 px-5 font-bold text-white">
        Try again
      </button>
    </main>
  );
}
