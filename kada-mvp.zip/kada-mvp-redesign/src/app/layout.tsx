import type { Metadata, Viewport } from 'next';
import './globals.css';
import { ToastProvider } from '@/components/toast';
import { CartProvider } from '@/components/cart';
import { publicEnv } from '@/lib/env';

export const metadata: Metadata = {
  title: { default: `${publicEnv.brandName} — local commerce, delivered`, template: `%s · ${publicEnv.brandName}` },
  description: 'Order food, medicine, groceries and everyday essentials from businesses around you.',
  applicationName: publicEnv.brandName,
  formatDetection: { telephone: true },
};

export const viewport: Viewport = {
  themeColor: '#2E0A4E',
  width: 'device-width',
  initialScale: 1,
  viewportFit: 'cover',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        {/*
          Loaded by link rather than next/font so the build never depends on
          reaching Google at compile time, which breaks CI on restricted
          networks. display=swap means text paints immediately in the fallback.
        */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        <ToastProvider>
          <CartProvider>{children}</CartProvider>
        </ToastProvider>
      </body>
    </html>
  );
}
