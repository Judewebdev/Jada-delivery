import { PanelSkeleton } from '@/components/shop/skeletons';
export default function Loading() { return <PanelSkeleton rows={3} />; }
