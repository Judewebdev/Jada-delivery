'use client';

import { useCallback, useEffect, useState } from 'react';
import { api, ApiError } from '@/lib/api-client';
import { useToast } from '@/components/toast';
import { naira } from '@/lib/money';
import { Button, Card, Skeleton, StateScreen, Tag, Sheet } from '@/components/ui';
import { Icon } from '@/components/ui/icon';
import { SignOutButton } from '@/components/sign-out';
import { STATUS_COPY, zoneById, type OrderStatus } from '@/lib/types';

interface Order {
  _id: string; reference: string; status: OrderStatus; totalKobo: number;
  zoneId: string; landmark: string; riderId?: string; statusAt: string; vendorId: string;
}
interface Rider { _id: string; name: string; online: boolean; zoneId: string; runsCompleted: number }
interface Vendor { _id: string; name: string; isOpen: boolean; categoryId: string; status: string }
interface Application { _id: string; type: 'vendor' | 'rider'; name: string; phone: string; summary: string; documents: string[]; missing: string[] }
interface Metrics {
  gmvKobo: number; takeKobo: number; contributionKobo: number; takeRatePct: number;
  deliveredCount: number; liveCount: number; cancelledCount: number; dropsPerRun: number;
  vendors: number; riders: number; customers: number;
}

const SLA: Partial<Record<OrderStatus, number>> = {
  PAID: 300, CONFIRMED: 900, PREPARING: 1800, READY_FOR_PICKUP: 600, RIDER_ASSIGNED: 900, PICKED_UP: 1500, IN_TRANSIT: 1500,
};
const secs = (iso: string) => Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
const mmss = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;

type Tab = 'live' | 'approvals' | 'money';

export default function OpsConsole() {
  const { toast } = useToast();
  const [tab, setTab] = useState<Tab>('live');
  const [orders, setOrders] = useState<Order[] | null>(null);
  const [riders, setRiders] = useState<Rider[]>([]);
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [apps, setApps] = useState<Application[]>([]);
  const [metrics, setMetrics] = useState<Metrics | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [assigning, setAssigning] = useState<Order | null>(null);
  const [, setTick] = useState(0);

  const load = useCallback(async () => {
    try {
      const [o, a, m] = await Promise.all([
        api<{ orders: Order[]; riders: Rider[]; vendors: Vendor[] }>('/api/ops/orders'),
        api<{ applications: Application[] }>('/api/ops/applications'),
        api<Metrics>('/api/ops/metrics'),
      ]);
      setOrders(o.orders); setRiders(o.riders); setVendors(o.vendors);
      setApps(a.applications); setMetrics(m); setError(null);
    } catch (e) { setError((e as ApiError).message); }
  }, []);

  useEffect(() => {
    void load();
    const poll = setInterval(() => void load(), 10000);
    const clock = setInterval(() => setTick((t) => t + 1), 1000);
    return () => { clearInterval(poll); clearInterval(clock); };
  }, [load]);

  const flagged = (orders ?? []).filter((o) => {
    const limit = SLA[o.status] ?? 1800;
    return secs(o.statusAt) > limit || (o.status === 'READY_FOR_PICKUP' && !o.riderId);
  });

  async function act(body: Record<string, unknown>, label: string) {
    try { await api('/api/ops/orders', { method: 'POST', json: body }); toast(label); await load(); }
    catch (e) { toast((e as ApiError).message, 'error'); }
  }
  async function decide(applicationId: string, decision: 'approve' | 'reject') {
    try {
      await api('/api/ops/applications', { method: 'POST', json: { applicationId, decision } });
      toast(decision === 'approve' ? 'Approved, account created' : 'Application rejected');
      await load();
    } catch (e) { toast((e as ApiError).message, 'error'); }
  }

  const TABS: { id: Tab; label: string; icon: string; badge?: number }[] = [
    { id: 'live', label: 'Live', icon: 'alert', badge: flagged.length },
    { id: 'approvals', label: 'Approvals', icon: 'inbox', badge: apps.length },
    { id: 'money', label: 'Money', icon: 'chart' },
  ];

  return (
    <div className="min-h-dvh bg-white">
      <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-ink-200 bg-white px-4 py-3">
        <span className="flex items-baseline text-[19px] font-extrabold tracking-[-0.05em] text-purple-700">
          kada<span className="ml-1 h-[6px] w-[6px] rounded-full bg-yellow-500" aria-hidden />
          <span className="ml-2 text-[11px] font-extrabold uppercase tracking-wider text-ink-400">Ops</span>
        </span>
        <Tag tone={flagged.length ? 'err' : 'ok'}>{flagged.length} need attention</Tag>
        <span className="ml-auto text-xs text-ink-400">{riders.filter((r) => r.online).length} riders online</span>
      </header>

      <nav className="flex gap-2 overflow-x-auto border-b border-ink-200 px-4 py-3" aria-label="Sections">
        {TABS.map((t) => (
          <button
            key={t.id} aria-current={tab === t.id ? 'page' : undefined} onClick={() => setTab(t.id)}
            className={`flex min-h-[36px] flex-none items-center gap-2 rounded-full border-[1.5px] px-4 text-[13.5px] font-bold transition ${
              tab === t.id ? 'border-purple-700 bg-purple-700 text-white' : 'border-ink-200 text-ink-600'
            }`}
          >
            <Icon name={t.icon} size={16} />{t.label}
            {t.badge ? <span className="rounded-full bg-yellow-500 px-2 text-[11px] text-purple-900">{t.badge}</span> : null}
          </button>
        ))}
      </nav>

      <main className="mx-auto w-full max-w-[1180px] px-4 py-5 sm:px-6">
        {error ? (
          <StateScreen tone="error" icon="alert" title="Could not load operations data" body={error}
            action={<Button onClick={() => void load()}>Try again</Button>} />
        ) : !orders ? (
          <div className="space-y-3">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-16 w-full rounded-md" />)}</div>
        ) : tab === 'live' ? (
          <>
            {flagged.length > 0 && (
              <Card tone="bad" className="mb-4">
                <div className="mb-2 flex items-center gap-2 text-err-600"><Icon name="alert" size={18} /><b>Needs you now</b></div>
                {flagged.slice(0, 4).map((o) => (
                  <div key={o._id} className="flex items-center justify-between gap-3 py-1.5 text-[13.5px]">
                    <span><b className="num">{o.reference}</b> — {o.status === 'READY_FOR_PICKUP' && !o.riderId
                      ? 'ready with no rider' : `${STATUS_COPY[o.status].title} for ${mmss(secs(o.statusAt))}`}</span>
                    {o.status === 'READY_FOR_PICKUP' && !o.riderId && (
                      <Button size="sm" onClick={() => setAssigning(o)}>Assign</Button>
                    )}
                  </div>
                ))}
              </Card>
            )}

            <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {[
                ['In flight', String(orders.length)],
                ['Delivered', String(metrics?.deliveredCount ?? 0)],
                ['Vendors', String(metrics?.vendors ?? 0)],
                ['Riders online', String(riders.filter((r) => r.online).length)],
              ].map(([k, v]) => (
                <div key={k} className="rounded-md border border-ink-200 p-4">
                  <span className="text-xs text-ink-400">{k}</span>
                  <div className="num mt-0.5 text-[23px] font-extrabold tracking-[-0.03em]">{v}</div>
                </div>
              ))}
            </div>

            {orders.length === 0 ? (
              <StateScreen icon="chart" title="Nothing in flight"
                body="Live orders appear here the moment a customer pays." />
            ) : (
              <div className="overflow-hidden rounded-lg border border-ink-200">
                {orders.map((o) => {
                  const late = secs(o.statusAt) > (SLA[o.status] ?? 1800);
                  const rider = riders.find((r) => r._id === o.riderId);
                  const vendor = vendors.find((v) => v._id === o.vendorId);
                  return (
                    <div key={o._id} className={`flex items-center gap-3 border-b border-ink-200 px-4 py-3 text-[13.5px] last:border-0 ${late ? 'bg-err-50' : ''}`}>
                      <b className="num w-[92px] flex-none">{o.reference}</b>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate">{vendor?.name ?? 'Vendor'}</span>
                        <span className="text-xs text-ink-400">{zoneById(o.zoneId).name}</span>
                      </span>
                      <Tag tone={o.status === 'READY_FOR_PICKUP' && !o.riderId ? 'err' : 'brand'}>
                        {STATUS_COPY[o.status].title}
                      </Tag>
                      <span className={`num hidden w-[56px] text-right font-extrabold sm:block ${late ? 'text-err-600' : 'text-ink-600'}`}>
                        {mmss(secs(o.statusAt))}
                      </span>
                      <span className="hidden w-[100px] truncate text-xs text-ink-400 md:block">{rider?.name ?? '—'}</span>
                      {o.status === 'READY_FOR_PICKUP' && !o.riderId ? (
                        <Button size="sm" onClick={() => setAssigning(o)}>Assign</Button>
                      ) : (
                        <Button size="sm" variant="ghost"
                          onClick={() => void act({ orderId: o._id, action: 'cancel', note: 'Cancelled by operations' }, 'Cancelled and refunded')}>
                          Cancel
                        </Button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </>
        ) : tab === 'approvals' ? (
          apps.length === 0 ? (
            <StateScreen icon="check" title="Queue is clear"
              body="Vendor and rider applications land here from the signup flow." />
          ) : (
            apps.map((a) => (
              <Card key={a._id} className="mb-4">
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-[19px] font-extrabold">{a.name}</h2>
                  <Tag tone={a.type === 'vendor' ? 'brand' : 'accent'}>{a.type === 'vendor' ? 'Vendor' : 'Rider'}</Tag>
                </div>
                <p className="mt-1 text-xs text-ink-400">{a.summary} · {a.phone}</p>
                <div className="my-3 flex flex-wrap gap-1.5">
                  {a.documents.map((d) => <Tag key={d} tone="ok"><Icon name="check" size={12} stroke={2.5} />{d}</Tag>)}
                  {a.missing.map((d) => <Tag key={d} tone="err"><Icon name="close" size={12} stroke={2.5} />{d}</Tag>)}
                </div>
                {a.missing.length > 0 ? (
                  <Card tone="bad" className="mb-3">
                    <p className="text-[13.5px]"><b>Cannot approve yet.</b> {a.missing[0]} is outstanding.</p>
                  </Card>
                ) : (
                  <Card tone="ok" className="mb-3">
                    <p className="text-[13.5px]"><b>Complete.</b> Approving creates the account and they can sign in immediately.</p>
                  </Card>
                )}
                <div className="flex flex-wrap gap-2">
                  <Button variant={a.missing.length ? 'ghost' : 'ok'} disabled={a.missing.length > 0}
                    onClick={() => void decide(a._id, 'approve')}>Approve</Button>
                  <Button variant="danger" onClick={() => void decide(a._id, 'reject')}>Reject</Button>
                </div>
              </Card>
            ))
          )
        ) : (
          metrics && (
            <>
              <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
                {[
                  ['GMV', naira(metrics.gmvKobo)],
                  ['Take rate', `${metrics.takeRatePct}%`],
                  ['Contribution', naira(metrics.contributionKobo)],
                  ['Drops per run', String(metrics.dropsPerRun)],
                ].map(([k, v]) => (
                  <div key={k} className="rounded-md border border-ink-200 p-4">
                    <span className="text-xs text-ink-400">{k}</span>
                    <div className="num mt-0.5 text-[23px] font-extrabold tracking-[-0.03em]">{v}</div>
                  </div>
                ))}
              </div>
              <Card>
                {[
                  ['Delivered orders', String(metrics.deliveredCount)],
                  ['Cancelled', String(metrics.cancelledCount)],
                  ['Active vendors', String(metrics.vendors)],
                  ['Active riders', String(metrics.riders)],
                  ['Customers', String(metrics.customers)],
                ].map(([k, v]) => (
                  <div key={k} className="flex justify-between border-b border-ink-200 py-3 last:border-0">
                    <span className="text-ink-600">{k}</span><b className="num">{v}</b>
                  </div>
                ))}
              </Card>
              <Card tone="warn" className="mt-4">
                <p className="text-[13.5px]">
                  <b>Below 2.5 drops per run, every delivery loses money.</b> That single number is why dispatch
                  slots exist, and it is the one to optimise before anything else.
                </p>
              </Card>
            </>
          )
        )}

        <div className="mt-10 max-w-[240px]"><SignOutButton surface="ops" /></div>
      </main>

      <Sheet open={Boolean(assigning)} onClose={() => setAssigning(null)} title="Assign a rider">
        {riders.filter((r) => r.online).length === 0 ? (
          <Card tone="bad">
            <p className="text-[13.5px]">
              No riders are online. Call the stand, or cancel and tell the customer now rather than letting it rot.
            </p>
          </Card>
        ) : (
          riders.filter((r) => r.online).map((r) => (
            <Button
              key={r._id} variant="outline" block className="mb-2 justify-start"
              onClick={() => { void act({ orderId: assigning!._id, action: 'assign', riderId: r._id }, 'Rider assigned'); setAssigning(null); }}
            >
              {r.name} · {zoneById(r.zoneId).name} · {r.runsCompleted} runs
            </Button>
          ))
        )}
      </Sheet>
    </div>
  );
}
