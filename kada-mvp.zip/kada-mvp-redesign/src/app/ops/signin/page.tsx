'use client';

import { Suspense, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { api, ApiError } from '@/lib/api-client';
import { Button, Field, Card } from '@/components/ui';

/**
 * Ops sign in. Deliberately unlinked from anywhere in the customer app. Reaching
 * it requires knowing the URL, and passing it requires an admin role on the
 * account, checked server-side on every admin request afterwards.
 */
function OpsSignInForm() {
  const router = useRouter();
  const next = useSearchParams().get('next') || '/ops';
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [sent, setSent] = useState(false);
  const [devCode, setDevCode] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<{ field?: string; message: string } | null>(null);

  async function send() {
    setBusy(true); setError(null);
    try {
      const r = await api<{ devCode?: string }>('/api/auth/request-otp', { method: 'POST', json: { phone } });
      setDevCode(r.devCode ?? null); setSent(true);
    } catch (e) { const a = e as ApiError; setError({ field: a.field ?? 'phone', message: a.message }); }
    finally { setBusy(false); }
  }

  async function verify() {
    setBusy(true); setError(null);
    try {
      await api('/api/auth/verify-otp', { method: 'POST', json: { phone, code, surface: 'ops' } });
      router.push(next); router.refresh();
    } catch (e) { const a = e as ApiError; setError({ field: a.field ?? 'code', message: a.message }); }
    finally { setBusy(false); }
  }

  return (
    <main className="on-dark flex min-h-dvh flex-col items-center justify-center bg-purple-900 px-4">
      <div className="w-full max-w-[400px]">
        <div className="mb-6 flex items-baseline text-[22px] font-extrabold tracking-[-0.05em] text-white">
          kada<span className="ml-1 h-[7px] w-[7px] rounded-full bg-yellow-500" aria-hidden />
          <span className="ml-2 text-[11px] font-extrabold uppercase tracking-wider text-white/50">Operations</span>
        </div>
        <div className="rounded-xl bg-white p-6">
          <h1 className="text-[22px] font-extrabold tracking-[-0.03em]">Staff sign in</h1>
          <p className="mt-2 text-[13.5px] text-ink-600">
            Authorised operators only. Every action here is recorded against your account.
          </p>

          {devCode && (
            <Card tone="warn" className="mt-4">
              <p className="text-[13.5px]">No SMS provider connected. Test code: <b className="num">{devCode}</b></p>
            </Card>
          )}

          <form className="mt-5" onSubmit={(e) => { e.preventDefault(); void (sent ? verify() : send()); }}>
            <Field
              label="Phone number" type="tel" inputMode="tel" value={phone} disabled={sent}
              onChange={(e) => setPhone(e.target.value)}
              error={error?.field === 'phone' ? error.message : undefined}
            />
            {sent && (
              <Field
                label="Verification code" inputMode="numeric" maxLength={6} value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                error={error?.field === 'code' ? error.message : undefined}
                className="text-center text-[24px] font-extrabold tracking-[0.3em]"
              />
            )}
            <Button type="submit" size="lg" block loading={busy}
              disabled={sent ? code.length < 6 : phone.replace(/\D/g, '').length < 10}>
              {sent ? 'Sign in' : 'Send code'}
            </Button>
          </form>
        </div>
        <p className="mt-4 text-center text-xs text-white/40">
          This console is not part of the customer application.
        </p>
      </div>
    </main>
  );
}

export default function OpsSignInPage() {
  return (
    <Suspense fallback={<main className="min-h-dvh bg-purple-900" aria-busy="true" />}>
      <OpsSignInForm />
    </Suspense>
  );
}
