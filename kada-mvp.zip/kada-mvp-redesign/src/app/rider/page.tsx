'use client';

import { useCallback, useEffect, useState } from 'react';
import { api, ApiError } from '@/lib/api-client';
import { useToast } from '@/components/toast';
import { naira } from '@/lib/money';
import { Button, Card, Field, Skeleton, StateScreen, Tag } from '@/components/ui';
import { zoneById, type OrderStatus } from '@/lib/types';

interface Job {
  _id: string; reference: string; status: OrderStatus; totalKobo: number;
  zoneId: string; landmark: string; lines: { name: string; qty: number }[];
}
interface Rider { _id: string; name: string; online: boolean; zoneId: string }
interface Earnings { runs: number; earnedKobo: number; tipsKobo: number; totalKobo: number }

export default function RiderRuns() {
  const { toast } = useToast();
  const [jobs, setJobs] = useState<Job[] | null>(null);
  const [offers, setOffers] = useState<Job[]>([]);
  const [rider, setRider] = useState<Rider | null>(null);
  const [earnings, setEarnings] = useState<Earnings | null>(null);
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const r = await api<{ jobs: Job[]; earnings: Earnings; rider: Rider }>('/api/rider/jobs');
      setJobs(r.jobs); setRider(r.rider); setEarnings(r.earnings); setError(null);
      if (!r.jobs.length && r.rider.online) {
        const o = await api<{ offers: Job[] }>('/api/rider/offers');
        setOffers(o.offers);
      } else setOffers([]);
    } catch (e) { setError((e as ApiError).message); }
  }, []);

  useEffect(() => {
    void load();
    const id = setInterval(() => void load(), 8000);
    return () => clearInterval(id);
  }, [load]);

  async function setOnline(online: boolean) {
    try {
      await api('/api/rider/status', { method: 'POST', json: { online } });
      toast(online ? 'You are online' : 'You are offline');
      await load();
    } catch (e) { toast((e as ApiError).message, 'error'); }
  }

  async function claim(orderId: string) {
    setBusy(true);
    try {
      await api('/api/rider/offers', { method: 'POST', json: { orderId } });
      toast('Run accepted. Head to the vendor');
      await load();
    } catch (e) { toast((e as ApiError).message, 'error'); }
    finally { setBusy(false); }
  }

  async function confirmPickup(orderId: string) {
    setBusy(true);
    try {
      await api('/api/rider/jobs', { method: 'POST', json: { orderId, code } });
      setCode(''); toast('Pickup confirmed');
      await load();
    } catch (e) { toast((e as ApiError).message, 'error'); }
    finally { setBusy(false); }
  }

  async function move(orderId: string, to: OrderStatus, label: string) {
    setBusy(true);
    try {
      await api('/api/orders/transition', { method: 'POST', json: { orderId, to } });
      toast(label);
      await load();
    } catch (e) { toast((e as ApiError).message, 'error'); }
    finally { setBusy(false); }
  }

  if (error) {
    return <div className="mx-auto max-w-[560px] px-4 pt-5">
      <StateScreen tone="error" icon="alert" title="Could not load your runs" body={error}
        action={<Button onClick={() => void load()}>Try again</Button>} />
    </div>;
  }
  if (!rider || !jobs) {
    return <div className="mx-auto max-w-[560px] px-4 pt-5"><Skeleton className="h-32 w-full rounded-lg" /></div>;
  }

  const job = jobs[0];

  return (
    <div className="mx-auto w-full max-w-[560px] px-4 pt-5 sm:px-6">
      {!job && (
        <Card className={rider.online ? 'border-ok-600' : ''}>
          <div className="flex items-center justify-between gap-3">
            <div>
              <h2 className="text-[19px] font-extrabold">{rider.online ? 'You are online' : 'You are offline'}</h2>
              <p className="mt-1 text-[13.5px] text-ink-600">
                {rider.online ? `Runs in ${zoneById(rider.zoneId).name} will reach you` : 'No runs will reach you until you switch on'}
              </p>
            </div>
            <button
              role="switch" aria-checked={rider.online} aria-label="Go online"
              onClick={() => void setOnline(!rider.online)}
              className={`relative h-[30px] w-[52px] flex-none rounded-full transition ${rider.online ? 'bg-ok-600' : 'bg-ink-200'}`}
            >
              <span className={`absolute top-[3px] h-6 w-6 rounded-full bg-white shadow-1 transition-[left] ${rider.online ? 'left-[25px]' : 'left-[3px]'}`} />
            </button>
          </div>
        </Card>
      )}

      {job ? (
        <>
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h1 className="num text-[27px] font-extrabold tracking-[-0.03em]">{job.reference}</h1>
              <p className="text-[13.5px] text-ink-600">
                {job.status === 'RIDER_ASSIGNED' ? 'Step 1 of 2 · collect' : 'Step 2 of 2 · deliver'}
              </p>
            </div>
            <Tag tone="brand">In progress</Tag>
          </div>

          <Card tone="brand" className="p-6">
            <span className="text-[13.5px] text-white/70">
              {job.status === 'RIDER_ASSIGNED' ? 'Collect from the vendor' : 'Deliver to'}
            </span>
            <h2 className="mt-1.5 text-[27px] font-extrabold tracking-[-0.03em]">
              {job.status === 'RIDER_ASSIGNED' ? 'Vendor pickup' : job.landmark || zoneById(job.zoneId).name}
            </h2>
            <p className="mt-2 text-[14.5px] text-white/80">{zoneById(job.zoneId).name}</p>
            <div className="mt-4 flex flex-wrap gap-2">
              <Tag tone="onBrand">{job.lines.reduce((a, l) => a + l.qty, 0)} items</Tag>
              <Tag tone="onBrand">Paid {naira(job.totalKobo)}</Tag>
            </div>
          </Card>

          {job.status === 'RIDER_ASSIGNED' ? (
            <div className="mt-6">
              <h3 className="text-[17px] font-bold">Enter the vendor pickup code</h3>
              <p className="mb-3 mt-1 text-[14.5px] text-ink-600">
                No code, no pickup. This is what stops you being blamed for an order you never collected.
              </p>
              <Field
                label="Pickup code" inputMode="numeric" maxLength={4} value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 4))}
                className="text-center text-[32px] font-extrabold tracking-[0.14em]"
              />
              <Button variant="ok" size="lg" block loading={busy} disabled={code.length !== 4}
                onClick={() => void confirmPickup(job._id)}>Confirm pickup</Button>
            </div>
          ) : (
            <div className="mt-6 space-y-3">
              {job.status === 'PICKED_UP' && (
                <Button size="lg" block loading={busy} onClick={() => void move(job._id, 'IN_TRANSIT', 'On the way')}>
                  Start delivery
                </Button>
              )}
              {job.status === 'IN_TRANSIT' && (
                <Button variant="ok" size="lg" block loading={busy} onClick={() => void move(job._id, 'DELIVERED', 'Delivered')}>
                  Mark delivered
                </Button>
              )}
            </div>
          )}

          <Card tone="ok" className="mt-4">
            <p className="text-[14.5px]">
              <b>Never collect money.</b> Every order is prepaid. If a customer offers you cash at the door,
              refuse it and report it.
            </p>
          </Card>
        </>
      ) : rider.online ? (
        offers.length ? (
          <>
            <h2 className="mb-3 mt-6 text-[19px] font-extrabold">Runs available now</h2>
            {offers.map((o) => (
              <Card key={o._id} className="mb-3 border-purple-700 bg-purple-50">
                <div className="flex items-center justify-between">
                  <Tag tone="brand">Run offered</Tag>
                  <b className="num text-[19px]">{naira(150000)}</b>
                </div>
                <h3 className="mt-3 text-[27px] font-extrabold tracking-[-0.03em]">{zoneById(o.zoneId).name}</h3>
                <p className="mt-1 text-[14.5px] text-ink-600">1 drop · {o.lines.length} items</p>
                <Card tone="ok" className="my-4">
                  <p className="text-[14.5px]"><b>No cash on this run.</b> The customer already paid {naira(o.totalKobo)} in the app.</p>
                </Card>
                <Button variant="ok" size="lg" block loading={busy} onClick={() => void claim(o._id)}>Accept run</Button>
              </Card>
            ))}
          </>
        ) : (
          <StateScreen icon="bike" title="Waiting for a run"
            body="A run appears here as soon as a vendor marks an order ready for pickup." />
        )
      ) : (
        <StateScreen icon="bike" title="Go online to get runs"
          body="You keep your normal work. This is what you earn in between." />
      )}

      {earnings && !job && (
        <Card className="mt-6">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-[17px] font-bold">This week</h3>
            <Tag>Pays Friday</Tag>
          </div>
          <div className="flex gap-6">
            <div><span className="text-xs text-ink-400">Runs</span><div className="num text-[25px] font-extrabold">{earnings.runs}</div></div>
            <div><span className="text-xs text-ink-400">Earned</span><div className="num text-[25px] font-extrabold">{naira(earnings.totalKobo)}</div></div>
            <div><span className="text-xs text-ink-400">Cash held</span><div className="num text-[25px] font-extrabold text-ok-600">₦0</div></div>
          </div>
        </Card>
      )}
      <div className="h-16" />
    </div>
  );
}
