import { redirect } from 'next/navigation';
import { readSession, APP_COOKIE } from '@/lib/session';
import { AppShell } from '@/components/app-shell';

export const dynamic = 'force-dynamic';

const NAV = [
  { href: '/rider', icon: 'bike', label: 'Runs' },
  { href: '/rider/earnings', icon: 'money', label: 'Earnings' },
];

export default async function RiderLayout({ children }: { children: React.ReactNode }) {
  const session = await readSession(APP_COOKIE);
  if (!session) redirect('/join?role=rider');
  if (!session.roles.includes('rider')) redirect('/shop');
  return <AppShell nav={NAV} title="Rider">{children}</AppShell>;
}
