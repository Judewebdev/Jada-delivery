'use client';

import { useEffect, useState } from 'react';
import { api, ApiError } from '@/lib/api-client';
import { naira } from '@/lib/money';
import { Button, Card, Skeleton, StateScreen } from '@/components/ui';

interface Earnings { runs: number; earnedKobo: number; tipsKobo: number; totalKobo: number }

export default function RiderEarnings() {
  const [data, setData] = useState<Earnings | null>(null);
  const [error, setError] = useState<string | null>(null);
  const load = () => api<{ earnings: Earnings }>('/api/rider/jobs')
    .then((r) => { setData(r.earnings); setError(null); })
    .catch((e: ApiError) => setError(e.message));
  useEffect(() => { void load(); }, []);

  if (error) return <div className="mx-auto max-w-[560px] px-4 pt-5">
    <StateScreen tone="error" icon="alert" title="Could not load earnings" body={error}
      action={<Button onClick={() => void load()}>Try again</Button>} /></div>;
  if (!data) return <div className="mx-auto max-w-[560px] px-4 pt-5"><Skeleton className="h-40 w-full rounded-lg" /></div>;

  return (
    <div className="mx-auto w-full max-w-[560px] px-4 pt-5 sm:px-6">
      <h1 className="text-[27px] font-extrabold tracking-[-0.03em]">Earnings</h1>
      <p className="mt-2 text-[14.5px] text-ink-600">Paid every Friday by transfer.</p>

      <Card tone="brand" className="mt-4 p-6">
        <span className="text-[14.5px] text-white/70">Next payment, Friday</span>
        <div className="mt-1 text-[30px] font-extrabold tracking-[-0.035em]">{naira(data.totalKobo)}</div>
      </Card>

      <div className="mt-6">
        {[
          [`${data.runs} runs completed`, naira(data.earnedKobo), ''],
          ['Tips from customers', naira(data.tipsKobo), 'text-ok-600'],
          ['Deductions', '₦0', ''],
        ].map(([k, v, cls]) => (
          <div key={k} className="flex justify-between border-b border-ink-200 py-3">
            <span className="text-ink-600">{k}</span><b className={`num ${cls}`}>{v}</b>
          </div>
        ))}
        <div className="mt-2 flex justify-between border-t-2 border-ink-900 pt-4 text-[18px] font-extrabold">
          <span>Total</span><span className="num">{naira(data.totalKobo)}</span>
        </div>
      </div>

      <Card tone="ok" className="mt-5">
        <p className="text-[14.5px]"><b>Every naira of a tip is yours.</b> KADA takes nothing from tips.</p>
      </Card>
      <Card tone="warn" className="mt-3">
        <p className="text-[14.5px]"><b>Cash you are holding: ₦0.</b> Every order is prepaid, so there is nothing to remit.</p>
      </Card>
      <div className="h-16" />
    </div>
  );
}
