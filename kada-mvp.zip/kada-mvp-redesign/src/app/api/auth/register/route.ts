import { NextResponse } from 'next/server';
import { z } from 'zod';
import { AuthService } from '@/lib/services/auth.service';
import { errorResponse, HttpError } from '@/lib/auth';
import { setSessionCookie, APP_COOKIE } from '@/lib/session';
import { ZONES } from '@/lib/types';

export const dynamic = 'force-dynamic';
const zoneIds = ZONES.map((z) => z.id) as [string, ...string[]];
const Body = z.object({
  phone: z.string().min(7),
  code: z.string().length(6),
  name: z.string().trim().min(2, 'Enter your name').max(80),
  zoneId: z.enum(zoneIds),
  landmark: z.string().trim().max(160).optional(),
  email: z.string().email('Enter a valid email').optional().or(z.literal('')),
});

export async function POST(req: Request) {
  try {
    const parsed = Body.safeParse(await req.json());
    if (!parsed.success) {
      const first = parsed.error.errors[0];
      throw new HttpError(400, first.message, String(first.path[0]));
    }
    // Verified again so registration cannot be called with an arbitrary number.
    await AuthService.verifyOtp(parsed.data.phone, parsed.data.code);

    const user = await AuthService.createCustomer({
      phone: parsed.data.phone,
      name: parsed.data.name,
      zoneId: parsed.data.zoneId,
      landmark: parsed.data.landmark,
      email: parsed.data.email || undefined,
    });
    await setSessionCookie(APP_COOKIE, { sub: String(user._id), roles: user.roles, name: user.name });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errorResponse(e);
  }
}
