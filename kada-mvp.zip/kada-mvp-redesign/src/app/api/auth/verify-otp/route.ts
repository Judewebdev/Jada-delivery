import { NextResponse } from 'next/server';
import { z } from 'zod';
import { AuthService } from '@/lib/services/auth.service';
import { errorResponse, HttpError } from '@/lib/auth';
import { rateLimit, clientKey } from '@/lib/rate-limit';
import { setSessionCookie, APP_COOKIE, OPS_COOKIE } from '@/lib/session';

export const dynamic = 'force-dynamic';
const Body = z.object({
  phone: z.string().min(7),
  code: z.string().length(6),
  surface: z.enum(['app', 'ops']).default('app'),
});

export async function POST(req: Request) {
  try {
    const lim = rateLimit(clientKey(req, 'verify'), 20, 900);
    if (!lim.ok) throw new HttpError(429, `Too many attempts. Try again in ${lim.retryAfterSec} seconds.`);

    const parsed = Body.safeParse(await req.json());
    if (!parsed.success) throw new HttpError(400, 'Enter the six digit code.', 'code');

    const { phone, user } = await AuthService.verifyOtp(parsed.data.phone, parsed.data.code);
    if (!user) return NextResponse.json({ verified: true, registered: false, phone });

    const resolved = await AuthService.resolveRoles(phone);
    if (!resolved) throw new HttpError(500, 'Could not load your account.');

    if (parsed.data.surface === 'ops') {
      if (!resolved.session.roles.includes('admin')) {
        throw new HttpError(403, 'This number does not have Ops access.');
      }
      await setSessionCookie(OPS_COOKIE, resolved.session, 60 * 60 * 8);
    } else {
      await setSessionCookie(APP_COOKIE, resolved.session);
    }
    return NextResponse.json({ verified: true, registered: true, roles: resolved.session.roles });
  } catch (e) {
    return errorResponse(e);
  }
}
