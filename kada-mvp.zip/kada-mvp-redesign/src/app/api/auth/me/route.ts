import { NextResponse } from 'next/server';
import { readSession, APP_COOKIE } from '@/lib/session';
import { connectDb } from '@/lib/db';
import { User } from '@/lib/models';
import { errorResponse } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const s = await readSession(APP_COOKIE);
    if (!s) return NextResponse.json({ user: null });
    await connectDb();
    const u = await User.findById(s.sub).select('name phone roles zoneId landmark walletKobo').lean();
    if (!u) return NextResponse.json({ user: null });
    return NextResponse.json({
      user: {
        id: String(u._id), name: u.name, phone: u.phone, roles: u.roles,
        zoneId: u.zoneId, landmark: u.landmark, walletKobo: u.walletKobo,
        vendorId: s.vendorId, riderId: s.riderId,
      },
    });
  } catch (e) {
    return errorResponse(e);
  }
}
