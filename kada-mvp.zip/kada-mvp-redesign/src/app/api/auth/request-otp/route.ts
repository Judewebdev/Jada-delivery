import { NextResponse } from 'next/server';
import { z } from 'zod';
import { AuthService } from '@/lib/services/auth.service';
import { errorResponse, HttpError } from '@/lib/auth';
import { rateLimit, clientKey } from '@/lib/rate-limit';

export const dynamic = 'force-dynamic';
const Body = z.object({ phone: z.string().min(7).max(20) });

export async function POST(req: Request) {
  try {
    const ip = rateLimit(clientKey(req, 'otp'), 10, 900);
    if (!ip.ok) throw new HttpError(429, `Too many requests. Try again in ${ip.retryAfterSec} seconds.`);

    const parsed = Body.safeParse(await req.json());
    if (!parsed.success) throw new HttpError(400, 'Enter a valid phone number.', 'phone');

    const perPhone = rateLimit(`phone:${parsed.data.phone}`, 5, 900);
    if (!perPhone.ok) throw new HttpError(429, `Too many codes requested. Try again in ${perPhone.retryAfterSec} seconds.`);

    return NextResponse.json(await AuthService.requestOtp(parsed.data.phone));
  } catch (e) {
    return errorResponse(e);
  }
}
