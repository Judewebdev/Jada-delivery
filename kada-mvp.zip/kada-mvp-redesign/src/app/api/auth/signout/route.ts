import { NextResponse } from 'next/server';
import { clearSessionCookie, APP_COOKIE, OPS_COOKIE } from '@/lib/session';

export const dynamic = 'force-dynamic';

export async function POST(req: Request) {
  const surface = new URL(req.url).searchParams.get('surface');
  clearSessionCookie(surface === 'ops' ? OPS_COOKIE : APP_COOKIE);
  return NextResponse.json({ ok: true });
}
