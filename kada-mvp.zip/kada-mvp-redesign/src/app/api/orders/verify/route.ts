import { NextResponse } from 'next/server';
import { z } from 'zod';
import { connectDb } from '@/lib/db';
import { Order, Payment } from '@/lib/models';
import { PaymentService } from '@/lib/services/payment.service';
import { OrderService } from '@/lib/services/order.service';
import { errorResponse, HttpError, requireRole } from '@/lib/auth';

export const dynamic = 'force-dynamic';
const Body = z.object({ reference: z.string().min(6).max(120) });

/**
 * Confirms a Paystack transaction. The order only becomes PAID if Paystack
 * itself reports success for this reference and the amount covers the total.
 */
export async function POST(req: Request) {
  try {
    const s = await requireRole('customer');
    const parsed = Body.safeParse(await req.json());
    if (!parsed.success) throw new HttpError(400, 'Missing payment reference.');

    await connectDb();
    const order = await Order.findOne({ paymentRef: parsed.data.reference });
    if (!order) throw new HttpError(404, 'We could not find that payment.');
    if (String(order.userId) !== s.sub) throw new HttpError(403, 'That order is not yours.');
    if (order.status !== 'PENDING_PAYMENT') {
      return NextResponse.json({ paid: true, orderId: String(order._id), status: order.status });
    }

    const v = await PaymentService.verify(parsed.data.reference);
    await Payment.findOneAndUpdate(
      { reference: parsed.data.reference },
      {
        orderId: order._id, userId: order.userId, reference: parsed.data.reference,
        provider: 'paystack', amountKobo: v.amountKobo ?? order.totalKobo,
        status: v.paid ? 'success' : 'failed', rawVerification: v.raw,
      },
      { upsert: true }
    );

    if (!v.ok || !v.paid) {
      return NextResponse.json(
        { paid: false, orderId: String(order._id), error: v.error ?? 'Payment was not completed.' },
        { status: 402 }
      );
    }

    await OrderService.markPaid(String(order._id), parsed.data.reference, v.amountKobo ?? 0, v.channel ?? 'paystack');
    return NextResponse.json({ paid: true, orderId: String(order._id), status: 'PAID' });
  } catch (e) {
    return errorResponse(e);
  }
}
