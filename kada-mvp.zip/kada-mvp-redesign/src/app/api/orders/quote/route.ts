import { NextResponse } from 'next/server';
import { z } from 'zod';
import { OrderService } from '@/lib/services/order.service';
import { errorResponse, HttpError, requireRole } from '@/lib/auth';
import { ZONES, DISPATCH_SLOTS } from '@/lib/types';

export const dynamic = 'force-dynamic';
const Body = z.object({
  lines: z.array(z.object({ productId: z.string().length(24), qty: z.number().int().min(1).max(20) })).min(1).max(40),
  zoneId: z.enum(ZONES.map((z) => z.id) as [string, ...string[]]),
  slotId: z.enum(DISPATCH_SLOTS.map((s) => s.id) as [string, ...string[]]),
});

export async function POST(req: Request) {
  try {
    await requireRole('customer');
    const parsed = Body.safeParse(await req.json());
    if (!parsed.success) throw new HttpError(400, 'That cart is not valid.');
    return NextResponse.json(await OrderService.quote(parsed.data));
  } catch (e) {
    return errorResponse(e);
  }
}
