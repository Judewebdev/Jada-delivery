import { NextResponse } from 'next/server';
import { z } from 'zod';
import { OrderService } from '@/lib/services/order.service';
import { errorResponse, HttpError, requireRole } from '@/lib/auth';
import { rateLimit, clientKey } from '@/lib/rate-limit';
import { ZONES, DISPATCH_SLOTS } from '@/lib/types';

export const dynamic = 'force-dynamic';
const Body = z.object({
  lines: z.array(z.object({ productId: z.string().length(24), qty: z.number().int().min(1).max(20) })).min(1).max(40),
  zoneId: z.enum(ZONES.map((z) => z.id) as [string, ...string[]]),
  slotId: z.enum(DISPATCH_SLOTS.map((s) => s.id) as [string, ...string[]]),
  landmark: z.string().max(160).default(''),
  paymentMethod: z.enum(['wallet', 'paystack']),
});

export async function GET() {
  try {
    const s = await requireRole('customer');
    return NextResponse.json({ orders: await OrderService.listForUser(s.sub) });
  } catch (e) {
    return errorResponse(e);
  }
}

export async function POST(req: Request) {
  try {
    const s = await requireRole('customer');
    const lim = rateLimit(clientKey(req, 'order'), 12, 300);
    if (!lim.ok) throw new HttpError(429, 'You are placing orders very quickly. Give it a moment.');

    const parsed = Body.safeParse(await req.json());
    if (!parsed.success) throw new HttpError(400, 'Check your delivery details and try again.');

    const result = await OrderService.create({ userId: s.sub, ...parsed.data });
    return NextResponse.json(result, { status: 201 });
  } catch (e) {
    return errorResponse(e);
  }
}
