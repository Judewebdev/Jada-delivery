import { NextResponse } from 'next/server';
import { z } from 'zod';
import { OrderService } from '@/lib/services/order.service';
import { errorResponse, HttpError, requireRole } from '@/lib/auth';
import { ORDER_STATUSES } from '@/lib/types';
import { connectDb } from '@/lib/db';
import { Order } from '@/lib/models';

export const dynamic = 'force-dynamic';
const Body = z.object({
  orderId: z.string().length(24),
  to: z.enum(ORDER_STATUSES),
  note: z.string().max(300).optional(),
});

/**
 * Single transition endpoint for vendor, rider and customer. Ownership is
 * re-checked against the database, never taken from the request body.
 */
export async function POST(req: Request) {
  try {
    const s = await requireRole('customer', 'vendor', 'rider');
    const parsed = Body.safeParse(await req.json());
    if (!parsed.success) throw new HttpError(400, 'That action is not valid.');

    await connectDb();
    const order = await Order.findById(parsed.data.orderId).select('userId vendorId riderId').lean();
    if (!order) throw new HttpError(404, 'Order not found.');

    let role: 'customer' | 'vendor' | 'rider';
    if (s.vendorId && String(order.vendorId) === s.vendorId) role = 'vendor';
    else if (s.riderId && String(order.riderId ?? '') === s.riderId) role = 'rider';
    else if (String(order.userId) === s.sub) role = 'customer';
    else throw new HttpError(403, 'You do not have access to this order.');

    const updated = await OrderService.transition({
      orderId: parsed.data.orderId, to: parsed.data.to, role,
      actorId: s.sub, note: parsed.data.note,
    });
    return NextResponse.json({ order: updated });
  } catch (e) {
    return errorResponse(e);
  }
}
