import { NextResponse } from 'next/server';
import { z } from 'zod';
import { connectDb } from '@/lib/db';
import { Application } from '@/lib/models';
import { errorResponse, HttpError } from '@/lib/auth';
import { rateLimit, clientKey } from '@/lib/rate-limit';
import { normalisePhone } from '@/lib/services/auth.service';
import { CATEGORIES, ZONES } from '@/lib/types';

export const dynamic = 'force-dynamic';

const Body = z.object({
  type: z.enum(['vendor', 'rider']),
  name: z.string().trim().min(2, 'Enter a name').max(120),
  phone: z.string().min(7),
  summary: z.string().max(200).default(''),
  documents: z.array(z.string().max(60)).max(12).default([]),
  missing: z.array(z.string().max(60)).max(12).default([]),
  payload: z.record(z.unknown()).default({}),
});

/** Public endpoint used by the vendor and rider signup flows. */
export async function POST(req: Request) {
  try {
    const lim = rateLimit(clientKey(req, 'apply'), 5, 3600);
    if (!lim.ok) throw new HttpError(429, 'Too many applications from this device. Try again later.');

    const parsed = Body.safeParse(await req.json());
    if (!parsed.success) {
      const first = parsed.error.errors[0];
      throw new HttpError(400, first.message, String(first.path[0]));
    }
    const phone = normalisePhone(parsed.data.phone);
    await connectDb();

    const dup = await Application.findOne({ phone, type: parsed.data.type, status: 'pending' });
    if (dup) throw new HttpError(409, 'You already have an application waiting for review.');

    const payload = parsed.data.payload as Record<string, string>;
    if (parsed.data.type === 'vendor') {
      const valid = CATEGORIES.some((c) => c.id === payload.categoryId);
      if (!valid) throw new HttpError(400, 'Choose what you sell.', 'categoryId');
      if (payload.categoryId === 'pharmacy' && !parsed.data.documents.includes('PCN licence')) {
        parsed.data.missing.push('PCN premises licence');
      }
    }
    if (!ZONES.some((z) => z.id === payload.zoneId)) {
      throw new HttpError(400, 'Choose your zone.', 'zoneId');
    }

    const app = await Application.create({ ...parsed.data, phone, status: 'pending' });
    return NextResponse.json({ ok: true, id: String(app._id) }, { status: 201 });
  } catch (e) {
    return errorResponse(e);
  }
}
