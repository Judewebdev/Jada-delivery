import { NextResponse } from 'next/server';
import { z } from 'zod';
import { OrderService } from '@/lib/services/order.service';
import { errorResponse, HttpError, requireAdmin } from '@/lib/auth';
import { connectDb } from '@/lib/db';
import { Order, Rider, Vendor } from '@/lib/models';
import { ORDER_STATUSES } from '@/lib/types';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    await requireAdmin();
    await connectDb();
    const [orders, riders, vendors] = await Promise.all([
      OrderService.listLive(),
      Rider.find({ status: 'active' }).lean(),
      Vendor.find().lean(),
    ]);
    return NextResponse.json({ orders, riders, vendors });
  } catch (e) {
    return errorResponse(e);
  }
}

const Action = z.object({
  orderId: z.string().length(24),
  action: z.enum(['assign', 'cancel', 'transition']),
  riderId: z.string().length(24).optional(),
  to: z.enum(ORDER_STATUSES).optional(),
  note: z.string().max(300).optional(),
});

export async function POST(req: Request) {
  try {
    const admin = await requireAdmin();
    const parsed = Action.safeParse(await req.json());
    if (!parsed.success) throw new HttpError(400, 'Invalid action.');
    await connectDb();

    if (parsed.data.action === 'assign') {
      if (!parsed.data.riderId) throw new HttpError(400, 'Choose a rider.');
      const order = await OrderService.transition({
        orderId: parsed.data.orderId, to: 'RIDER_ASSIGNED', role: 'admin',
        actorId: admin.sub, riderId: parsed.data.riderId, note: 'Assigned by operations',
      });
      return NextResponse.json({ order });
    }
    if (parsed.data.action === 'cancel') {
      const order = await OrderService.transition({
        orderId: parsed.data.orderId, to: 'CANCELLED', role: 'admin',
        actorId: admin.sub, note: parsed.data.note ?? 'Cancelled by operations',
      });
      return NextResponse.json({ order });
    }
    if (!parsed.data.to) throw new HttpError(400, 'Target status required.');
    const order = await OrderService.transition({
      orderId: parsed.data.orderId, to: parsed.data.to, role: 'admin',
      actorId: admin.sub, note: parsed.data.note,
    });
    return NextResponse.json({ order });
  } catch (e) {
    return errorResponse(e);
  }
}
