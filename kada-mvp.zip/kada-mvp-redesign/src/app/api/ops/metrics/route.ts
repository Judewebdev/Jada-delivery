import { NextResponse } from 'next/server';
import { connectDb } from '@/lib/db';
import { Order, Vendor, Rider, User } from '@/lib/models';
import { errorResponse, requireAdmin } from '@/lib/auth';
import { LIVE_STATUSES } from '@/lib/types';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    await requireAdmin();
    await connectDb();

    const [delivered, live, cancelled, vendors, riders, customers] = await Promise.all([
      Order.find({ status: 'DELIVERED' }).select('totalKobo commissionKobo serviceFeeKobo riderId').lean(),
      Order.countDocuments({ status: { $in: LIVE_STATUSES } }),
      Order.countDocuments({ status: 'CANCELLED' }),
      Vendor.countDocuments({ status: 'active' }),
      Rider.countDocuments({ status: 'active' }),
      User.countDocuments({ roles: 'customer' }),
    ]);

    const gmvKobo = delivered.reduce((a, o) => a + o.totalKobo, 0);
    const takeKobo = delivered.reduce((a, o) => a + o.commissionKobo + o.serviceFeeKobo, 0);
    const riderCostKobo = delivered.length * 150000;
    const runs = new Set(delivered.map((o) => String(o.riderId ?? ''))).size || 1;

    return NextResponse.json({
      gmvKobo,
      takeKobo,
      contributionKobo: takeKobo - riderCostKobo,
      takeRatePct: gmvKobo ? Math.round((takeKobo / gmvKobo) * 1000) / 10 : 0,
      deliveredCount: delivered.length,
      liveCount: live,
      cancelledCount: cancelled,
      dropsPerRun: Math.round((delivered.length / runs) * 10) / 10,
      vendors,
      riders,
      customers,
    });
  } catch (e) {
    return errorResponse(e);
  }
}
