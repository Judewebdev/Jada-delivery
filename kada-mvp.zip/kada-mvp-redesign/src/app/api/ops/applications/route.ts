import { NextResponse } from 'next/server';
import { z } from 'zod';
import { connectDb } from '@/lib/db';
import { Application, Vendor, Rider, User } from '@/lib/models';
import { errorResponse, HttpError, requireAdmin } from '@/lib/auth';
import { categoryById } from '@/lib/types';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    await requireAdmin();
    await connectDb();
    return NextResponse.json({
      applications: await Application.find({ status: 'pending' }).sort({ createdAt: -1 }).lean(),
    });
  } catch (e) {
    return errorResponse(e);
  }
}

const Body = z.object({
  applicationId: z.string().length(24),
  decision: z.enum(['approve', 'reject']),
});

export async function POST(req: Request) {
  try {
    await requireAdmin();
    const parsed = Body.safeParse(await req.json());
    if (!parsed.success) throw new HttpError(400, 'Invalid request.');
    await connectDb();

    const app = await Application.findById(parsed.data.applicationId);
    if (!app) throw new HttpError(404, 'Application not found.');
    if (app.status !== 'pending') throw new HttpError(409, 'That application was already decided.');

    if (parsed.data.decision === 'reject') {
      app.status = 'rejected';
      await app.save();
      return NextResponse.json({ ok: true });
    }
    if (app.missing.length) {
      throw new HttpError(409, `Cannot approve while ${app.missing[0]} is outstanding.`);
    }

    const payload = app.payload as Record<string, string>;
    if (app.type === 'vendor') {
      const categoryId = payload.categoryId ?? 'food';
      const vendor = await Vendor.create({
        name: app.name, ownerName: payload.ownerName ?? app.name, phone: app.phone,
        categoryId, zoneId: payload.zoneId ?? 'emaudo', address: payload.address ?? '',
        isOpen: false, status: 'active', prepMins: Number(payload.prepMins ?? 25),
        commissionPct: 10, payoutBank: payload.bank, payoutAccountMasked: payload.accountMasked,
        licenceRef: payload.licenceRef,
      });
      await User.findOneAndUpdate(
        { phone: app.phone },
        { $addToSet: { roles: 'vendor' }, vendorId: vendor._id, $setOnInsert: { name: app.name, phoneVerified: false } },
        { upsert: true }
      );
      app.status = 'approved';
      await app.save();
      return NextResponse.json({ ok: true, vendorId: String(vendor._id), category: categoryById(categoryId).name });
    }

    const rider = await Rider.create({
      name: app.name, phone: app.phone, bike: payload.bike ?? '',
      zoneId: payload.zoneId ?? 'emaudo', online: false, status: 'active',
      guarantorName: payload.guarantorName, guarantorPhone: payload.guarantorPhone,
      slots: Array.isArray(app.payload.slots) ? (app.payload.slots as string[]) : [],
    });
    await User.findOneAndUpdate(
      { phone: app.phone },
      { $addToSet: { roles: 'rider' }, riderId: rider._id, $setOnInsert: { name: app.name, phoneVerified: false } },
      { upsert: true }
    );
    app.status = 'approved';
    await app.save();
    return NextResponse.json({ ok: true, riderId: String(rider._id) });
  } catch (e) {
    return errorResponse(e);
  }
}
