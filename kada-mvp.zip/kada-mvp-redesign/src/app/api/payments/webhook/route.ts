import { NextResponse } from 'next/server';
import { connectDb } from '@/lib/db';
import { Order, Payment } from '@/lib/models';
import { PaymentService } from '@/lib/services/payment.service';
import { OrderService } from '@/lib/services/order.service';

export const dynamic = 'force-dynamic';

/**
 * Paystack webhook. Signature is validated before the body is trusted. This is
 * the safety net for customers who close the browser before the callback runs.
 */
export async function POST(req: Request) {
  const raw = await req.text();
  const signature = req.headers.get('x-paystack-signature');
  if (!PaymentService.verifyWebhookSignature(raw, signature)) {
    return NextResponse.json({ error: 'Invalid signature' }, { status: 401 });
  }

  const event = JSON.parse(raw) as { event: string; data: { reference: string; amount: number; channel: string } };
  if (event.event !== 'charge.success') return NextResponse.json({ received: true });

  try {
    await connectDb();
    const order = await Order.findOne({ paymentRef: event.data.reference });
    if (!order) return NextResponse.json({ received: true });

    await Payment.findOneAndUpdate(
      { reference: event.data.reference },
      {
        orderId: order._id, userId: order.userId, reference: event.data.reference,
        provider: 'paystack', amountKobo: event.data.amount, status: 'success', rawVerification: event.data,
      },
      { upsert: true }
    );
    await OrderService.markPaid(String(order._id), event.data.reference, event.data.amount, event.data.channel);
  } catch (e) {
    console.error('[kada] webhook', e);
  }
  return NextResponse.json({ received: true });
}
