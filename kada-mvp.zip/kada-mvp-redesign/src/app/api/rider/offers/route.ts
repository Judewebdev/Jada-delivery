import { NextResponse } from 'next/server';
import { z } from 'zod';
import { OrderService } from '@/lib/services/order.service';
import { RiderService } from '@/lib/services/rider.service';
import { errorResponse, HttpError, requireRole } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const s = await requireRole('rider');
    if (!s.riderId) throw new HttpError(403, 'No rider account is linked.');
    const rider = await RiderService.get(s.riderId);
    if (!rider.online) return NextResponse.json({ offers: [] });
    return NextResponse.json({ offers: await OrderService.listOffers() });
  } catch (e) {
    return errorResponse(e);
  }
}

/** Claim an available run. */
export async function POST(req: Request) {
  try {
    const s = await requireRole('rider');
    if (!s.riderId) throw new HttpError(403, 'No rider account is linked.');
    const parsed = z.object({ orderId: z.string().length(24) }).safeParse(await req.json());
    if (!parsed.success) throw new HttpError(400, 'Invalid request.');

    const order = await OrderService.transition({
      orderId: parsed.data.orderId, to: 'RIDER_ASSIGNED', role: 'rider',
      actorId: s.sub, riderId: s.riderId, note: 'Run accepted by rider',
    });
    return NextResponse.json({ order });
  } catch (e) {
    return errorResponse(e);
  }
}
