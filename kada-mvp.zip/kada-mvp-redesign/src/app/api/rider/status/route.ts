import { NextResponse } from 'next/server';
import { z } from 'zod';
import { RiderService } from '@/lib/services/rider.service';
import { errorResponse, HttpError, requireRole } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function POST(req: Request) {
  try {
    const s = await requireRole('rider');
    if (!s.riderId) throw new HttpError(403, 'No rider account is linked.');
    const parsed = z.object({
      online: z.boolean().optional(),
      slots: z.array(z.string().max(20)).optional(),
    }).safeParse(await req.json());
    if (!parsed.success) throw new HttpError(400, 'Invalid request.');

    let rider;
    if (parsed.data.online !== undefined) rider = await RiderService.setOnline(s.riderId, parsed.data.online);
    if (parsed.data.slots) rider = await RiderService.setSlots(s.riderId, parsed.data.slots);
    return NextResponse.json({ rider });
  } catch (e) {
    return errorResponse(e);
  }
}
