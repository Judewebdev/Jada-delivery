import { NextResponse } from 'next/server';
import { z } from 'zod';
import { RiderService } from '@/lib/services/rider.service';
import { OrderService } from '@/lib/services/order.service';
import { errorResponse, HttpError, requireRole } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const s = await requireRole('rider');
    if (!s.riderId) throw new HttpError(403, 'No rider account is linked.');
    const [jobs, earnings, rider] = await Promise.all([
      RiderService.activeJobs(s.riderId),
      RiderService.earnings(s.riderId),
      RiderService.get(s.riderId),
    ]);
    return NextResponse.json({ jobs, earnings, rider });
  } catch (e) {
    return errorResponse(e);
  }
}

/** Confirm pickup with the vendor's four digit code. */
export async function POST(req: Request) {
  try {
    const s = await requireRole('rider');
    if (!s.riderId) throw new HttpError(403, 'No rider account is linked.');
    const parsed = z.object({
      orderId: z.string().length(24),
      code: z.string().length(4),
    }).safeParse(await req.json());
    if (!parsed.success) throw new HttpError(400, 'Enter the four digit code.', 'code');

    const order = await OrderService.confirmPickup(parsed.data.orderId, parsed.data.code, s.riderId);
    return NextResponse.json({ order });
  } catch (e) {
    return errorResponse(e);
  }
}
