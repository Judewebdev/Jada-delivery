import { NextResponse } from 'next/server';
import { CatalogService } from '@/lib/services/catalog.service';
import { errorResponse } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  try {
    const q = new URL(req.url).searchParams.get('q') ?? '';
    return NextResponse.json(await CatalogService.search(q));
  } catch (e) {
    return errorResponse(e);
  }
}
